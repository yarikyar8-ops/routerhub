package com.routerhub.app;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UserInfo;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

// SSH-терминал. Ключи серверов запоминаются при первом подключении (как в PuTTY) и проверяются при следующих.
class SshBridge {
    final MainActivity a;
    final WebView w;
    final SharedPreferences sp;
    final ExecutorService wr = Executors.newSingleThreadExecutor();
    volatile Session ses;
    volatile ChannelShell ch;
    volatile OutputStream out;
    volatile boolean busy = false;
    static boolean cfg = false;

    SshBridge(MainActivity a, WebView w) {
        this.a = a; this.w = w;
        sp = a.getSharedPreferences("pins", 0);
    }

    void ev(String t, String d) {
        final String c = "window.sshEv('" + t + "'," + JSONObject.quote(d) + ")";
        a.runOnUiThread(() -> w.evaluateJavascript(c, null));
    }

    String msg(Throwable e) {
        String m = String.valueOf(e.getMessage());
        if (m.contains("Auth fail") || m.contains("Auth cancel")) return "Неверный логин или пароль";
        if (m.contains("refused")) return "Подключение отклонено: SSH выключен или неверный порт";
        if (m.contains("timeout") || m.contains("timed out")) return "Нет ответа от хоста";
        if (m.contains("UnknownHost") || m.contains("Unable to resolve")) return "Адрес не найден";
        return m;
    }

    boolean ask(final String t) {
        final CountDownLatch l = new CountDownLatch(1);
        final boolean[] r = {false};
        a.runOnUiThread(() -> new AlertDialog.Builder(a).setTitle("SSH").setMessage(t).setCancelable(false)
            .setPositiveButton("Доверять", (d, i) -> { r[0] = true; l.countDown(); })
            .setNegativeButton("Отмена", (d, i) -> l.countDown()).show());
        try { l.await(120, TimeUnit.SECONDS); } catch (Exception e) { }
        return r[0];
    }

    boolean verify(String host, int port, String m) {
        Matcher mt = Pattern.compile("(SHA256|MD5):[A-Za-z0-9+/=:]+").matcher(m);
        if (!mt.find()) return false;
        String fp = mt.group(), k = host + ":" + port, old = sp.getString(k, null);
        if (fp.equals(old)) return true;
        String t = old == null
            ? "Новый сервер.\nОтпечаток ключа:\n" + fp + "\n\nДоверять?"
            : "⚠️ КЛЮЧ СЕРВЕРА ИЗМЕНИЛСЯ!\nЭто может быть подмена (атака) или переустановка роутера.\nНовый отпечаток:\n" + fp + "\n\nЗаменить сохранённый и продолжить?";
        boolean ok = ask(t);
        if (ok) sp.edit().putString(k, fp).apply();
        return ok;
    }

    @JavascriptInterface public void connect(final String host, final int port, final String user, final String pass, final int cols, final int rows) {
        if (busy) return;
        busy = true;
        new Thread(() -> {
            try {
                if (port < 1 || port > 65535) throw new Exception("Неверный порт");
                if (!cfg) {
                    cfg = true;
                    try { Class.forName("com.jcraft.jsch.bc.SignatureEd25519"); JSch.setConfig("ssh-ed25519", "com.jcraft.jsch.bc.SignatureEd25519"); } catch (Throwable t) { }
                }
                JSch j = new JSch();
                Session s = j.getSession(user, host, port);
                s.setPassword(pass);
                s.setConfig("StrictHostKeyChecking", "ask");
                s.setConfig("PreferredAuthentications", "password");
                s.setUserInfo(new UserInfo() {
                    public String getPassphrase() { return null; }
                    public String getPassword() { return pass; }
                    public boolean promptPassword(String m) { return true; }
                    public boolean promptPassphrase(String m) { return false; }
                    public boolean promptYesNo(String m) { return verify(host, port, m); }
                    public void showMessage(String m) { }
                });
                ses = s;
                s.setServerAliveInterval(15000);
                s.connect(10000);
                ChannelShell c = (ChannelShell) s.openChannel("shell");
                c.setPtyType("dumb", cols, rows, 0, 0);
                InputStream in = c.getInputStream();
                out = c.getOutputStream();
                c.connect(8000);
                ch = c;
                ev("ok", "");
                InputStreamReader r = new InputStreamReader(in, StandardCharsets.UTF_8);
                char[] buf = new char[4096]; int n;
                while ((n = r.read(buf)) > 0) ev("out", new String(buf, 0, n));
            } catch (Throwable e) {
                ev("err", msg(e));
            } finally {
                close0();
                ev("closed", "");
                busy = false;
            }
        }).start();
    }

    @JavascriptInterface public void send(final String d) {
        wr.execute(() -> { try { OutputStream o = out; if (o != null) { o.write(d.getBytes(StandardCharsets.UTF_8)); o.flush(); } } catch (Exception e) { } });
    }
    @JavascriptInterface public void resize(int c, int r) { try { if (ch != null) ch.setPtySize(c, r, 0, 0); } catch (Exception e) { } }
    @JavascriptInterface public void close() { close0(); }

    void close0() {
        try { if (ch != null) ch.disconnect(); } catch (Exception e) { }
        try { if (ses != null) ses.disconnect(); } catch (Exception e) { }
        ch = null; ses = null; out = null;
    }
}
