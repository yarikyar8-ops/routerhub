package com.routerhub.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.net.URL;

// Отдельное окно для LuCI: без доступа к функциям приложения, только страницы одного роутера
public class LuciActivity extends Activity {
    WebView w;
    String host;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (getSharedPreferences("s", 0).getBoolean("secure", true))
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        String u = getIntent().getStringExtra("u");
        try { host = new URL(u).getHost(); } catch (Exception e) { finish(); return; }
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSaveFormData(false);
        w.setBackgroundColor(0xFF0F1220);
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !host.equals(r.getUrl().getHost());
            }
        });
        w.loadUrl(u);
    }
    @Override public void onBackPressed() { if (w.canGoBack()) w.goBack(); else finish(); }
    @Override protected void onDestroy() {
        CookieManager.getInstance().removeAllCookies(null);
        if (w != null) { w.clearCache(true); w.clearHistory(); w.destroy(); }
        super.onDestroy();
    }
}
