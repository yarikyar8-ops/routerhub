package com.routerhub.app;

import java.net.InetAddress;
import java.net.URL;

final class Net {
    // http разрешён только для локальных адресов, для остальных нужен https
    static boolean hostOk(URL x) {
        try {
            String p = x.getProtocol();
            if (p.equals("https")) return true;
            if (!p.equals("http")) return false;
            for (InetAddress a : InetAddress.getAllByName(x.getHost())) if (!priv(a)) return false;
            return true;
        } catch (Exception e) { return false; }
    }
    // публичный адрес (для загрузки подписок с телефона): никаких локальных сетей
    static boolean pubOk(URL x) {
        try {
            String p = x.getProtocol();
            if (!p.equals("http") && !p.equals("https")) return false;
            for (InetAddress a : InetAddress.getAllByName(x.getHost()))
                if (priv(a) || a.isAnyLocalAddress() || a.isMulticastAddress()) return false;
            return true;
        } catch (Exception e) { return false; }
    }
    static boolean priv(InetAddress a) {
        if (a.isLoopbackAddress() || a.isSiteLocalAddress() || a.isLinkLocalAddress()) return true;
        byte[] b = a.getAddress();
        if (b.length == 4) return (b[0] & 255) == 100 && (b[1] & 192) == 64;
        return (b[0] & 0xFE) == 0xFC;
    }
}
