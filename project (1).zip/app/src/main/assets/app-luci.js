'use strict';
// ====== Schema-driven LuCI-style pages ======
const FX = {
  t: (o, ru, en, x) => Object.assign({ o, t: 'text', l: _(ru, en) }, x),
  pw: (o, ru, en, x) => Object.assign({ o, t: 'password', l: _(ru, en) }, x),
  s: (o, ru, en, opts, x) => Object.assign({ o, t: 'select', l: _(ru, en), opts: opts.map(a => [a[0], _(a[1], a[2])]) }, x),
  f: (o, ru, en, x) => Object.assign({ o, t: 'check', l: _(ru, en) }, x),
  l: (o, ru, en, x) => Object.assign({ o, t: 'list', l: _(ru, en), h: _('По одному значению в строке', 'One value per line') }, x)
};
const POL = [['ACCEPT', 'Разрешить', 'Accept'], ['REJECT', 'Отклонить', 'Reject'], ['DROP', 'Отбросить', 'Drop']];
const isMacRe = /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/, isIpRe = /^\d{1,3}(\.\d{1,3}){3}$/, numRe = /^\d+$/, portRe = /^\d{1,5}(-\d{1,5})?$/;
const SPEC = () => ({
  ifs: { cfg: 'network', type: 'interface', t: _('Интерфейсы', 'Interfaces'), add: 1, del: 1, named: 1, warn: _('Сеть перезапустится, подключение может пропасть на минуту.', 'The network will restart; the connection may drop for a minute.'), skip: (s, k) => k === 'loopback',
    sum: (s, k) => [esc(k), esc(L.protoName(s.proto || '', lang === 'ru') + ' · ' + (s.ipaddr || '—') + ' · ' + (s.device || s.ifname || ''))],
    fields: [FX.s('proto', 'Способ подключения', 'Connection method', [['static', 'Статический адрес', 'Static address'], ['dhcp', 'DHCP-клиент', 'DHCP client'], ['dhcpv6', 'DHCPv6', 'DHCPv6'], ['pppoe', 'PPPoE', 'PPPoE'], ['none', 'Не настроен', 'Unmanaged']], { def: 'dhcp', custom: 1 }),
      FX.t('device', 'Устройство', 'Device', { p: 'br-lan / eth1' }),
      FX.t('ipaddr', 'IP-адрес', 'IPv4 address', { show: g => g('proto') === 'static', re: /^\d{1,3}(\.\d{1,3}){3}(\/\d+)?$/ }), FX.t('netmask', 'Маска', 'Netmask', { show: g => g('proto') === 'static', p: '255.255.255.0' }),
      FX.t('gateway', 'Шлюз', 'Gateway', { show: g => g('proto') === 'static' }), FX.l('dns', 'DNS-серверы', 'DNS servers', { show: g => ['static', 'dhcp', 'pppoe'].includes(g('proto')) }),
      FX.t('username', 'Логин PPPoE', 'PPPoE username', { show: g => g('proto') === 'pppoe' }), FX.pw('password', 'Пароль PPPoE', 'PPPoE password', { show: g => g('proto') === 'pppoe' }), FX.t('mtu', 'MTU', 'MTU', { re: numRe })] },
  dns: { cfg: 'dhcp', type: 'dnsmasq', t: _('DNS-сервер (dnsmasq)', 'DNS server (dnsmasq)'),
    sum: s => [_('Основной DNS и DHCP', 'Main DNS and DHCP'), esc([].concat(s.server || []).join(', ') || _('DNS провайдера', 'ISP DNS'))],
    fields: [FX.l('server', 'Внешние DNS-серверы', 'Upstream DNS servers', { h: _('Например 1.1.1.1 или /example.com/8.8.8.8', 'E.g. 1.1.1.1 or /example.com/8.8.8.8') }), FX.t('domain', 'Локальный домен', 'Local domain'), FX.t('cachesize', 'Размер кэша', 'Cache size', { re: numRe }),
      FX.f('domainneeded', 'Не пересылать имена без домена', 'Require domain in queries', { def: 1 }), FX.f('boguspriv', 'Не пересылать частные адреса', 'Filter private reverse lookups', { def: 1 }), FX.f('rebind_protection', 'Защита от DNS-rebind', 'DNS rebind protection', { def: 1 }),
      FX.f('localise_queries', 'Локализовать ответы', 'Localise queries', { def: 1 }), FX.f('expandhosts', 'Добавлять домен к именам', 'Expand hostnames', { def: 1 }), FX.f('noresolv', 'Не читать resolv.conf', 'Ignore resolv.conf'), FX.f('authoritative', 'Авторитетный DHCP', 'Authoritative DHCP', { def: 1 })] },
  pool: { cfg: 'dhcp', type: 'dhcp', t: _('DHCP-серверы', 'DHCP servers'), skip: s => s.ignore === '1' && !s.start,
    sum: (s, k) => [esc(k), esc(s.ignore === '1' ? _('выключен', 'disabled') : `${_('с', 'from')} ${s.start || 100}, ${s.limit || 150} ${_('адресов', 'addresses')}, ${s.leasetime || '12h'}`)],
    fields: [FX.f('ignore', 'Отключить DHCP', 'Disable DHCP'), FX.t('start', 'Начало пула', 'Pool start', { re: numRe, show: g => !g('ignore') }), FX.t('limit', 'Размер пула', 'Pool size', { re: numRe, show: g => !g('ignore') }), FX.t('leasetime', 'Время аренды', 'Lease time', { p: '12h', re: /^\d+[smhdw]?$|^infinite$/, show: g => !g('ignore') }),
      FX.s('dhcpv6', 'DHCPv6', 'DHCPv6', [['', 'По умолчанию', 'Default'], ['disabled', 'Выкл', 'Off'], ['server', 'Сервер', 'Server'], ['relay', 'Ретранслятор', 'Relay'], ['hybrid', 'Гибрид', 'Hybrid']]), FX.s('ra', 'Router Advertisement', 'Router Advertisement', [['', 'По умолчанию', 'Default'], ['disabled', 'Выкл', 'Off'], ['server', 'Сервер', 'Server'], ['relay', 'Ретранслятор', 'Relay'], ['hybrid', 'Гибрид', 'Hybrid']])] },
  host: { cfg: 'dhcp', type: 'host', t: _('Закреплённые адреса (static leases)', 'Static leases'), add: 1, del: 1,
    sum: s => [esc(s.name || '—'), esc([].concat(s.mac || '')[0] + ' → ' + (s.ip || ''))],
    fields: [FX.t('name', 'Имя', 'Name'), FX.t('mac', 'MAC-адрес', 'MAC address', { req: 1, re: isMacRe, p: 'aa:bb:cc:dd:ee:ff' }), FX.t('ip', 'IP-адрес', 'IP address', { req: 1, re: isIpRe })] },
  domain: { cfg: 'dhcp', type: 'domain', t: _('Имена хостов', 'Hostnames'), add: 1, del: 1, sum: s => [esc(s.name || ''), esc(s.ip || '')], fields: [FX.t('name', 'Имя', 'Name', { req: 1 }), FX.t('ip', 'IP-адрес', 'IP address', { req: 1, re: isIpRe })] },
  route: { cfg: 'network', type: 'route', t: _('Статические маршруты', 'Static routes'), add: 1, del: 1, warn: _('Сеть перезапустится.', 'The network will restart.'),
    sum: s => [esc((s.target || '') + (s.netmask ? '/' + s.netmask : '')), esc(`${_('через', 'via')} ${s.gateway || '—'} (${s.interface || ''})`)],
    fields: [FX.t('interface', 'Интерфейс', 'Interface', { req: 1, p: 'lan' }), FX.t('target', 'Сеть назначения', 'Target', { req: 1 }), FX.t('netmask', 'Маска', 'Netmask', { p: '255.255.255.0' }), FX.t('gateway', 'Шлюз', 'Gateway'), FX.t('metric', 'Метрика', 'Metric', { re: numRe })] },
  fwdef: { cfg: 'firewall', type: 'defaults', t: _('Общие правила', 'General rules'), sum: () => [_('Политики по умолчанию', 'Default policies'), ''],
    fields: [FX.s('input', 'Входящие', 'Input', POL), FX.s('output', 'Исходящие', 'Output', POL), FX.s('forward', 'Пересылка', 'Forward', POL), FX.f('synflood_protect', 'Защита от SYN-flood', 'SYN-flood protection', { def: 1 })] },
  zone: { cfg: 'firewall', type: 'zone', t: _('Зоны', 'Zones'), add: 1, del: 1, sum: s => [esc(s.name || ''), esc(`${_('вход', 'in')}: ${s.input || ''} · ${_('выход', 'out')}: ${s.output || ''} · ${_('пересылка', 'fwd')}: ${s.forward || ''}`)],
    fields: [FX.t('name', 'Название', 'Name', { req: 1 }), FX.s('input', 'Входящие', 'Input', POL), FX.s('output', 'Исходящие', 'Output', POL), FX.s('forward', 'Пересылка', 'Forward', POL), FX.f('masq', 'NAT (маскарадинг)', 'Masquerading'), FX.f('mtu_fix', 'Подгонка MSS', 'MSS clamping'), FX.l('network', 'Интерфейсы', 'Networks')] },
  fwd: { cfg: 'firewall', type: 'forwarding', t: _('Пересылка между зонами', 'Zone forwarding'), add: 1, del: 1, sum: s => [esc((s.src || '') + ' → ' + (s.dest || '')), ''], fields: [FX.t('src', 'Из зоны', 'From zone', { req: 1 }), FX.t('dest', 'В зону', 'To zone', { req: 1 })] },
  rule: { cfg: 'firewall', type: 'rule', t: _('Правила трафика', 'Traffic rules'), add: 1, del: 1, skip: (s, k) => String(s.name || k).startsWith('rh_'),
    sum: s => [esc(s.name || '—'), esc(`${s.src || '*'} → ${s.dest || _('роутер', 'router')} · ${s.proto || 'any'} · ${s.target || 'ACCEPT'}${s.enabled === '0' ? ' · ' + _('выкл', 'off') : ''}`)],
    fields: [FX.t('name', 'Название', 'Name', { req: 1 }), FX.f('enabled', 'Включено', 'Enabled', { def: 1 }), FX.t('src', 'Зона источника', 'Source zone', { p: 'lan' }), FX.t('src_ip', 'IP источника', 'Source IP'), FX.t('src_mac', 'MAC источника', 'Source MAC', { re: isMacRe }), FX.t('src_port', 'Порт источника', 'Source port', { re: portRe }),
      FX.t('dest', 'Зона назначения (пусто = роутер)', 'Destination zone (empty = router)', { p: 'wan' }), FX.t('dest_ip', 'IP назначения', 'Destination IP'), FX.t('dest_port', 'Порт назначения', 'Destination port', { re: portRe }), FX.t('proto', 'Протокол', 'Protocol', { p: 'tcp udp' }), FX.s('target', 'Действие', 'Action', POL, { def: 'ACCEPT' }), FX.s('family', 'Семейство', 'Family', [['', 'Любое', 'Any'], ['ipv4', 'IPv4', 'IPv4'], ['ipv6', 'IPv6', 'IPv6']])] },
  redir: { cfg: 'firewall', type: 'redirect', t: _('Проброс портов', 'Port forwards'), add: 1, del: 1,
    sum: s => [esc(s.name || '—'), esc(`${s.proto || 'tcp'} :${s.src_dport || '?'} → ${s.dest_ip || ''}:${s.dest_port || s.src_dport || ''}${s.enabled === '0' ? ' · ' + _('выкл', 'off') : ''}`)],
    fields: [FX.t('name', 'Название', 'Name', { req: 1 }), FX.f('enabled', 'Включено', 'Enabled', { def: 1 }), FX.s('proto', 'Протокол', 'Protocol', [['tcp', 'TCP', 'TCP'], ['udp', 'UDP', 'UDP'], ['tcp udp', 'TCP+UDP', 'TCP+UDP']], { def: 'tcp' }), FX.t('src', 'Внешняя зона', 'External zone', { def: 'wan' }), FX.t('src_dport', 'Внешний порт', 'External port', { req: 1, re: portRe }),
      FX.t('dest', 'Внутренняя зона', 'Internal zone', { def: 'lan' }), FX.t('dest_ip', 'IP устройства', 'Device IP', { req: 1, re: isIpRe }), FX.t('dest_port', 'Порт устройства', 'Device port', { re: portRe }), FX.s('target', 'Тип', 'Type', [['DNAT', 'DNAT', 'DNAT'], ['SNAT', 'SNAT', 'SNAT']], { def: 'DNAT' })] },
  drop: { cfg: 'dropbear', type: 'dropbear', t: _('SSH-сервер (Dropbear)', 'SSH server (Dropbear)'), sum: s => [`SSH :${esc(s.Port || 22)}`, esc(s.Interface || _('все интерфейсы', 'all interfaces'))],
    fields: [FX.t('Port', 'Порт', 'Port', { re: numRe, def: '22' }), FX.t('Interface', 'Интерфейс (пусто = все)', 'Interface (empty = all)'), FX.f('PasswordAuth', 'Вход по паролю', 'Password login', { onoff: 1, def: 1 }), FX.f('RootPasswordAuth', 'Вход root по паролю', 'Root password login', { onoff: 1, def: 1 })] },
  ntp: { cfg: 'system', type: 'timeserver', t: _('Синхронизация времени (NTP)', 'Time sync (NTP)'), sum: s => [_('NTP-клиент', 'NTP client'), esc([].concat(s.server || []).join(', '))],
    fields: [FX.f('enabled', 'Включено', 'Enabled', { def: 1 }), FX.f('enable_server', 'Работать как NTP-сервер', 'Act as NTP server'), FX.l('server', 'Серверы', 'Servers')] },
  pkSet: { cfg: () => K.pkg, type: 'settings', t: _('Общие настройки', 'General settings'), sum: () => [esc(K.pkg || ''), _('DNS, интерфейсы, списки', 'DNS, interfaces, lists')],
    fields: [FX.s('dns_type', 'Протокол DNS', 'DNS protocol', [['doh', 'DoH', 'DoH'], ['dot', 'DoT', 'DoT'], ['udp', 'UDP', 'UDP']], { def: 'doh', core: 1, custom: 1 }), FX.t('dns_server', 'DNS-сервер', 'DNS server', { core: 1, p: '1.1.1.1' }), FX.t('bootstrap_dns_server', 'Bootstrap DNS', 'Bootstrap DNS', { core: 1, p: '77.88.8.8', h: _('Нужен, чтобы найти адрес основного DNS, если он задан именем', 'Used to resolve the main DNS name if it is not an IP') }), FX.t('dns_rewrite_ttl', 'TTL DNS-записей, с', 'DNS rewrite TTL, s', { core: 1, re: numRe, def: '60' }),
      FX.l('source_network_interfaces', 'Интерфейсы-источники', 'Source interfaces', { opt: 1 }), FX.f('enable_output_network_interface', 'Свой выходной интерфейс', 'Custom output interface', { opt: 1 }), FX.t('output_network_interface', 'Выходной интерфейс', 'Output interface', { opt: 1, show: g => g('enable_output_network_interface') }),
      FX.f('enable_badwan_interface_monitoring', 'Следить за WAN', 'Monitor bad WAN', { opt: 1 }), FX.l('badwan_monitored_interfaces', 'Контролируемые интерфейсы', 'Monitored interfaces', { opt: 1, show: g => g('enable_badwan_interface_monitoring') }),
      FX.f('disable_quic', 'Отключить QUIC', 'Disable QUIC', { opt: 1 }), FX.f('download_lists_via_proxy', 'Скачивать списки через прокси', 'Download lists via proxy', { opt: 1 }), FX.t('download_lists_via_proxy_section', 'Раздел для скачивания', 'Section for downloads', { opt: 1, show: g => g('download_lists_via_proxy') }),
      FX.f('dont_touch_dhcp', 'Не менять DHCP', "Don't touch DHCP", { opt: 1 }), FX.f('enable_yacd', 'Панель YACD', 'YACD dashboard', { opt: 1 }), FX.f('exclude_ntp', 'Исключить NTP', 'Exclude NTP', { opt: 1 }), FX.t('update_interval', 'Обновление списков', 'List update interval', { opt: 1 })] },
  pkSec: { cfg: () => K.pkg, type: 'section', t: _('Разделы маршрутизации', 'Routing sections'), add: 1, del: 1, named: 1, warn: _('После сохранения сервис перезапустится.', 'The service will restart after saving.'),
    sum: (s, k) => [esc(k), esc(`${L.connName(s.connection_type || 'proxy', lang === 'ru')}${(s.connection_type || 'proxy') === 'proxy' && s.proxy_config_type ? ' · ' + L.modeName(s.proxy_config_type, lang === 'ru') : ''} · ${[].concat(s.community_lists || []).length} ${_('списков', 'lists')}${s.rh_note ? ' · 🔗' : ''}`)],
    fields: [FX.s('connection_type', 'Способ подключения', 'Connection method', [['proxy', 'Прокси', 'Proxy'], ['vpn', 'VPN-интерфейс', 'VPN interface'], ['block', 'Блокировать', 'Block'], ['exclusion', 'Исключение (напрямую)', 'Exclusion (direct)']], { def: 'proxy', core: 1, custom: 1 }),
      FX.s('proxy_config_type', 'Способ задания ключа', 'Key mode', [['url', 'Один ключ', 'Single key'], ['selector', 'Выбор из списка', 'Selector'], ['urltest', 'Авто (лучший)', 'Auto (best)'], ['outbound', 'JSON outbound', 'JSON outbound']], { def: 'url', custom: 1, show: g => g('connection_type') === 'proxy' }),
      FX.t('proxy_string', 'Ключ (vless:// ...)', 'Key (vless:// ...)', { show: g => g('connection_type') === 'proxy' && g('proxy_config_type') === 'url' }), FX.l('selector_proxy_links', 'Ключи для выбора', 'Selector keys', { show: g => g('connection_type') === 'proxy' && g('proxy_config_type') === 'selector' }), FX.l('urltest_proxy_links', 'Ключи для авто-выбора', 'Auto-select keys', { show: g => g('connection_type') === 'proxy' && g('proxy_config_type') === 'urltest' }),
      { o: 'outbound_json', t: 'area', l: 'JSON outbound', rows: 6, show: g => g('connection_type') === 'proxy' && g('proxy_config_type') === 'outbound' },
      FX.t('interface', 'Интерфейс VPN', 'VPN interface', { p: 'wg0 / tun0', show: g => g('connection_type') === 'vpn' }), FX.f('domain_resolver_enabled', 'Свой DNS для доменов', 'Custom domain resolver', { show: g => g('connection_type') === 'vpn' }),
      FX.s('domain_resolver_dns_type', 'Протокол DNS', 'DNS protocol', [['udp', 'UDP', 'UDP'], ['doh', 'DoH', 'DoH'], ['dot', 'DoT', 'DoT']], { show: g => g('connection_type') === 'vpn' && g('domain_resolver_enabled') }), FX.t('domain_resolver_dns_server', 'DNS-сервер', 'DNS server', { show: g => g('connection_type') === 'vpn' && g('domain_resolver_enabled') }),
      { o: 'community_lists', t: 'multi', l: _('Готовые списки', 'Community lists'), opts: L.COMMUNITY.map(c => [c[0], _(c[1], c[2])]), excl: L.REGIONAL },
      FX.s('user_domain_list_type', 'Свои домены', 'Custom domains', [['disabled', 'Выкл', 'Off'], ['dynamic', 'Списком', 'List'], ['text', 'Текстом', 'Text']], { def: 'disabled' }), FX.l('user_domains', 'Домены', 'Domains', { show: g => g('user_domain_list_type') === 'dynamic' }), { o: 'user_domains_text', t: 'area', l: _('Домены (через пробел, запятую или строки; // комментарий)', 'Domains (space, comma or lines; // comment)'), rows: 5, show: g => g('user_domain_list_type') === 'text' },
      FX.s('user_subnet_list_type', 'Свои подсети', 'Custom subnets', [['disabled', 'Выкл', 'Off'], ['dynamic', 'Списком', 'List'], ['text', 'Текстом', 'Text']], { def: 'disabled' }), FX.l('user_subnets', 'Подсети', 'Subnets', { show: g => g('user_subnet_list_type') === 'dynamic' }), { o: 'user_subnets_text', t: 'area', l: _('Подсети (через пробел, запятую или строки)', 'Subnets (space, comma or lines)'), rows: 5, show: g => g('user_subnet_list_type') === 'text' },
      FX.l('remote_domain_lists', 'Удалённые списки доменов (URL)', 'Remote domain lists (URL)', { opt: 1 }), FX.l('remote_subnet_lists', 'Удалённые списки подсетей (URL)', 'Remote subnet lists (URL)', { opt: 1 }), FX.l('local_domain_lists', 'Локальные файлы доменов', 'Local domain files', { opt: 1 }), FX.l('local_subnet_lists', 'Локальные файлы подсетей', 'Local subnet files', { opt: 1 }),
      FX.l('subscription_url', 'Ссылки-подписки (NetShift)', 'Subscription URLs (NetShift)', { opt: 1 })] }
});
const CV = {};
const cfgOf = sp => (typeof sp.cfg === 'function' ? sp.cfg() : sp.cfg);
async function loadCfgs(names) { await Promise.all(names.map(async n => { CV[n] = await U.get(n).catch(() => ({})); })); }
function cfgCard(id) {
  const sp = SPEC()[id], vals = CV[cfgOf(sp)] || {};
  const keys = Object.keys(vals).filter(k => sid(k) && vals[k]['.type'] === sp.type && !(sp.skip && sp.skip(vals[k], k)));
  const rows = keys.map(k => { const r = sp.sum(vals[k], k); return H.row(r[0], r[1], `<button class="s" onclick="cfgEdit('${id}','${k}')">✏️</button>${sp.del ? `<button class="s d" onclick="cfgDel('${id}','${k}')">🗑</button>` : ''}`); }).join('');
  return H.card(sp.t, (rows || `<div class=sub style="margin:0 0 6px">${_('Пусто', 'Empty')}</div>`) + (sp.add ? `<button style="margin-top:8px" onclick="cfgAdd('${id}')">➕ ${_('Добавить', 'Add')}</button>` : ''));
}
function schFields(sp, sec, isNew) {
  const fs = [];
  if (isNew && sp.named) fs.push({ k: '__name', t: 'text', l: _('Имя (латиница, цифры, _)', 'Name (letters, digits, _)'), v: '' });
  sp.fields.forEach(f => {
    if (f.opt && sec && !(f.o in sec)) return;
    const has = sec && sec[f.o] !== undefined, raw = has ? sec[f.o] : (f.def !== undefined ? f.def : '');
    const x = { k: f.o, l: f.l, h: f.h, p: f.p, show: f.show, rows: f.rows, custom: f.custom };
    if (f.t === 'check') { x.t = 'check'; x.v = f.onoff ? (has ? raw !== 'off' : !!f.def) : (has ? (raw === '1' || raw === 'true' || raw === 'on') : !!f.def); }
    else if (f.t === 'list') { x.t = 'area'; x.v = [].concat(raw).join('\n'); }
    else if (f.t === 'select') { x.t = 'select'; x.v = String(raw); x.o = f.opts.slice(); if (x.v && !x.o.some(o => o[0] === x.v)) x.o.push([x.v, x.v]); }
    else if (f.t === 'multi') { x.t = 'multi'; x.o = f.opts; x.v = [].concat(raw || []); x.excl = f.excl; }
    else { x.t = f.t === 'password' ? 'password' : f.t === 'area' ? 'area' : 'text'; x.v = String(raw); }
    fs.push(x);
  });
  return fs;
}
async function schSave(sp, secName, isNew, fields, vals, vis) {
  const idx = {}; fields.forEach((f, i) => { idx[f.k] = i; });
  const set = {}, del = [];
  for (const f of sp.fields) {
    const i = idx[f.o]; if (i === undefined || !vis[i]) continue;
    let v = vals[i];
    if (f.t === 'check') { set[f.o] = f.onoff ? (v ? 'on' : 'off') : (v ? '1' : '0'); continue; }
    if (f.t === 'multi') { if (v.length) set[f.o] = v; else del.push(f.o); continue; }
    if (f.t === 'list') {
      const a = v.split('\n').map(x => x.trim()).filter(Boolean);
      if (f.re && !a.every(x => f.re.test(x))) throw new Error(f.l + ': ' + _('неверный формат', 'invalid format'));
      if (a.length) set[f.o] = a; else del.push(f.o); continue;
    }
    v = String(v).trim();
    if (f.req && !v) throw new Error(f.l + ': ' + _('обязательное поле', 'required'));
    if (f.re && v && !f.re.test(v)) throw new Error(f.l + ': ' + _('неверный формат', 'invalid format'));
    if (v === '') del.push(f.o); else set[f.o] = v;
  }
  const cfg = cfgOf(sp);
  if (isNew) {
    let name; if (sp.named) { name = String(vals[idx.__name] || '').trim(); if (!L.okName(name)) throw new Error(_('Неверное имя', 'Invalid name')); if (CV[cfg] && CV[cfg][name]) throw new Error(_('Такое имя уже есть', 'Name already exists')); }
    await U.add(cfg, sp.type, name, set);
  } else {
    if (Object.keys(set).length) await U.set(cfg, secName, set);
    if (del.length) await U.del(cfg, secName, del).catch(() => { });
  }
  await applySafe(cfg);
}
function cfgEdit(id, k) {
  const sp = SPEC()[id], cfg = cfgOf(sp), sec = (CV[cfg] || {})[k]; if (!sec) return;
  const fs = schFields(sp, sec, false);
  form(sp.t + ' · ' + k, fs, async (v, vis) => { await schSave(sp, k, false, fs, v, vis); setTimeout(() => go(page, arg), 300); }, '', sp.warn);
}
function cfgAdd(id) {
  const sp = SPEC()[id], fs = schFields(sp, null, true);
  form(_('Добавить', 'Add') + ' · ' + sp.t, fs, async (v, vis) => { await schSave(sp, null, true, fs, v, vis); setTimeout(() => go(page, arg), 300); }, '', sp.warn);
}
async function cfgDel(id, k) {
  const sp = SPEC()[id], cfg = cfgOf(sp);
  if (!await ask(_('Удалить?', 'Delete?'), k, _('Удалить', 'Delete'), true)) return;
  try { await U.del(cfg, k); await applySafe(cfg); } catch (e) { toast(e.message); }
  go(page, arg);
}
// ====== LuCI hub ======
const mi = (ic, lb, ds, fn) => `<button class=hub onclick="${fn}"><span>${ic}</span><b>${lb}</b><small>${ds}</small></button>`;
P.set = async () => {
  const grp = (t, items) => `<div class=gt>${t}</div><div class=hubs>${items.join('')}</div>`;
  V(H.hd('LuCI') + `<div class=sub style="margin-top:-6px">${_('Все настройки роутера в удобном виде. Как веб-интерфейс, только в приложении.', 'All router settings in a friendly layout. Like the web UI, but in the app.')}</div>` +
    grp(_('Статус', 'Status'), [mi('📊', _('Обзор', 'Overview'), _('Интерфейсы, система', 'Interfaces, system'), "go('ov')"), mi('📜', _('Журнал', 'System log'), _('Сообщения системы', 'System messages'), "go('logs')"), mi('🧮', _('Процессы', 'Processes'), _('Что запущено', 'What is running'), "go('procs')"), mi('🩺', _('Самопроверка', 'Self-test'), _('Всё ли работает', 'Does everything work'), "go('selftest')")]) +
    grp(_('Система', 'System'), [mi('🖥️', _('Система', 'System'), _('Имя, время, питание', 'Name, time, power'), "go('sys')"), mi('🔑', _('Администрирование', 'Administration'), _('Пароль, SSH-доступ', 'Password, SSH access'), "go('admin')"), mi('🧩', _('Программы', 'Software'), _('Плагины, пакеты, обновления', 'Plugins, packages, updates'), "go('pkgs')"), mi('🛟', _('Резервные копии', 'Backups'), _('Откат настроек', 'Restore settings'), "go('bk')"), mi('⚙️', _('Автозапуск', 'Startup'), _('Службы', 'Services'), "go('svc')"), mi('⏱️', _('Планировщик', 'Scheduled tasks'), 'cron', "go('cron')")]) +
    grp(_('Сеть', 'Network'), [mi('🔌', _('Интерфейсы', 'Interfaces'), 'LAN, WAN', "go('ifs')"), mi('📶', 'Wi-Fi', _('Сети и каналы', 'Networks and channels'), "go('wifi')"), mi('🌐', _('DHCP и DNS', 'DHCP & DNS'), _('Адреса, имена', 'Leases, names'), "go('dhcp')"), mi('🧭', _('Маршруты', 'Routing'), _('Статические маршруты', 'Static routes'), "go('routes')"), mi('🛡️', _('Брандмауэр', 'Firewall'), _('Порты, правила, зоны', 'Ports, rules, zones'), "go('fw')"), mi('🩺', _('Диагностика', 'Diagnostics'), 'ping, traceroute', "go('diag')")]) +
    grp(_('Службы и инструменты', 'Services & tools'), [mi('🛰️', 'Podkop', _('Маршрутизация трафика', 'Traffic routing'), "go('pk')"), mi('📦', _('Приложения', 'Apps'), _('Установленные LuCI-приложения', 'Installed LuCI apps'), "go('apps')"), mi('⌨️', 'SSH', _('Терминал', 'Terminal'), "go('ssh')"), mi('🛠', _('Редактор UCI', 'UCI editor'), _('Любой параметр', 'Any option'), "go('uci')"), mi('🌍', _('Веб-LuCI', 'Web LuCI'), _('Полный веб-интерфейс', 'Full web interface'), 'openLuci()')]));
};
// ====== Pages ======
const age = s => { const t = L.dur(s); return (t.d ? t.d + _('д ', 'd ') : '') + t.h + _('ч ', 'h ') + t.m + _('м', 'm'); };
async function ifaceCard() {
  let l = []; try { l = L.parseIfaces(await out('ubus call network.interface dump 2>/dev/null')); } catch (e) { }
  return H.card(_('Состояние', 'Status'), l.map(i => H.row(`<span class="dot ${i.up ? 'on' : ''}"></span>${esc(i.name)}`, esc(`${i.proto} · ${i.dev} · ${i.ip ? i.ip + '/' + i.mask : '—'}${i.dns.length ? ' · DNS ' + i.dns.join(', ') : ''}`), i.up ? `<span class="chip ok">${age(i.uptime)}</span>` : `<span class="chip bad">${_('выкл', 'down')}</span>`)).join('') || `<div class=sub>—</div>`);
}
P.ov = async () => {
  const b = await getBoard(); await homeRefresh(b); const d = HS.d;
  const x = L.sections(await out("echo '##C'; cat /proc/sys/net/netfilter/nf_conntrack_count 2>/dev/null; echo '##W'; for i in $(iw dev 2>/dev/null | awk '$1==\"Interface\"{print $2}'); do iw dev $i station dump 2>/dev/null | grep -c '^Station'; done; true"));
  const wc = (x.W || '').split('\n').map(Number).filter(n => !isNaN(n) && n > 0).reduce((a, c) => a + c, 0);
  V(H.hd(_('Обзор', 'Overview'), 'set') + wHero(d) + H.card(_('Система', 'System'), H.row(_('Модель', 'Model'), esc(d.b.model), '') + H.row(_('Прошивка', 'Firmware'), esc((d.b.release || {}).description || ''), '') + H.row(_('Ядро', 'Kernel'), esc(d.b.kernel || ''), '') + H.row(_('Нагрузка', 'Load'), d.l.map(v => v.toFixed(2)).join(' / '), '') + H.row(_('Память', 'Memory'), `${Math.round((d.memT - d.memA) / 1024)} / ${Math.round(d.memT / 1024)} MB`, '') + H.row(_('Соединений', 'Connections'), esc((x.C || '').trim() || '—'), '') + H.row(_('Клиентов Wi-Fi', 'Wi-Fi clients'), String(wc), '')) + await ifaceCard());
};
P.ifs = async () => { await loadCfgs(['network']); V(H.hd(_('Интерфейсы', 'Interfaces'), 'set') + await ifaceCard() + cfgCard('ifs')); };
P.dhcp = async () => { await loadCfgs(['dhcp']); V(H.hd(_('DHCP и DNS', 'DHCP & DNS'), 'set') + cfgCard('dns') + cfgCard('pool') + cfgCard('host') + cfgCard('domain')); };
P.routes = async () => {
  await loadCfgs(['network']); const t = await out('ip route 2>/dev/null; echo; ip -4 neigh 2>/dev/null');
  V(H.hd(_('Маршруты', 'Routing'), 'set') + cfgCard('route') + H.card(_('Таблица маршрутов и соседей', 'Routing table and neighbours'), `<pre class=jl>${esc(t)}</pre>`));
};
const FWT = { tab: 'g' };
P.fw = async () => {
  await loadCfgs(['firewall']); const t = FWT.tab;
  V(H.hd(_('Брандмауэр', 'Firewall'), 'set') + H.seg([['g', _('Общие', 'General')], ['p', _('Порты', 'Ports')], ['r', _('Правила', 'Rules')]], t, 'fwTab') + (t === 'g' ? cfgCard('fwdef') + cfgCard('zone') + cfgCard('fwd') : t === 'p' ? cfgCard('redir') : cfgCard('rule')));
};
function fwTab(k) { FWT.tab = k; go('fw'); }
const DG = { tool: 'ping' };
P.diag = async () => {
  V(H.hd(_('Диагностика', 'Diagnostics'), 'set') + H.card('', `<label class=fl>${_('Инструмент', 'Tool')}</label><select id=dgt><option value=ping>ping</option><option value=traceroute>traceroute</option><option value=nslookup>nslookup</option></select><label class=fl>${_('Адрес или имя', 'Address or name')}</label><input type=text id=dgh value="1.1.1.1" autocapitalize=off><button class=p onclick="diagRun()">▶ ${_('Запустить', 'Run')}</button>`) + H.card(_('Результат', 'Output'), `<pre id=dg class=jl style="max-height:50vh">—</pre>`));
};
async function diagRun() {
  const t = $('#dgt').value, h = $('#dgh').value.trim();
  if (!/^[A-Za-z0-9._:-]+$/.test(h) || h.length > 120) return toast(_('Неверный адрес', 'Invalid address'));
  const cmd = { ping: `ping -c 4 -W 2 ${h}`, traceroute: `traceroute -w 2 -m 15 ${h}`, nslookup: `nslookup ${h}` }[t]; if (!cmd) return;
  $('#dg').textContent = '…';
  await job(cmd, x => { const e = $('#dg'); if (e) e.textContent = x.replace(/##EXIT.*/, ''); });
}
P.cron = async () => {
  const t = await out('cat /etc/crontabs/root 2>/dev/null');
  V(H.hd(_('Планировщик', 'Scheduled tasks'), 'set') + H.card('', `<div class=sub style="margin:0 0 8px">${_('Формат: минута час день месяц день_недели команда. Одна задача в строке.', 'Format: minute hour day month weekday command. One job per line.')}</div><textarea id=ct rows=10 spellcheck=false autocapitalize=off>${esc(t)}</textarea><button class=p onclick="cronSave()">${_('Сохранить', 'Save')}</button>`));
};
async function cronSave() {
  const t = $('#ct').value.replace(/\r/g, '').replace(/\s+$/, '');
  try { await sh(`printf '%s\\n' ${L.shq(t)} > /etc/crontabs/root; /etc/init.d/cron restart >/dev/null 2>&1; true`); toast(_('Сохранено', 'Saved')); } catch (e) { toast(e.message); }
}
P.admin = async () => {
  await loadCfgs(['dropbear']); const k = await out('cat /etc/dropbear/authorized_keys 2>/dev/null');
  V(H.hd(_('Администрирование', 'Administration'), 'set') + H.card('', H.row(_('Пароль root', 'Root password'), '', '✏️', 'pwEdit()')) + cfgCard('drop') + H.card(_('Ключи SSH (authorized_keys)', 'SSH keys (authorized_keys)'), `<textarea id=ak rows=5 spellcheck=false autocapitalize=off>${esc(k)}</textarea><button class=p style="margin-top:8px" onclick="akSave()">${_('Сохранить', 'Save')}</button>`));
};
async function akSave() {
  const t = $('#ak').value.replace(/\r/g, '').replace(/\s+$/, '');
  try { await sh(`mkdir -p /etc/dropbear; printf '%s\\n' ${L.shq(t)} > /etc/dropbear/authorized_keys; chmod 600 /etc/dropbear/authorized_keys; true`); toast(_('Сохранено', 'Saved')); } catch (e) { toast(e.message); }
}
const PS = { q: '', t: '' };
P.procs = async () => {
  V(H.hd(_('Процессы', 'Processes'), 'set') + `<input type=text id=pq placeholder="🔎 ${_('Поиск', 'Search')}" value="${esc(PS.q)}" oninput="PS.q=this.value;psDraw()"><div id=pl></div>`);
  await psLoad(); timer = setInterval(() => { psLoad().catch(() => { }); }, 5000);
};
async function psLoad() { PS.t = await out('ps 2>/dev/null'); psDraw(); }
function psDraw() {
  const e = $('#pl'); if (!e) return; const q = PS.q.toLowerCase();
  e.innerHTML = L.parsePs(PS.t).filter(p => !q || (p.cmd + p.user).toLowerCase().includes(q)).slice(0, 80).map(p => `<div class=svc><div class=dm><b>${esc(p.cmd.slice(0, 60))}</b><small>PID ${p.pid} · ${esc(p.user)} · ${esc(p.vsz)} · ${esc(p.stat)}</small></div><button class="s d" onclick="psKill(${p.pid})">✖</button></div>`).join('');
}
async function psKill(pid) { if (!(pid > 1)) return; if (await ask(_('Завершить процесс?', 'Kill process?'), 'PID ' + pid, _('Завершить', 'Kill'), true)) { await sh(`kill ${pid | 0}; true`); await sleep(500); await psLoad(); } }
const APPCFG = { sqm: 'sqm', nlbwmon: 'nlbwmon', upnp: 'upnpd', ddns: 'ddns', 'adblock-fast': 'adblock-fast', adblock: 'adblock', banip: 'banip', statistics: 'luci_statistics', samba4: 'samba4', wol: 'etherwake', commands: 'luci', watchcat: 'watchcat', mwan3: 'mwan3', openvpn: 'openvpn', zerotier: 'zerotier', 'hd-idle': 'hd-idle', acme: 'acme', 'https-dns-proxy': 'https-dns-proxy', vnstat2: 'vnstat', transmission: 'transmission', minidlna: 'minidlna', smartdns: 'smartdns', ttyd: 'ttyd', socat: 'socat', attendedsysupgrade: 'attendedsysupgrade', homeproxy: 'homeproxy', ksmbd: 'ksmbd' };
P.apps = async () => {
  const inst = await installed(), cfgs = (await out('ls /etc/config 2>/dev/null')).split('\n').map(x => x.trim());
  const apps = Object.keys(inst).filter(n => n.startsWith('luci-app-')).map(n => n.slice(9)).sort();
  V(H.hd(_('Приложения', 'Apps'), 'set') + H.card('', apps.map(a => {
    const c = APPCFG[a] || a, own = ['podkop', 'forkop', 'netshift'].includes(a), hasCfg = cfgs.includes(c);
    return H.row(esc(a), own ? _('Свой экран в приложении', 'Has its own screen') : hasCfg ? `${_('Конфиг', 'Config')}: ${esc(c)}` : '', (own ? `<button class="s p" onclick="go('pk')">${_('Открыть', 'Open')}</button>` : hasCfg && sid(c) ? `<button class="s" onclick="go('uci','${c}')">⚙️</button>` : '') + `<button class="s" onclick="openLuci()">🌍</button>`);
  }).join('') || `<div class=sub>${_('LuCI-приложения не найдены', 'No LuCI apps found')}</div>`) + H.card('', `<button class=p onclick="go('pkgs')">🧩 ${_('Установить плагины', 'Install plugins')}</button>`));
};

// ====== Self-test, backups, app log ======
const STC = () => [
  { t: _('Команды на роутере', 'Running commands on the router'), run: async () => { const o = await out('echo RH_OK'); return { ok: o.includes('RH_OK') }; }, hint: _('Нужна подготовка роутера (Ещё → Подготовка роутера).', 'Router setup is needed (More → Router setup).') },
  { t: _('Фоновые задачи', 'Background jobs'), run: async () => { const c = await job('echo bg-ok', null); return { ok: c === 0 }; }, hint: _('Установка и обновления не смогут работать в фоне.', 'Installs and updates cannot run in the background.') },
  { t: _('Менеджер пакетов', 'Package manager'), run: async () => { const p = await pm(), o = await out(p === 'apk' ? 'apk --version 2>&1' : 'opkg --version 2>&1'); return { ok: o.trim().length > 0, info: p + ' ' + o.trim().slice(0, 40) }; }, hint: '' },
  { t: _('Интернет (ping)', 'Internet (ping)'), run: async () => ({ ok: (await out('ping -c1 -W3 1.1.1.1 >/dev/null 2>&1 && echo ok')).includes('ok') }), hint: _('Роутер не выходит в интернет: установка пакетов не получится.', 'The router has no internet: package installs will not work.') },
  { t: _('DNS', 'DNS'), run: async () => ({ ok: (await out('nslookup openwrt.org >/dev/null 2>&1 && echo ok')).includes('ok') }), hint: _('Не работает разрешение имён. Проверьте DNS в «DHCP и DNS».', 'Name resolution fails. Check DNS in "DHCP & DNS".') },
  { t: _('Загрузка по HTTPS', 'HTTPS download'), run: async () => ({ ok: (await out('(wget -q -T 8 -O /dev/null https://downloads.openwrt.org/ || curl -sI -m 8 https://downloads.openwrt.org/) >/dev/null 2>&1 && echo ok')).includes('ok') }), hint: _('Установите ca-bundle и curl (Программы → Плагины → Утилиты).', 'Install ca-bundle and curl (Software → Plugins → Utilities).') },
  { t: 'GitHub', run: async () => ({ ok: (await out('(wget -q -T 8 -O /dev/null https://api.github.com/ || curl -sI -m 8 https://api.github.com/) >/dev/null 2>&1 && echo ok')).includes('ok') }), warn: 1, hint: _('Роутер не достаёт GitHub (нужно для обновления Podkop с роутера). Телефон загрузит подписки сам.', 'The router cannot reach GitHub (needed to update Podkop from the router). The phone fetches subscriptions itself.') },
  { t: 'curl', run: async () => ({ ok: (await out('command -v curl')).trim().length > 0 }), warn: 1, hint: _('Не обязателен, но ускоряет загрузки.', 'Optional but speeds up downloads.') },
  { t: _('Свободное место', 'Free space'), run: async () => { const k = +((await out("df -k /overlay 2>/dev/null | awk 'NR==2{print $4}'")).trim() || 0); return { ok: k > 2048 || k === 0, info: k ? Math.round(k / 1024) + ' MB' : '' }; }, hint: _('Мало места: удалите ненужные пакеты.', 'Low space: remove unneeded packages.') },
  { t: 'iw / etherwake', run: async () => { const a = (await out('command -v iw')).trim(), b = (await out('command -v etherwake')).trim(); return { ok: !!a, info: (a ? 'iw ✓' : 'iw ✗') + ' · ' + (b ? 'etherwake ✓' : 'etherwake ✗') }; }, warn: 1, hint: _('etherwake поставится автоматически, когда понадобится.', 'etherwake is installed automatically when needed.') },
  { t: _('Дата и время', 'Date and time'), run: async () => { const y = +(await out('date +%Y')).trim(); return { ok: y >= 2024, info: String(y) }; }, warn: 1, hint: _('Время сбито: HTTPS и пакеты могут не работать. Синхронизируйте время в «Система».', 'Clock is wrong: HTTPS and packages may fail. Sync time under "System".') }
];
const ST = { res: [], run: false };
P.selftest = async () => {
  ST.res = [];
  V(H.hd(_('Самопроверка', 'Self-test'), 'set') + `<div class=sub style="margin-top:-6px">${_('Проверяю, что на роутере работает всё, что нужно приложению.', 'Checking that everything the app needs works on the router.')}</div><div id=stl></div><div id=stt></div>`);
  const list = STC();
  for (let i = 0; i < list.length; i++) {
    let r; try { r = await list[i].run(); } catch (e) { r = { ok: false, info: e.message }; }
    ST.res.push({ t: list[i].t, ok: r.ok, warn: list[i].warn, info: r.info || '', hint: r.ok ? '' : list[i].hint });
    if (page !== 'selftest') return;
    const el = $('#stl'); if (el) el.innerHTML = H.card('', ST.res.map(x => H.row(`${x.ok ? '✅' : x.warn ? '⚠️' : '❌'} ${esc(x.t)}`, esc((x.info ? x.info + ' ' : '') + x.hint), '')).join('') + (ST.res.length < list.length ? `<div class=sub>…</div>` : ''));
  }
  const bad = ST.res.filter(x => !x.ok && !x.warn).length, warn = ST.res.filter(x => !x.ok && x.warn).length;
  const rep = ST.res.map(x => `${x.ok ? 'OK ' : x.warn ? 'WARN' : 'FAIL'} ${x.t} ${x.info}`).join('\n');
  alog('selftest', rep.replace(/\n/g, ' | '));
  const e = $('#stt'); if (e) e.innerHTML = H.card('', `<div class=sub style="margin:0 0 8px">${bad ? '❌ ' + _('Есть проблемы: ', 'Problems: ') + bad : '✅ ' + _('Критичных проблем нет.', 'No critical problems.')}${warn ? ' · ⚠️ ' + warn : ''}</div><textarea rows=6 readonly spellcheck=false>${esc(rep)}</textarea><button style="margin-top:8px" onclick="go('selftest')">🔄 ${_('Проверить ещё раз', 'Run again')}</button>`);
};
P.bk = async () => {
  const files = (await out('ls -t /root/routerhub-backup 2>/dev/null')).split('\n').map(x => x.trim()).filter(x => /^[\w-]+\.\d{8}-\d{6}$/.test(x));
  V(H.hd(_('Резервные копии', 'Backups'), 'set') + H.card('', `<div class=sub style="margin:0">${_('Перед каждым изменением приложение копирует настройки в /root/routerhub-backup (хранятся последние 10 копий каждого файла). Отсюда можно вернуть любую.', 'Before every change the app copies the settings to /root/routerhub-backup (the last 10 copies of each file are kept). You can restore any of them here.')}</div>`) +
    H.card(_('Копии', 'Copies'), files.slice(0, 60).map(f => { const m = f.match(/^([\w-]+)\.(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})$/); return H.row(esc(m[1]), `${m[4]}.${m[3]}.${m[2]} ${m[5]}:${m[6]}`, `<button class="s" onclick="restoreCfg('${f}')">↩ ${_('Вернуть', 'Restore')}</button>`); }).join('') || `<div class=sub>${_('Пока нет копий', 'No copies yet')}</div>`));
};
async function restoreCfg(f) {
  const m = String(f).match(/^([\w-]+)\.\d{8}-\d{6}$/); if (!m) return;
  const c = m[1];
  if (!await ask(_('Вернуть настройки?', 'Restore settings?'), `${c} · ${f.slice(c.length + 1)}`, _('Вернуть', 'Restore'), true)) return;
  try {
    await backupCfg(c);
    if (RISKY.includes(c)) { const u = await armUndo(c); await sh(`cp -f /root/routerhub-backup/${f} /etc/config/${c}\n${RELOAD[c]}\ntrue`); confirmSheet(u.id, c, u.undo); }
    else { await sh(`cp -f /root/routerhub-backup/${f} /etc/config/${c}\n${RELOAD[c] || 'reload_config'}\ntrue`); toast('↩ ' + _('Настройки возвращены', 'Settings restored')); }
  } catch (e) { toast(e.message); }
}
P.applog = async () => {
  const t = ALOG.slice().reverse().map(x => `${x.t} [${x.k}] ${x.x}`).join('\n') || '—';
  V(H.hd(_('Журнал приложения', 'App log'), 'more') + H.card('', `<div class=sub style="margin:0 0 8px">${_('Здесь видно, что делало приложение и какие были ошибки. Если что-то не работает, пришлите этот текст.', 'Shows what the app did and any errors. If something does not work, send this text.')}</div><textarea rows=14 readonly spellcheck=false>${esc(t)}</textarea><button style="margin-top:8px" onclick="ALOG.length=0;go('applog')">${_('Очистить', 'Clear')}</button>`));
};
