'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
};
let lang = LS.get('lang', 'ru');
const _ = (ru, en) => (lang === 'en' && en !== undefined ? en : ru);
let rs = [], cur = LS.get('cur', 0), page = 'home', arg = null, timer = null, CBK = null, PM = null, FS = null, SSHK = null;
const R = () => rs[cur];
const V = h => { $('#v').innerHTML = h; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
function toast(t) { const e = $('#toast'); e.textContent = t; e.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => { e.style.display = 'none'; }, 2600); }
const saveRs = () => { Native.secSet('rs', JSON.stringify(rs)); LS.set('cur', cur); };

// ---------------- action log & visible errors ----------------
const ALOG = [];
function alog(k, t) { ALOG.push({ t: new Date().toTimeString().slice(0, 8), k, x: String(t).slice(0, 400) }); if (ALOG.length > 150) ALOG.shift(); }
function reportErr(e) { const m = e && e.message ? e.message : String(e); alog('error', m); toast('⚠️ ' + m.slice(0, 160)); }
if (typeof window.addEventListener === 'function') window.addEventListener('unhandledrejection', ev => { if (ev.preventDefault) ev.preventDefault(); reportErr(ev.reason); });
window.onerror = (m, src, ln) => { reportErr(String(m) + (ln ? ' (' + ln + ')' : '')); return true; };

// ---------------- ubus over native bridge ----------------
const Z = '0'.repeat(32), S = {}, cbs = {};
let nid = 1;
window.cb = (id, ok, t) => { const f = cbs[id]; delete cbs[id]; if (f) f(ok, t); };
const post = (u, b) => new Promise((res, rej) => {
  const id = nid++;
  cbs[id] = (ok, t) => (ok ? res(t) : rej(new Error(_('Нет связи с роутером', 'Cannot reach the router'))));
  Native.post(id, u, JSON.stringify(b));
});
const phoneGet = (url, ua) => new Promise((res, rej) => {
  const id = nid++;
  cbs[id] = (ok, t) => { if (!ok) return rej(new Error(t)); try { res(JSON.parse(t)); } catch (e) { rej(new Error('bad response')); } };
  Native.get(id, url, ua || '');
});
const base = r => (/^https?:\/\//.test(r.a) ? r.a : 'http://' + r.a).replace(/\/+$/, '');
async function login(r) {
  const k = base(r);
  const j = JSON.parse(await post(k + '/ubus', { jsonrpc: '2.0', id: 1, method: 'call', params: [Z, 'session', 'login', { username: r.u || 'root', password: r.p }] }));
  if (!j.result || j.result[0] !== 0) throw new Error(_('Неверный логин или пароль', 'Wrong username or password'));
  S[k] = j.result[1].ubus_rpc_session;
}
async function call(r, o, m, a, retry) {
  if (retry === undefined) retry = 1;
  const k = base(r);
  const j = JSON.parse(await post(k + '/ubus', { jsonrpc: '2.0', id: 1, method: 'call', params: [S[k] || Z, o, m, a || {}] }));
  if (j.error || !j.result || j.result[0] !== 0) {
    const c = j.result ? j.result[0] : (j.error && j.error.code);
    if (retry && (c === 6 || c === -32002)) { await login(r); return call(r, o, m, a, 0); }
    const e = new Error(_('Ошибка ubus ', 'ubus error ') + c + ' (' + o + '.' + m + ')'); e.code = c; throw e;
  }
  return j.result[1];
}
async function shOn(r, cmd) {
  const x = await call(r, 'file', 'exec', { command: '/bin/sh', params: ['-c', cmd] });
  return { code: x.code | 0, stdout: x.stdout || '', stderr: x.stderr || '' };
}
async function sh(cmd) {
  try {
    const r = await shOn(R(), cmd);
    alog('sh', cmd.replace(/\s+/g, ' ').slice(0, 110) + ' -> ' + r.code);
    return r;
  } catch (e) {
    alog('sh-err', e.message + ' :: ' + cmd.slice(0, 80));
    if (e.code === 6 || e.code === -32002) { const x = new Error(_('Нужна подготовка роутера', 'Router setup required')); x.acl = true; throw x; }
    throw e;
  }
}
const out = async c => (await sh(c)).stdout;
const U = {
  get: async cfg => (await call(R(), 'uci', 'get', { config: cfg })).values || {},
  set: (cfg, section, values) => call(R(), 'uci', 'set', { config: cfg, section, values }),
  add: (cfg, type, name, values) => call(R(), 'uci', 'add', { config: cfg, type, name, values }),
  del: (cfg, section, options) => call(R(), 'uci', 'delete', options ? { config: cfg, section, options } : { config: cfg, section }),
  commit: cfg => call(R(), 'uci', 'commit', { config: cfg }),
  revert: cfg => call(R(), 'uci', 'revert', { config: cfg })
};
const RELOAD = {
  firewall: '/etc/init.d/firewall reload', dhcp: '/etc/init.d/dnsmasq reload; /etc/init.d/odhcpd reload', wireless: 'wifi reload',
  network: '(sleep 2; /etc/init.d/network restart) >/dev/null 2>&1 &', system: '/etc/init.d/system reload',
  podkop: '/etc/init.d/podkop restart >/dev/null 2>&1 &', forkop: '/etc/init.d/forkop restart >/dev/null 2>&1 &', netshift: '/etc/init.d/netshift restart >/dev/null 2>&1 &'
};
const RISKY = ['network', 'wireless', 'firewall'];
const okCfg = c => /^[\w-]+$/.test(c);
async function backupCfg(c) {
  if (!okCfg(c)) return;
  try { await sh(`mkdir -p /root/routerhub-backup && [ -f /etc/config/${c} ] && cp /etc/config/${c} /root/routerhub-backup/${c}.$(date +%Y%m%d-%H%M%S); ls -t /root/routerhub-backup/${c}.* 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null; true`); } catch (e) { }
}
async function applyCfg(c) {
  if (!okCfg(c)) throw new Error('bad config name');
  await backupCfg(c);
  await U.commit(c);
  await sh((RELOAD[c] || 'reload_config') + '\ntrue');
}
// Apply with automatic rollback (like LuCI "apply with revert"): if the change cuts the connection and is not confirmed, the router restores the old config itself.
const undoOf = c => RELOAD[c].replace(/\(sleep 2; /, '(').replace(/\)\s*>\/dev\/null 2>&1 &$/, ')');
async function armUndo(c) {
  const id = Date.now(), undo = undoOf(c);
  await sh(`mkdir -p /tmp/rh-undo && cp -f /etc/config/${c} /tmp/rh-undo/${c}.${id}; rm -f /tmp/rh_ok_${id}; ( sleep 75; [ -f /tmp/rh_ok_${id} ] || { cp -f /tmp/rh-undo/${c}.${id} /etc/config/${c}; ${undo}; }; rm -f /tmp/rh-undo/${c}.${id} /tmp/rh_ok_${id} ) </dev/null >/dev/null 2>&1 &\ntrue`);
  return { id, undo };
}
async function applySafe(c) {
  if (!RISKY.includes(c)) return applyCfg(c);
  await backupCfg(c);
  const u = await armUndo(c);
  await U.commit(c);
  await sh(RELOAD[c] + '\ntrue');
  confirmSheet(u.id, c, u.undo);
}
function confirmSheet(id, c, undo) {
  sheet(`<h3>🛟 ${_('Проверьте связь', 'Check the connection')}</h3><p class=sub>${_('Если после изменения всё работает, подтвердите. Если связь пропала, ничего делать не нужно: через ', 'If everything still works, confirm. If the connection is lost, do nothing: in ')}<b id=cd>75</b> ${_('с роутер сам вернёт прежние настройки.', 's the router restores the previous settings by itself.')}</p><div class=g2><button class=d onclick="undoNow(${id},'${c}')">${_('Откатить', 'Revert')}</button><button class=p onclick="confirmOk(${id})">${_('Всё работает', 'Keep changes')}</button></div>`);
  let n = 75;
  const tickf = () => { const e = $('#cd'); if (!e) return; n--; e.textContent = Math.max(0, n); if (n > 0) setTimeout(tickf, 1000); };
  setTimeout(tickf, 1000);
}
async function retrySh(cmd) { for (let i = 0; i < 6; i++) { try { return await sh(cmd); } catch (e) { await sleep(3000); } } throw new Error(_('Нет связи с роутером', 'Cannot reach the router')); }
async function confirmOk(id) { try { await retrySh(`touch /tmp/rh_ok_${id}`); closeSheet(); toast('✅ ' + _('Изменения сохранены', 'Changes kept')); go(page, arg); } catch (e) { toast(e.message); } }
async function undoNow(id, c) {
  if (!okCfg(c) || !(id > 0)) return;
  try { await retrySh(`[ -f /tmp/rh-undo/${c}.${id} ] && cp -f /tmp/rh-undo/${c}.${id} /etc/config/${c}; ${undoOf(c)}\ntrue`); closeSheet(); toast('↩ ' + _('Настройки возвращены', 'Settings restored')); go(page, arg); } catch (e) { toast(e.message); }
}

// ---------------- UI helpers ----------------
const H = {
  card: (t, b, cls) => `<div class="card ${cls || ''}">${t ? `<h2>${t}</h2>` : ''}${b}</div>`,
  row: (l, s, r, oc) => `<div class=row${oc ? ` onclick="${oc}"` : ''}><div class=rl>${l}${s ? `<small>${s}</small>` : ''}</div>${r || ''}</div>`,
  sw: (on, fn) => `<label class=sw><input type=checkbox ${on ? 'checked' : ''} onchange="${fn}"><i></i></label>`,
  seg: (items, c, fn) => `<div class=seg>` + items.map(x => `<button class="${x[0] === c ? 'a' : ''}" onclick="${fn}('${x[0]}')">${x[1]}</button>`).join('') + `</div>`,
  hd: (t, back) => `<div class=hd>${back ? `<button class=bk onclick="go('${back}')">‹</button>` : ''}<h1>${t}</h1></div>`
};
let SHG = 0;
function sheet(h) { SHG++; const s = $('#sheet'); s.innerHTML = `<div class=sh-b onclick="closeSheet()"></div><div class=sh-c><div class=sh-g></div>${h}</div>`; s.style.display = 'block'; }
function closeSheet() { const s = $('#sheet'); s.style.display = 'none'; s.innerHTML = ''; if (CBK) { const f = CBK; CBK = null; f(false); } }
function ask(title, text, okLbl, danger) {
  return new Promise(res => {
    CBK = res;
    sheet(`<h3>${esc(title)}</h3><p class=sub>${esc(text)}</p><div class=g2><button onclick="ans(0)">${_('Отмена', 'Cancel')}</button><button class="${danger ? 'd' : 'p'}" onclick="ans(1)">${esc(okLbl || 'OK')}</button></div>`);
  });
}
function ans(v) { const f = CBK; CBK = null; if (f) f(!!v); closeSheet(); }
function askText(title, label, val, type) {
  return new Promise(res => {
    CBK = x => res(x ? $('#pi').value : null);
    sheet(`<h3>${esc(title)}</h3><label class=fl>${esc(label)}</label><input id=pi type="${type || 'text'}" value="${esc(val || '')}" autocapitalize=off autocomplete=off><div class=g2><button onclick="ans(0)">${_('Отмена', 'Cancel')}</button><button class=p onclick="ans(1)">OK</button></div>`);
  });
}
function fieldHtml(f, i) {
  const id = 'f' + i, lb = `<label class=fl>${esc(f.l)}</label>`;
  let h;
  if (f.t === 'select') h = lb + `<select id=${id} onchange="depUpd()">` + f.o.map(o => `<option value="${esc(o[0])}" ${String(o[0]) === String(f.v) ? 'selected' : ''}>${esc(o[1])}</option>`).join('') + (f.custom ? `<option value="__custom">✏️ ${_('Другое (ввести вручную)…', 'Other (type manually)…')}</option>` : '') + `</select>` + (f.custom ? `<input id=${id}_c type=text style="display:none;margin-top:8px" placeholder="${_('Своё значение', 'Custom value')}" autocapitalize=off>` : '');
  else if (f.t === 'check') h = `<div class=row><div class=rl>${esc(f.l)}</div><label class=sw><input type=checkbox id=${id} ${f.v ? 'checked' : ''} onchange="depUpd()"><i></i></label></div>`;
  else if (f.t === 'multi') h = lb + `<div class=mc>` + f.o.map((o, j) => `<label class=mcl><input type=checkbox id=f${i}_${j} ${(f.v || []).includes(o[0]) ? 'checked' : ''} onchange="mcX(${i},${j})"><span>${esc(o[1])}</span></label>`).join('') + `</div>`;
  else if (f.t === 'area') h = lb + `<textarea id=${id} rows=${f.rows || 4} autocapitalize=off spellcheck=false placeholder="${esc(f.p || '')}">${esc(f.v)}</textarea>`;
  else h = lb + `<input id=${id} type="${f.t === 'num' ? 'text' : (f.t || 'text')}" value="${esc(f.v)}" autocapitalize=off autocomplete=off spellcheck=false placeholder="${esc(f.p || '')}">`;
  return `<div id=fw${i}>${h}${f.h ? `<div class=hp>${esc(f.h)}</div>` : ''}</div>`;
}
function formVals() {
  return FS.fields.map((f, i) => {
    if (f.t === 'multi') return f.o.filter((o, j) => { const e = $('#f' + i + '_' + j); return e && e.checked; }).map(o => o[0]);
    const e = $('#f' + i); if (!e) return f.v;
    if (f.t === 'select' && f.custom && e.value === '__custom') { const ce = $('#f' + i + '_c'); return ce ? ce.value.trim() : ''; }
    return f.t === 'check' ? e.checked : e.value;
  });
}
function mcX(i, j) {
  const f = FS.fields[i], me = $('#f' + i + '_' + j);
  if (!f.excl || !me || !me.checked || !f.excl.includes(f.o[j][0])) return;
  f.o.forEach((o, k) => { if (k !== j && f.excl.includes(o[0])) { const e = $('#f' + i + '_' + k); if (e) e.checked = false; } });
  toast(_('Региональные списки нельзя сочетать, остался один', 'Regional lists cannot be combined; only one is kept'));
}
function depUpd() {
  if (!FS) return;
  const v = formVals(), g = o => v[FS.idx[o]];
  FS.fields.forEach((f, i) => {
    if (f.show) { const w = $('#fw' + i); if (w) w.style.display = f.show(g) ? '' : 'none'; }
    if (f.t === 'select' && f.custom) { const e = $('#f' + i), ce = $('#f' + i + '_c'); if (e && ce) ce.style.display = e.value === '__custom' ? '' : 'none'; }
  });
}
function form(title, fields, onSave, extra, note) {
  FS = { fields, onSave, idx: {} };
  fields.forEach((f, i) => { if (f.k) FS.idx[f.k] = i; });
  sheet(`<h3>${esc(title)}</h3>${note ? `<p class=sub>${esc(note)}</p>` : ''}` + fields.map(fieldHtml).join('') + (extra || '') + `<div class=g2><button onclick="closeSheet()">${_('Отмена', 'Cancel')}</button><button class=p onclick="fsave()">${_('Сохранить', 'Save')}</button></div>`);
  depUpd();
}
async function fsave() {
  if (!FS) return;
  const vals = formVals(), g = o => vals[FS.idx[o]], vis = FS.fields.map(f => !f.show || f.show(g));
  const gen = SHG;
  try { await FS.onSave(vals, vis); if (SHG === gen) closeSheet(); } catch (e) { toast(e.message); }
}
const PROG = `<div class=prog><i></i></div>`;

// ---------------- packages & background jobs ----------------
async function pm() { if (PM) return PM; PM = (await out('command -v apk >/dev/null 2>&1 && echo apk || echo opkg')).trim() === 'apk' ? 'apk' : 'opkg'; return PM; }
async function installed() { return L.parseInstalled(await out(L.pmCmd(await pm()).list)); }
async function job(cmd, onLog) {
  const id = 'rh' + Date.now();
  await sh(`sh -c ${L.shq(cmd + '; echo "##EXIT $?"')} </dev/null >/tmp/${id}.log 2>&1 &\ntrue`);
  for (let i = 0; i < 600; i++) {
    await sleep(1500);
    let t = '';
    try { t = await out(`cat /tmp/${id}.log`); } catch (e) { continue; }
    if (onLog) onLog(t);
    const m = t.match(/##EXIT (\d+)/);
    if (m) { sh(`rm -f /tmp/${id}.log`).catch(() => { }); return +m[1]; }
  }
  return -1;
}
function jobSheet(title, cmd) {
  sheet(`<h3>${esc(title)}</h3>${PROG}<pre id=jl class=jl></pre><div id=jb></div>`);
  return job(cmd, t => { const e = $('#jl'); if (e) { e.textContent = t.replace(/##EXIT.*/, ''); e.scrollTop = e.scrollHeight; } }).then(c => {
    const b = $('#jb');
    if (b) b.innerHTML = `<div class=sub>${c === 0 ? '✅ ' + _('Готово', 'Done') : '⚠️ ' + _('Ошибка, код ', 'Error, code ') + c}</div><button class=p onclick="closeSheet()">OK</button>`;
    return c;
  });
}
async function need(pkgs, why) {
  pkgs = [].concat(pkgs);
  if (!pkgs.every(L.okPkg)) throw new Error('bad package name');
  const inst = await installed();
  const miss = pkgs.filter(p => !(p in inst));
  if (!miss.length) return true;
  const yes = await ask(_('Нужен пакет', 'Package required'),
    _(`Для функции «${why}» нужно установить: ${miss.join(', ')}. Скачать и установить сейчас? Роутеру нужен доступ в интернет.`, `The feature "${why}" needs: ${miss.join(', ')}. Download and install now? The router needs internet access.`), _('Установить', 'Install'));
  if (!yes) return false;
  const c = L.pmCmd(await pm());
  const code = await jobSheet(_('Установка', 'Installing'), `${c.upd}; ${c.inst(miss.join(' '))}`);
  return code === 0;
}

// ---------------- router preparation via SSH (one-time ACL) ----------------
function sshRun(h, p, u, pw, cmd, mark) {
  return new Promise((res, rej) => {
    let buf = '', sent = false;
    SSHK = (t, d) => {
      if (t === 'ok' && !sent) { sent = true; Ssh.send(cmd + '\n'); }
      else if (t === 'out') { buf += d; if (buf.includes(mark)) { SSHK = null; Ssh.close(); res(buf); } }
      else if (t === 'err') { SSHK = null; rej(new Error(d)); }
      else if (t === 'closed' && SSHK) { SSHK = null; rej(new Error(_('Соединение закрыто', 'Connection closed'))); }
    };
    Ssh.connect(h, p, u, pw, 80, 24);
    setTimeout(() => { if (SSHK) { SSHK = null; Ssh.close(); rej(new Error('timeout')); } }, 60000);
  });
}
const ACL = '{"routerhub":{"description":"Router Hub","read":{"file":{"/bin/sh":["exec"]},"ubus":{"system":["*"],"uci":["*"],"luci":["*"]}},"write":{"file":{"/bin/sh":["exec"]},"ubus":{"system":["*"],"uci":["*"],"luci":["*"]}}}}';
const ACLCMD = `printf '%s\\n' '${ACL}' > /usr/share/rpcd/acl.d/routerhub.json && /etc/init.d/rpcd restart; echo RH_OK_$((20+22))`;
async function prepRouter() {
  const r = R();
  const host = r.a.replace(/^https?:\/\//, '').split('/')[0].replace(/:\d+$/, '');
  sheet(`<h3>${_('Подготовка роутера', 'Router setup')}</h3><p class=sub>${_('Подключаюсь по SSH и разрешаю приложению выполнять команды. Если появится запрос про ключ сервера, нажмите «Доверять».', 'Connecting over SSH to allow the app to run commands. If asked about the server key, tap Trust.')}</p>${PROG}`);
  try {
    await sshRun(host, 22, r.u || 'root', r.p, ACLCMD, 'RH_OK_42');
    closeSheet(); toast('✅ ' + _('Готово', 'Done')); await sleep(1500); go(page, arg);
  } catch (e) {
    sheet(`<h3>⚠️ ${_('Не получилось автоматически', 'Automatic setup failed')}</h3><p class=sub>${esc(e.message)}</p><p class=sub>${_('Выполните эту команду на роутере (по SSH) один раз:', 'Run this command on the router (over SSH) once:')}</p><pre class=jl>${esc(ACLCMD)}</pre><button class=p onclick="closeSheet()">OK</button>`);
  }
}

// ---------------- navigation ----------------
const NAV = [['home', '🏠', ['Главная', 'Home']], ['dev', '📱', ['Устройства', 'Devices']], ['pk', '🛰️', ['Подкоп', 'Podkop']], ['set', '🧰', ['LuCI', 'LuCI']], ['more', '☰', ['Ещё', 'More']]];
const PARENT = { wifi: 'set', ifs: 'set', dhcp: 'set', routes: 'set', fw: 'set', diag: 'set', sys: 'set', admin: 'set', cron: 'set', ov: 'set', procs: 'set', apps: 'set', svc: 'set', pkgs: 'set', ssh: 'set', uci: 'set', logs: 'set', bk: 'set', selftest: 'set', rt: 'more', look: 'more', sec: 'more', applog: 'more' };
const NOROUTER = ['rt', 'look', 'more', 'ssh', 'sec', 'applog'];
const P = {};
function renderNav() {
  const t = PARENT[page] || page;
  $('#nav').innerHTML = NAV.map(x => `<button class="${x[0] === t ? 'a' : ''}" onclick="go('${x[0]}')"><b>${x[1]}</b>${_(x[2][0], x[2][1])}</button>`).join('');
}
function errCard(e) {
  if (e && e.acl) return H.card('', `<h2 style="margin:0 0 8px;font-size:15px;text-transform:none;color:var(--t)">🔐 ${_('Нужна разовая подготовка роутера', 'One-time router setup needed')}</h2><p class=sub>${_('Роутер пока не разрешает приложению выполнять команды. Приложение само подключится по SSH и добавит разрешение.', 'The router does not yet allow the app to run commands. The app will connect over SSH and add the permission.')}</p><button class=p onclick="prepRouter()">${_('Подготовить автоматически', 'Set up automatically')}</button>`);
  return H.card('', `⚠️ ${esc(e && e.message)}<br><br><button onclick="go(page,arg)">${_('Повторить', 'Retry')}</button>`);
}
async function go(p, a) {
  clearInterval(timer); timer = null;
  if (!R() && !NOROUTER.includes(p)) p = 'rt';
  page = p; arg = a; renderNav(); window.scrollTo(0, 0);
  V(`<div class=sub style="margin-top:40px;text-align:center">${_('Загрузка…', 'Loading…')}</div>`);
  try { await P[p](a); } catch (e) { V(errCard(e)); }
}

// ---------------- Home ----------------
const HW = [['hero', ['Роутер', 'Router']], ['load', ['Нагрузка', 'Load']], ['speed', ['Скорость интернета', 'Internet speed']], ['mem', ['Память', 'Memory']], ['devs', ['Устройства', 'Devices']], ['fav', ['Быстрое включение', 'Quick power-on']], ['pk', ['Подкоп', 'Podkop']], ['act', ['Действия', 'Actions']]];
const hwCfg = () => {
  const s = LS.get('hw', null), ids = HW.map(x => x[0]);
  const a = Array.isArray(s) ? s.filter(x => ids.includes(x[0])) : [];
  ids.forEach(i => { if (!a.find(x => x[0] === i)) a.push([i, 1]); });
  return a;
};
const hwOn = id => { const x = hwCfg().find(y => y[0] === id); return !!(x && x[1]); };
const HOMECMD = "echo '##LOAD';cat /proc/loadavg;echo '##CPU';grep -c ^processor /proc/cpuinfo;echo '##UP';cat /proc/uptime;echo '##MEM';awk '/MemTotal|MemAvailable/{print $2}' /proc/meminfo;echo '##NET';cat /proc/net/dev;echo '##WAN';ip route show default 2>/dev/null | awk '{for(i=1;i<NF;i++)if($i==\"dev\"){print $(i+1);exit}}';echo '##PK';ls /etc/config 2>/dev/null | grep -E '^(podkop|forkop)$' | head -1;echo '##PKR';for s in podkop forkop; do [ -x /etc/init.d/$s ] && /etc/init.d/$s running >/dev/null 2>&1 && echo $s; done; true";
const HS = { d: null, prev: null };
async function getBoard() {
  const k = R().a; getBoard.c = getBoard.c || {};
  if (!getBoard.c[k]) getBoard.c[k] = await call(R(), 'system', 'board');
  return getBoard.c[k];
}
P.home = async () => {
  const b = await getBoard();
  await homeRefresh(b);
  timer = setInterval(() => { homeRefresh(b).catch(() => { }); }, 5000);
};
async function homeRefresh(b) {
  const s = L.sections(await out(HOMECMD)), t = Date.now();
  const lo = (s.LOAD || '').trim().split(/\s+/).map(Number), cores = +(s.CPU || '1').trim() || 1, up = +(s.UP || '0').split(' ')[0];
  const mm = (s.MEM || '').trim().split(/\s+/).map(Number);
  const nd = L.parseNetDev(s.NET || ''), wan = (s.WAN || '').trim(), w = nd[wan];
  let sp = { rx: 0, tx: 0 };
  if (w && HS.prev && HS.prev.wan === wan) { const dt = (t - HS.prev.t) / 1000; if (dt > 0.5) sp = { rx: Math.max(0, w.rx - HS.prev.rx) / dt, tx: Math.max(0, w.tx - HS.prev.tx) / dt }; }
  if (w) HS.prev = { t, wan, rx: w.rx, tx: w.tx };
  HS.d = { b, l: lo, cores, up, memT: mm[0] || 0, memA: mm[1] || 0, sp, wan, pk: (s.PK || '').trim(), pkr: (s.PKR || '').trim() };
  if (hwOn('fav') || hwOn('devs')) await loadDev().catch(() => { });
  if (page === 'home') renderHome();
}
function wHero(d) {
  const t = L.dur(d.up);
  return `<div class="card hero"><div class=hr><div class=hi>🛜</div><div><b>${esc(d.b.hostname)}</b><small>${esc(d.b.model)}</small><small>${esc((d.b.release || {}).description || '')}</small></div></div><div class=up>⏱ ${_('Работает', 'Uptime')}: ${t.d ? t.d + _('д ', 'd ') : ''}${t.h}${_('ч ', 'h ')}${t.m}${_('м', 'm')}</div></div>`;
}
function wLoad(d) {
  const li = L.loadInfo(d.l[0], d.cores), lbl = { low: _('Низкая', 'Low'), mid: _('Средняя', 'Medium'), high: _('Высокая', 'High') }[li.lv];
  return H.card(`${_('Нагрузка процессора', 'CPU load')} <button class=info onclick="loadInfo()">?</button>`,
    `<div class=big>${li.pct}%<small> ${lbl}</small></div><div class=bar><i class=${li.lv} style="width:${Math.min(100, li.pct)}%"></i></div><div class=sub style="margin:8px 0 0">${_('За 1/5/15 мин', 'Over 1/5/15 min')}: ${d.l.map(x => x.toFixed(2)).join(' / ')} · ${d.cores} ${_('ядра', 'cores')}</div>`);
}
function wSpeed(d) {
  return H.card(_('Скорость интернета', 'Internet speed'), `<div class=grid><div class=st><span>↓ ${_('Загрузка', 'Download')}</span><b>${L.fmtR(d.sp.rx)}</b></div><div class=st><span>↑ ${_('Отдача', 'Upload')}</span><b>${L.fmtR(d.sp.tx)}</b></div></div><div class=sub style="margin:8px 0 0">${_('Интерфейс', 'Interface')}: ${esc(d.wan || '—')}</div>`);
}
function wMem(d) {
  const used = d.memT - d.memA, pct = d.memT ? Math.round(used / d.memT * 100) : 0;
  return H.card(_('Память', 'Memory'), `<div class=big>${pct}%<small> ${Math.round(used / 1024)} / ${Math.round(d.memT / 1024)} MB</small></div><div class=bar><i class=${pct > 85 ? 'high' : pct > 65 ? 'mid' : 'low'} style="width:${pct}%"></i></div>`);
}
function wDevs() {
  const on = D.list.filter(x => x.online && !x.blocked).length, bl = D.list.filter(x => x.blocked).length;
  return H.card(_('Устройства', 'Devices'), `<div class=grid><div class=st onclick="go('dev')"><span>${_('В сети', 'Online')}</span><b>${on}</b></div><div class=st onclick="go('dev')"><span>${_('Заблокировано', 'Blocked')}</span><b>${bl}</b></div></div>`);
}
function wFav() {
  const f = D.list.filter(x => x.fav);
  if (!f.length) return H.card(_('Быстрое включение', 'Quick power-on'), `<div class=sub style="margin:0">${_('Откройте устройство → «На главную», и оно появится здесь с кнопкой включения.', 'Open a device and tap "Pin to home" - it will appear here with a power button.')}</div>`);
  return H.card(_('Быстрое включение', 'Quick power-on'), `<div class=favs>` + f.map(d => `<div class=fv><div class=ic>${L.ICONS[d.icon] || '❓'}</div><b>${esc(d.name || d.ip)}</b>${d.online ? `<span class="chip ok">${_('в сети', 'online')}</span>` : `<button class=pw onclick="wolDev('${d.mac}')">${PWR}<small>${_('Включить', 'Power on')}</small></button>`}</div>`).join('') + `</div>`);
}
function wPk(d) {
  if (!d.pk) return '';
  return H.card('Podkop', H.row(`<span class="dot ${d.pkr ? 'on' : ''}"></span>${esc(d.pk)} ${d.pkr ? _('работает', 'running') : _('остановлен', 'stopped')}`, '', `<button class="s" onclick="go('pk')">${_('Открыть', 'Open')}</button>`));
}
function wAct() {
  return H.card(_('Действия', 'Actions'), `<div class=grid><button class=p onclick="openLuci()">⚙️ ${_('Веб-интерфейс', 'Web UI')}</button><button onclick="go('ssh')">⌨️ SSH</button><button class=d onclick="rebootAsk()">🔄 ${_('Перезагрузка', 'Reboot')}</button><button onclick="go('logs')">📜 ${_('Журнал', 'Log')}</button></div>`);
}
function renderHome() {
  const d = HS.d; if (!d) return;
  const fn = { hero: wHero, load: wLoad, speed: wSpeed, mem: wMem, devs: wDevs, fav: wFav, pk: wPk, act: wAct };
  V(`<div class=hd><h1>${_('Главная', 'Home')}</h1><button class=s onclick="hwSheet()">🎛</button></div>` + hwCfg().filter(x => x[1]).map(x => fn[x[0]](d)).join(''));
}
function loadInfo() {
  const d = HS.d || { cores: 1 };
  sheet(`<h3>${_('Что такое нагрузка?', 'What is load?')}</h3><p class=sub>${_(`Это среднее число задач, которые ждали процессор за последние 1, 5 и 15 минут. У вашего роутера ядер: ${d.cores}. Значение, равное числу ядер, означает, что процессор занят полностью (100%). Меньше — всё в порядке, больше — задачи стоят в очереди и роутер может тормозить.`, `It is the average number of tasks waiting for the CPU over the last 1, 5 and 15 minutes. Your router has ${d.cores} core(s). A value equal to the core count means the CPU is fully busy (100%). Lower is fine; higher means tasks queue up and the router may feel slow.`)}</p><p class=sub>${_('Процент на главной = нагрузка за 1 минуту ÷ число ядер.', 'The percentage on Home = 1-minute load ÷ number of cores.')}</p><button class=p onclick="closeSheet()">OK</button>`);
}
function hwSheet() {
  const c = hwCfg();
  const name = id => { const x = HW.find(y => y[0] === id); return _(x[1][0], x[1][1]); };
  sheet(`<h3>${_('Настроить главную', 'Customize Home')}</h3><p class=sub>${_('Включайте нужные блоки и меняйте порядок.', 'Toggle blocks and change their order.')}</p>` + c.map((x, i) => `<div class=row><div class=rl>${name(x[0])}</div><div class=ctl><button class=s onclick="hwMove(${i},-1)">↑</button><button class=s onclick="hwMove(${i},1)">↓</button>${H.sw(x[1], `hwTog(${i})`)}</div></div>`).join('') + `<button class=p style="margin-top:10px" onclick="closeSheet();go('home')">OK</button>`);
}
function hwMove(i, d) { const c = hwCfg(), j = i + d; if (j < 0 || j >= c.length) return; [c[i], c[j]] = [c[j], c[i]]; LS.set('hw', c); hwSheet(); }
function hwTog(i) { const c = hwCfg(); c[i][1] = c[i][1] ? 0 : 1; LS.set('hw', c); }
async function rebootAsk() { if (await ask(_('Перезагрузить роутер?', 'Reboot the router?'), _('Связь пропадёт примерно на минуту.', 'Connection will drop for about a minute.'), _('Перезагрузить', 'Reboot'), true)) { try { await call(R(), 'system', 'reboot', {}); } catch (e) { await sh('reboot'); } toast(_('Перезагрузка…', 'Rebooting…')); } }
function openLuci() { if (R()) Native.open(base(R()) + '/'); }

// ---------------- More / appearance / routers ----------------
const TH = { neon: ['Неон', 'Neon', '#5b6cff', '#c04dff'], sunset: ['Закат', 'Sunset', '#ff7a45', '#ff3d81'], ocean: ['Океан', 'Ocean', '#00b3d6', '#2f6bff'], forest: ['Лес', 'Forest', '#12b886', '#82c91e'], amoled: ['AMOLED', 'AMOLED', '#2b2f55', '#9aa4ff'] };
function ap() {
  const d = document.documentElement;
  d.dataset.th = LS.get('th', 'neon'); d.style.setProperty('--gl', LS.get('gl', 9) / 100); d.style.setProperty('--bo', LS.get('bo', 55) / 100);
  d.style.setProperty('--fs', LS.get('fs', 15) + 'px'); d.dataset.density = LS.get('dn', 'cozy');
}
function setTheme(k) { LS.set('th', k); ap(); toast(_(TH[k][0], TH[k][1])); }
function setLang(l) { lang = l; LS.set('lang', l); renderNav(); go(page, arg); }
P.more = async () => {
  V(H.hd(_('Ещё', 'More')) +
    H.card('', H.row('🛜 ' + _('Роутеры', 'Routers'), esc(R() ? R().n : _('не добавлен', 'none')), '›', "go('rt')") + H.row('🎨 ' + _('Оформление и язык', 'Appearance & language'), '', '›', "go('look')") + H.row('🔒 ' + _('Безопасность', 'Security'), '', '›', "go('sec')") + H.row('🎛 ' + _('Настроить главную', 'Customize Home'), '', '›', 'hwSheet()') + H.row('🔐 ' + _('Подготовка роутера', 'Router setup'), _('Разрешить приложению команды', 'Allow the app to run commands'), '›', 'prepRouter()') + H.row('🩺 ' + _('Самопроверка роутера', 'Router self-test'), _('Проверить, что всё работает', 'Check that everything works'), '›', "go('selftest')") + H.row('📋 ' + _('Журнал приложения', 'App log'), _('Что делало приложение и какие были ошибки', 'What the app did and any errors'), '›', "go('applog')")) +
    H.card('', `<div class=sub style="margin:0">Router Hub 2.0<br>${_('Приложение не отправляет данные никому, кроме ваших роутеров.', 'The app sends data only to your own routers.')}</div>`));
};
P.look = async () => {
  V(H.hd(_('Оформление', 'Appearance'), 'more') +
    H.card(_('Тема', 'Theme'), `<div class=grid3>` + Object.keys(TH).map(k => `<button class=th style="background:linear-gradient(135deg,${TH[k][2]},${TH[k][3]})" onclick="setTheme('${k}')">${_(TH[k][0], TH[k][1])}</button>`).join('') + `</div>
<div class=sub style="margin:12px 0 2px">${_('Прозрачность карточек', 'Card transparency')}</div><input type=range min=3 max=28 value=${LS.get('gl', 9)} oninput="LS.set('gl',this.value);ap()">
<div class=sub style="margin:4px 0 2px">${_('Яркость фона', 'Background brightness')}</div><input type=range min=10 max=90 value=${LS.get('bo', 55)} oninput="LS.set('bo',this.value);ap()">
<div class=sub style="margin:4px 0 2px">${_('Размер текста', 'Text size')}</div><input type=range min=13 max=19 value=${LS.get('fs', 15)} oninput="LS.set('fs',this.value);ap()">`) +
    H.card(_('Язык', 'Language'), H.seg([['ru', 'Русский'], ['en', 'English']], lang, 'setLang')));
};
P.sec = async () => {
  const ds = Native.isDeviceSecure();
  V(H.hd(_('Безопасность', 'Security'), 'more') + H.card('',
    H.row(_('Блокировка приложения', 'App lock'), ds ? _('PIN, рисунок или отпечаток телефона', 'Phone PIN, pattern or fingerprint') : _('Сначала задайте блокировку экрана на телефоне', 'Set a screen lock on the phone first'), `<label class=sw><input type=checkbox ${Native.getLock() && ds ? 'checked' : ''} ${ds ? '' : 'disabled'} onchange="Native.setLock(this.checked)"><i></i></label>`) +
    H.row(_('Запрет скриншотов', 'Block screenshots'), _('Скрывает окно в списке приложений', 'Hides the window in recent apps'), `<label class=sw><input type=checkbox ${Native.getSecure() ? 'checked' : ''} onchange="Native.setSecure(this.checked)"><i></i></label>`)) +
    H.card('', `<div class=sub style="margin:0">${_('Пароли роутеров хранятся зашифрованными (ключ в защищённом хранилище Android) и отправляются только на сами роутеры.', 'Router passwords are stored encrypted (key in the Android keystore) and are sent only to the routers themselves.')}</div>`));
};
P.rt = async () => {
  V(H.hd(_('Роутеры', 'Routers'), 'more') + H.card('', (rs.map((x, i) => H.row(`<span class="dot ${i === cur ? 'on' : ''}"></span>${esc(x.n)}`, esc(x.a), `<button class="s d" onclick="rtDel(${i})">🗑</button>`, `rtPick(${i})`)).join('')) || `<span class=sub>${_('Пока нет роутеров. Добавьте первый ниже.', 'No routers yet. Add the first one below.')}</span>`) +
    H.card(_('Добавить роутер', 'Add a router'), `<input type=text id=n placeholder="${_('Название (например, Cudy)', 'Name (e.g. Cudy)')}"><input type=text id=a placeholder="${_('Адрес (например, 192.168.1.1)', 'Address (e.g. 192.168.1.1)')}" autocapitalize=off><input type=text id=u placeholder="${_('Логин', 'Username')}" value=root autocapitalize=off><input type=password id=p placeholder="${_('Пароль', 'Password')}"><button class=p onclick="rtAdd()">${_('Добавить', 'Add')}</button>`));
};
async function rtAdd() {
  const r = { n: $('#n').value || $('#a').value, a: $('#a').value.trim(), u: $('#u').value || 'root', p: $('#p').value };
  if (!r.a) return toast(_('Введите адрес', 'Enter the address'));
  try { await login(r); rs.push(r); cur = rs.length - 1; PM = null; saveRs(); toast(_('Добавлено', 'Added')); go('home'); } catch (e) { toast(e.message); }
}
function rtPick(i) { cur = i; PM = null; D.list = []; D.loaded = 0; HS.prev = null; saveRs(); go('home'); }
async function rtDel(i) { if (await ask(_('Удалить роутер?', 'Remove router?'), rs[i].n, _('Удалить', 'Remove'), true)) { rs.splice(i, 1); cur = 0; saveRs(); go('rt'); } }
