package com.routerhub.app;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

public class MainActivity extends Activity {
    WebView w;
    SharedPreferences sp;
    boolean unlocked = false, loaded = false;
    long pausedAt = 0;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("s", 0);
        if (sp.getBoolean("secure", true))
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        w = new WebView(this);
        w.setVisibility(View.INVISIBLE);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSaveFormData(false);
        w.setBackgroundColor(0xFF0F1220);
        w.addJavascriptInterface(new Bridge(), "Native");
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        if (lockOn()) auth(); else ok();
    }

    boolean lockOn() {
        KeyguardManager k = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        return sp.getBoolean("lock", true) && k.isDeviceSecure();
    }
    void auth() {
        KeyguardManager k = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        Intent i = k.createConfirmDeviceCredentialIntent("Router Hub", "Подтвердите, что это вы");
        if (i == null) { ok(); return; }
        startActivityForResult(i, 1);
    }
    void ok() {
        unlocked = true;
        w.setVisibility(View.VISIBLE);
        if (!loaded) { loaded = true; w.loadUrl("file:///android_asset/index.html"); }
    }
    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == 1) { if (rs == RESULT_OK) ok(); else finish(); }
    }
    @Override protected void onPause() { super.onPause(); pausedAt = SystemClock.elapsedRealtime(); }
    @Override protected void onResume() {
        super.onResume();
        if (unlocked && lockOn() && SystemClock.elapsedRealtime() - pausedAt > 30000) {
            unlocked = false;
            w.setVisibility(View.INVISIBLE);
            auth();
        }
    }
    @Override public void onBackPressed() { super.onBackPressed(); }

    SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias("rh")) {
            KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder("rh", KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
            g.generateKey();
        }
        return (SecretKey) ks.getKey("rh", null);
    }

    class Bridge {
        @JavascriptInterface public void post(final int id, final String url, final String body) {
            new Thread(() -> {
                String res; boolean ok = false;
                try {
                    URL u = new URL(url);
                    if (!"/ubus".equals(u.getPath()) || !Net.hostOk(u)) throw new Exception("Адрес не разрешён");
                    if (body.length() > 65536) throw new Exception("Слишком большой запрос");
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(6000); c.setReadTimeout(20000);
                    c.setRequestMethod("POST"); c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json");
                    OutputStream o = c.getOutputStream(); o.write(body.getBytes("UTF-8")); o.close();
                    InputStream in = c.getResponseCode() < 400 ? c.getInputStream() : c.getErrorStream();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096]; int n;
                    while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 2000000) throw new Exception("Ответ слишком большой"); }
                    res = bo.toString("UTF-8"); ok = true;
                } catch (Exception e) { res = String.valueOf(e.getMessage()); }
                final String r = res; final boolean k = ok;
                runOnUiThread(() -> w.evaluateJavascript("window.cb(" + id + "," + k + "," + JSONObject.quote(r) + ")", null));
            }).start();
        }
        @JavascriptInterface public void open(final String url) {
            new Thread(() -> {
                try {
                    URL u = new URL(url);
                    if (!Net.hostOk(u)) return;
                    Intent i = new Intent(MainActivity.this, LuciActivity.class);
                    i.putExtra("u", url);
                    runOnUiThread(() -> startActivity(i));
                } catch (Exception e) { }
            }).start();
        }
        @JavascriptInterface public void secSet(String k, String v) {
            try {
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.ENCRYPT_MODE, key());
                String iv = Base64.encodeToString(c.getIV(), Base64.NO_WRAP);
                String ct = Base64.encodeToString(c.doFinal(v.getBytes("UTF-8")), Base64.NO_WRAP);
                sp.edit().putString(k, iv + ":" + ct).apply();
            } catch (Exception e) { }
        }
        @JavascriptInterface public String secGet(String k) {
            try {
                String s = sp.getString(k, null);
                if (s == null) return "";
                String[] p = s.split(":");
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
                return new String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), "UTF-8");
            } catch (Exception e) { return ""; }
        }
        @JavascriptInterface public boolean isDeviceSecure() {
            return ((KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE)).isDeviceSecure();
        }
        @JavascriptInterface public boolean getLock() { return sp.getBoolean("lock", true); }
        @JavascriptInterface public void setLock(boolean v) { sp.edit().putBoolean("lock", v).apply(); }
        @JavascriptInterface public boolean getSecure() { return sp.getBoolean("secure", true); }
        @JavascriptInterface public void setSecure(final boolean v) {
            sp.edit().putBoolean("secure", v).apply();
            runOnUiThread(() -> {
                if (v) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            });
        }
    }
}
