'use strict';
const D = { list: [], tab: 'on', tot: {}, sp: {}, prev: null, loaded: 0, nl: 0, tick: 0, lan: 'br-lan', q: '', hasCT: false };
const PWR = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><path d="M12 3v8"/><path d="M7.2 6.6a8 8 0 1 0 9.6 0"/></svg>';
const DEVCMD = "LAN=$(ubus call network.interface.lan status 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null); [ -z \"$LAN\" ] && LAN=br-lan\n" +
  "echo '##LAN'; echo $LAN\necho '##NEIGH'; ip -4 neigh show dev $LAN 2>/dev/null\necho '##LEASES'; cat /tmp/dhcp.leases 2>/dev/null\n" +
  "echo '##WIFI'; for i in $(iw dev 2>/dev/null | awk '$1==\"Interface\"{print $2}'); do iw dev $i station dump 2>/dev/null | awk -v I=$i '/^Station/{m=$2} /signal:/{print I, m, $2}'; done\n" +
  "echo '##UP'; for ip in $(ip -4 neigh show dev $LAN 2>/dev/null | awk '/STALE/{print $1}'); do (ping -c1 -W1 $ip >/dev/null 2>&1 && echo $ip) & done; wait\ntrue";
const regKey = () => 'dv_' + (R() ? R().a : '');
const reg = () => LS.get(regKey(), {});
const saveReg = r => LS.set(regKey(), r);

async function loadDev(force) {
  if (!force && Date.now() - D.loaded < 15000 && D.list.length) return D.list;
  const res = await Promise.all([out(DEVCMD), U.get('firewall').catch(() => ({})), U.get('dhcp').catch(() => ({}))]);
  const s = L.sections(res[0]), rules = L.parseRules(res[1]), statics = L.parseStatics(res[2]), r = reg();
  if ((s.LAN || '').trim()) D.lan = s.LAN.trim();
  const list = L.devices({ neigh: L.parseNeigh(s.NEIGH || ''), leases: L.parseLeases(s.LEASES || ''), wifi: L.parseWifi(s.WIFI || ''), up: (s.UP || '').split('\n').map(x => x.trim()).filter(Boolean), reg: r, blocks: rules.blocks, pcs: rules.pcs, statics });
  list.forEach(d => { const o = r[d.mac] || {}; r[d.mac] = Object.assign(o, { ip: d.ip, host: d.host, seen: d.online ? Date.now() : (o.seen || 0) }); });
  saveReg(r);
  D.list = list; D.loaded = Date.now();
  return list;
}
async function ctSample() {
  const t = Date.now(), m = L.parseCT(await out(L.CT_CMD));
  if (D.prev) {
    const dt = (t - D.prev.t) / 1000;
    if (dt > 0.5) { const sp = {}; Object.keys(m).forEach(ip => { const p = D.prev.m[ip]; if (p) sp[ip] = { up: Math.max(0, m[ip].up - p.up) / dt, down: Math.max(0, m[ip].down - p.down) / dt }; }); D.sp = sp; }
  }
  D.prev = { t, m }; D.hasCT = Object.keys(m).length > 0;
}
async function nlTotals() {
  const t = await out("command -v nlbw >/dev/null 2>&1 && { echo '##NL'; nlbw -c csv -g mac -n -q 2>/dev/null | tr -d '\"'; }; true");
  D.nl = t.includes('##NL') ? 1 : 0;
  D.tot = D.nl ? L.parseNlbw(t) : {};
}
const devCount = () => ({
  on: D.list.filter(d => d.online && !d.blocked).length,
  off: D.list.filter(d => !d.online && !d.blocked).length,
  bl: D.list.filter(d => d.blocked).length
});
function devVisible() {
  const q = D.q.toLowerCase();
  return D.list.filter(d => (D.tab === 'on' ? d.online && !d.blocked : D.tab === 'off' ? !d.online && !d.blocked : d.blocked) && (!q || (d.name + d.ip + d.mac).toLowerCase().includes(q)));
}
function devCard(d) {
  const sp = D.sp[d.ip], t = D.tot[d.mac];
  const chips = (d.wifi ? `<span class=chip>📶 ${esc(d.wifi.signal)} dBm</span>` : d.online ? `<span class=chip>🔌 LAN</span>` : '') +
    (d.pc ? `<span class="chip warn">🕒 ${_('Расписание', 'Schedule')}</span>` : '') + (d.fav ? '<span class=chip>★</span>' : '') +
    (t ? `<span class=chip>Σ ${L.fmtB(t.rx + t.tx)}</span>` : '');
  let r = '';
  if (d.blocked) r = `<button class="pw un" onclick="event.stopPropagation();blk('${d.mac}',0)">🔓<small>${_('Разблок.', 'Unblock')}</small></button>`;
  else if (d.online) r = `<div class=spd><span class=dn>↓ ${L.fmtR(sp ? sp.down : 0)}</span><span class=upc>↑ ${L.fmtR(sp ? sp.up : 0)}</span></div>`;
  else r = `<button class=pw onclick="event.stopPropagation();wolDev('${d.mac}')">${PWR}<small>${_('Включить', 'Power on')}</small></button>`;
  return `<div class="dv ${d.online ? 'on' : ''}" onclick="devSheet('${d.mac}')"><div class=ic>${L.ICONS[d.icon] || '❓'}</div><div class=dm><b>${esc(d.name || d.ip || d.mac)}</b><small>${esc((d.ip || '—') + ' · ' + d.mac)}</small><div>${chips}</div></div>${r}</div>`;
}
function renderDev() {
  const c = devCount(), list = devVisible();
  let banner = '';
  if (!D.nl) banner += `<div class=card style="padding:12px"><div class=sub style="margin:0 0 8px">📊 ${_('Чтобы видеть, сколько трафика съело каждое устройство, нужен учёт трафика.', 'To see how much traffic each device used, traffic accounting is needed.')}</div><button class=p onclick="enableNl()">${_('Включить учёт трафика', 'Enable traffic accounting')}</button></div>`;
  if (!D.hasCT) banner += `<div class=sub>${_('Скорость по устройствам пока недоступна: на роутере нет счётчиков соединений (conntrack). Если включён аппаратный ускоритель, счётчики могут не работать.', 'Per-device speed is unavailable: no connection counters (conntrack) on the router. Hardware flow offloading may prevent counters.')}</div>`;
  const keep = $('#dq') ? $('#dq').value : D.q;
  V(H.hd(_('Устройства', 'Devices')) +
    H.seg([['on', `${_('В сети', 'Online')} · ${c.on}`], ['off', `${_('Не в сети', 'Offline')} · ${c.off}`], ['bl', `${_('Блок', 'Blocked')} · ${c.bl}`]], D.tab, 'devTab') +
    `<input type=text id=dq placeholder="🔎 ${_('Поиск', 'Search')}" value="${esc(keep)}" oninput="D.q=this.value;renderDevList()">` + banner +
    `<div id=dl>${list.map(devCard).join('') || `<div class=sub style="text-align:center;margin-top:30px">${_('Пусто', 'Nothing here')}</div>`}</div>`);
}
function renderDevList() { const e = $('#dl'); if (e) e.innerHTML = devVisible().map(devCard).join('') || `<div class=sub style="text-align:center;margin-top:30px">${_('Пусто', 'Nothing here')}</div>`; }
function devTab(k) { D.tab = k; renderDev(); }
P.dev = async () => {
  await loadDev(true);
  sh('sysctl -w net.netfilter.nf_conntrack_acct=1 >/dev/null 2>&1; [ -f /etc/sysctl.d/99-routerhub.conf ] || echo net.netfilter.nf_conntrack_acct=1 > /etc/sysctl.d/99-routerhub.conf').catch(() => { });
  await ctSample().catch(() => { });
  await nlTotals().catch(() => { });
  renderDev();
  D.tick = 0;
  timer = setInterval(async () => {
    try {
      D.tick++;
      if (D.tick % 5 === 0) { await loadDev(true); await nlTotals(); renderDev(); }
      else { await ctSample(); if (!$('#sheet').innerHTML) renderDevList(); }
    } catch (e) { }
  }, 3000);
};
async function enableNl() {
  if (!await need(['nlbwmon'], _('Учёт трафика', 'Traffic accounting'))) return;
  await sh('/etc/init.d/nlbwmon enable; /etc/init.d/nlbwmon start; true');
  toast(_('Учёт включён. Данные появятся через пару минут.', 'Enabled. Data will appear in a couple of minutes.'));
}
// ---------- device actions ----------
const dget = m => D.list.find(x => x.mac === m);
function devSheet(mac) {
  const d = dget(mac); if (!d) return;
  const t = D.tot[mac], sp = D.sp[d.ip];
  const tile = (ic, lb, fn) => `<button class=tl onclick="${fn}"><span>${ic}</span>${lb}</button>`;
  sheet(`<div class=sh-hd><div class=ic>${L.ICONS[d.icon] || '❓'}</div><div><b>${esc(d.name || d.ip || d.mac)}</b><small>${esc((d.ip || '—') + ' · ' + d.mac)}</small></div></div>` +
    `<div class=grid style="margin-bottom:10px"><div class=st><span>${_('Сейчас', 'Now')}</span><b>${d.online ? '↓ ' + L.fmtR(sp ? sp.down : 0) : _('не в сети', 'offline')}</b><span>${d.online ? '↑ ' + L.fmtR(sp ? sp.up : 0) : ''}</span></div><div class=st><span>${_('Потреблено', 'Used')}</span><b>${t ? L.fmtB(t.rx + t.tx) : '—'}</b><span>${t ? '↓ ' + L.fmtB(t.rx) + ' · ↑ ' + L.fmtB(t.tx) : _('нужен учёт трафика', 'needs accounting')}</span></div></div>` +
    `<div class=tiles>` +
    (!d.online ? tile('⏻', _('Включить', 'Power on'), `closeSheet();wolDev('${mac}')`) : '') +
    tile('✏️', _('Название', 'Rename'), `renameDev('${mac}')`) + tile('🎨', _('Иконка', 'Icon'), `iconSheet('${mac}')`) +
    tile(d.fav ? '★' : '☆', d.fav ? _('Убрать с главной', 'Unpin') : _('На главную', 'Pin to home'), `favDev('${mac}')`) +
    tile(d.blocked ? '🔓' : '🚫', d.blocked ? _('Разблокировать', 'Unblock') : _('Блок интернета', 'Block internet'), `closeSheet();blk('${mac}',${d.blocked ? 0 : 1})`) +
    tile('🕒', _('Родит. контроль', 'Parental'), `pcSheet('${mac}')`) +
    tile('📌', d.static ? _('IP закреплён', 'IP pinned') : _('Закрепить IP', 'Pin IP'), `fixIP('${mac}')`) +
    (d.wifi ? tile('📴', _('Отключить от Wi-Fi', 'Kick from Wi-Fi'), `closeSheet();kick('${mac}')`) : '') + `</div>`);
}
async function renameDev(mac) {
  const d = dget(mac), v = await askText(_('Название устройства', 'Device name'), _('Пусто = вернуть имя по умолчанию', 'Empty = restore default name'), d.name);
  if (v === null) return;
  const r = reg(); r[mac] = Object.assign(r[mac] || {}, { n: v.trim() }); if (!r[mac].n) delete r[mac].n;
  saveReg(r); await loadDev(true); renderDev(); toast(_('Сохранено', 'Saved'));
}
function iconSheet(mac) {
  sheet(`<h3>${_('Иконка устройства', 'Device icon')}</h3><div class=icons>` + Object.keys(L.ICONS).map(k => `<button class=ib onclick="setIcon('${mac}','${k}')"><span>${L.ICONS[k]}</span><small>${_(L.ICON_NAMES[k][0], L.ICON_NAMES[k][1])}</small></button>`).join('') + `</div><button style="margin-top:10px" onclick="setIcon('${mac}','')">${_('Определять автоматически', 'Detect automatically')}</button>`);
}
async function setIcon(mac, k) {
  const r = reg(); r[mac] = Object.assign(r[mac] || {}, k ? { i: k } : {}); if (!k) delete r[mac].i;
  saveReg(r); closeSheet(); await loadDev(true); renderDev();
}
async function favDev(mac) { const r = reg(); r[mac] = Object.assign(r[mac] || {}, { fav: !(r[mac] && r[mac].fav) }); saveReg(r); closeSheet(); await loadDev(true); if (page === 'dev') renderDev(); toast('✓'); }
async function wolDev(mac) {
  if (!L.isMac(mac)) return;
  if (!await need(['etherwake'], _('Включение устройства по сети', 'Wake-on-LAN'))) return;
  try { await sh(`etherwake -b -i ${L.shq(D.lan)} ${mac}`); toast('⏻ ' + _('Сигнал включения отправлен', 'Wake signal sent')); } catch (e) { toast(e.message); }
}
async function blk(mac, on) {
  if (!L.isMac(mac)) return;
  const d = dget(mac);
  if (on && !await ask(_('Заблокировать интернет?', 'Block internet?'), (d && d.name || mac) + ' — ' + _('устройство останется в сети, но интернет у него пропадёт.', 'stays on the network but loses internet access.'), _('Заблокировать', 'Block'), true)) return;
  try {
    if (on) await U.add('firewall', 'rule', L.blockRule(mac).name, L.blockRule(mac));
    else await U.del('firewall', 'rh_block_' + L.m12(mac));
    await applyCfg('firewall'); await loadDev(true); if (page === 'dev') renderDev(); toast(on ? _('Заблокировано', 'Blocked') : _('Разблокировано', 'Unblocked'));
  } catch (e) { toast(e.message); }
}
let PCD = new Set();
const DAYS_UI = [['Mon', 'Пн', 'Mo'], ['Tue', 'Вт', 'Tu'], ['Wed', 'Ср', 'We'], ['Thu', 'Чт', 'Th'], ['Fri', 'Пт', 'Fr'], ['Sat', 'Сб', 'Sa'], ['Sun', 'Вс', 'Su']];
function pcSheet(mac) {
  const d = dget(mac), p = d.pc || { from: '22:00', to: '07:00', days: L.DAYS.slice() };
  PCD = new Set(p.days);
  sheet(`<h3>🕒 ${_('Родительский контроль', 'Parental control')}</h3><p class=sub>${_('В выбранное время у устройства будет отключён интернет.', 'Internet is cut for this device during the chosen time.')}</p>` +
    `<div class=g2><div><label class=fl>${_('С', 'From')}</label><input type=time id=pf value="${esc(p.from || '22:00')}"></div><div><label class=fl>${_('До', 'To')}</label><input type=time id=pt value="${esc(p.to || '07:00')}"></div></div>` +
    `<div class=days>` + DAYS_UI.map(x => `<button id=dy_${x[0]} class="${PCD.has(x[0]) ? 'a' : ''}" onclick="pcDay('${x[0]}')">${_(x[1], x[2])}</button>`).join('') + `</div>` +
    `<div class=g2><button onclick="closeSheet()">${_('Отмена', 'Cancel')}</button><button class=p onclick="pcSave('${mac}')">${_('Сохранить', 'Save')}</button></div>` +
    (d.pc ? `<button class=d style="margin-top:8px" onclick="pcDel('${mac}')">${_('Убрать расписание', 'Remove schedule')}</button>` : ''));
}
function pcDay(k) { if (PCD.has(k)) PCD.delete(k); else PCD.add(k); const e = $('#dy_' + k); if (e) e.className = PCD.has(k) ? 'a' : ''; }
async function pcClear(mac) { for (const s of ['s', 'a', 'b']) { await U.del('firewall', `rh_pc_${L.m12(mac)}_${s}`).catch(() => { }); } }
async function pcSave(mac) {
  const f = $('#pf').value, t = $('#pt').value, days = DAYS_UI.map(x => x[0]).filter(x => PCD.has(x));
  if (!f || !t || f === t) return toast(_('Укажите разное время начала и конца', 'Start and end times must differ'));
  if (!days.length) return toast(_('Выберите дни', 'Pick at least one day'));
  try {
    await pcClear(mac);
    for (const r of L.pcRules(mac, f, t, days)) await U.add('firewall', 'rule', r.name, r);
    await applyCfg('firewall'); closeSheet(); await loadDev(true); if (page === 'dev') renderDev(); toast(_('Расписание сохранено', 'Schedule saved'));
  } catch (e) { toast(e.message); }
}
async function pcDel(mac) { try { await pcClear(mac); await applyCfg('firewall'); closeSheet(); await loadDev(true); renderDev(); } catch (e) { toast(e.message); } }
async function fixIP(mac) {
  const d = dget(mac);
  if (d.static) { if (await ask(_('Открепить IP?', 'Unpin IP?'), d.static.ip, _('Открепить', 'Unpin'))) { await U.del('dhcp', d.static.sec); await applyCfg('dhcp'); await loadDev(true); renderDev(); } return; }
  const v = await askText(_('Закрепить IP', 'Pin IP address'), _('IP-адрес для этого устройства', 'IP address for this device'), d.ip);
  if (v === null) return;
  if (!L.isIP(v.trim())) return toast(_('Неверный IP', 'Invalid IP'));
  try { await U.add('dhcp', 'host', 'rh_' + L.m12(mac), { name: (d.name || 'device').replace(/[^\w-]/g, '_').slice(0, 30) || 'device', mac, ip: v.trim() }); await applyCfg('dhcp'); await loadDev(true); renderDev(); toast(_('Закреплено', 'Pinned')); } catch (e) { toast(e.message); }
}
async function kick(mac) {
  if (!L.isMac(mac)) return;
  await sh(`for i in $(ubus list 'hostapd.*'); do ubus call $i del_client '{"addr":"${mac}","reason":5,"deauth":true,"ban_time":30000}' 2>/dev/null; done; true`);
  toast(_('Отключено на 30 секунд', 'Disconnected for 30 seconds'));
}
