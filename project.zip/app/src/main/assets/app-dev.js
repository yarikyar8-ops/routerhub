'use strict';
const D = { list: [], tab: 'on', tot: {}, sp: {}, prev: null, loaded: 0, nl: 0, tick: 0, lan: 'br-lan', q: '', hasCT: false, acc: {}, hist: {}, accT: 0 };
const PWR = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><path d="M12 3v8"/><path d="M7.2 6.6a8 8 0 1 0 9.6 0"/></svg>';
const DEVCMD = "LAN=$(ubus call network.interface.lan status 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null); [ -z \"$LAN\" ] && LAN=br-lan\n" +
  "echo '##LAN'; echo $LAN\necho '##NEIGH'; ip -4 neigh show dev $LAN 2>/dev/null\necho '##LEASES'; cat /tmp/dhcp.leases 2>/dev/null\n" +
  "echo '##WIFI'; for i in $(iw dev 2>/dev/null | awk '$1==\"Interface\"{print $2}'); do iw dev $i station dump 2>/dev/null | awk -v I=$i '/^Station/{m=$2} /signal:/{print I, m, $2}'; done\n" +
  "echo '##UP'; for ip in $(ip -4 neigh show dev $LAN 2>/dev/null | awk '/STALE/{print $1}'); do (ping -c1 -W1 $ip >/dev/null 2>&1 && echo $ip) & done; wait\ntrue";
const regKey = () => 'dv_' + (R() ? R().a : '');
const reg = () => LS.get(regKey(), {});
const saveReg = r => LS.set(regKey(), r);

async function apStations() {
  const m = {};
  await Promise.all(rs.map(async (r, j) => {
    if (j === cur) return;
    try {
      const x = await Promise.race([shOn(r, L.stationsCmd), sleep(7000).then(() => { throw new Error('timeout'); })]);
      L.parseWifi(x.stdout).forEach(st => { m[st.mac] = { name: r.n, iface: st.iface, signal: st.signal }; });
    } catch (e) { alog('ap-skip', r.n + ': ' + e.message); }
  }));
  return m;
}
async function loadDev(force) {
  if (!force && Date.now() - D.loaded < 15000 && D.list.length) return D.list;
  const res = await Promise.all([out(DEVCMD), U.get('firewall').catch(() => ({})), U.get('dhcp').catch(() => ({})), rs.length > 1 ? apStations() : Promise.resolve({})]);
  const s = L.sections(res[0]), rules = L.parseRules(res[1]), statics = L.parseStatics(res[2]), r = reg();
  if ((s.LAN || '').trim()) D.lan = s.LAN.trim();
  const list = L.devices({ neigh: L.parseNeigh(s.NEIGH || ''), leases: L.parseLeases(s.LEASES || ''), wifi: L.parseWifi(s.WIFI || ''), up: (s.UP || '').split('\n').map(x => x.trim()).filter(Boolean), reg: r, blocks: rules.blocks, pcs: rules.pcs, statics, ap: res[3] });
  list.forEach(d => { const o = r[d.mac] || {}; r[d.mac] = Object.assign(o, { ip: d.ip, host: d.host, seen: d.online ? Date.now() : (o.seen || 0) }); });
  saveReg(r);
  D.list = list; D.loaded = Date.now();
  return list;
}
async function ctSample() {
  const t = Date.now(), m = L.parseCT(await out(L.CT_CMD));
  if (D.prev) {
    const dt = (t - D.prev.t) / 1000;
    if (dt > 0.5) {
      const sp = {};
      Object.keys(m).forEach(ip => {
        const p = D.prev.m[ip]; if (!p) return;
        const du = Math.max(0, m[ip].up - p.up), dd = Math.max(0, m[ip].down - p.down);
        sp[ip] = { up: du / dt, down: dd / dt };
        const d = D.list.find(x => x.ip === ip);
        if (d) { const a = D.acc[d.mac] || (D.acc[d.mac] = { rx: 0, tx: 0 }); a.rx += dd; a.tx += du; const h = D.hist[d.mac] || (D.hist[d.mac] = []); h.push(dd / dt); if (h.length > 60) h.shift(); }
      });
      D.sp = sp;
    }
  }
  D.prev = { t, m }; D.hasCT = Object.keys(m).length > 0;
}
async function nlTotals() {
  const t = await out("command -v nlbw >/dev/null 2>&1 && { echo '##NL'; nlbw -c csv -g mac -n -q 2>/dev/null | tr -d '\"'; }; true");
  D.nl = t.includes('##NL') ? 1 : 0;
  D.tot = D.nl ? L.parseNlbw(t) : {};
}
const accKey = () => 'tr_' + (R() ? R().a : '');
function accLoad() { const x = LS.get(accKey(), null); if (x && x.m) { Object.keys(x.m).forEach(k => { if (!D.acc[k]) D.acc[k] = x.m[k]; }); D.accSince = x.since; } else D.accSince = D.accSince || Date.now(); }
function accSave() { LS.set(accKey(), { since: D.accSince || Date.now(), m: D.acc }); }
function accReset() { D.acc = {}; D.accSince = Date.now(); accSave(); renderDev(); }
const devCount = () => ({
  on: D.list.filter(d => d.online && !d.blocked).length,
  off: D.list.filter(d => !d.online && !d.blocked).length,
  bl: D.list.filter(d => d.blocked).length,
  tr: D.list.filter(d => totOf(d) > 0).length
});
const totOf = d => { const t = D.tot[d.mac]; if (t) return t.rx + t.tx; const a = D.acc[d.mac]; return a ? a.rx + a.tx : 0; };
function devVisible() {
  const q = D.q.toLowerCase();
  return D.list.filter(d => (D.tab === 'on' ? d.online && !d.blocked : D.tab === 'off' ? !d.online && !d.blocked : D.tab === 'tr' ? totOf(d) > 0 || d.online : d.blocked) && (!q || (d.name + d.ip + d.mac).toLowerCase().includes(q))).sort(D.tab === 'tr' ? (a, b) => totOf(b) - totOf(a) : () => 0);
}
function connChip(d) {
  const sig = d.wifi && d.wifi.signal ? ` · ${esc(d.wifi.signal)} dBm` : '', tap = ` onclick="event.stopPropagation();connSheet('${d.mac}')"`;
  if (d.conn === 'wifi') return `<span class=chip${tap}>📶 Wi-Fi${sig}</span>`;
  if (d.conn === 'ap') return `<span class=chip${tap}>📡 ${esc(d.via || _('Точка доступа', 'Access point'))}${sig}</span>`;
  if (d.conn === 'apguess') return `<span class=chip${tap}>📶 Wi-Fi ≈</span>`;
  if (!d.online && !d.manualConn) return '';
  return `<span class=chip${tap}>🔌 ${d.manualConn ? _('Кабель', 'Wired') : 'LAN'}${d.via ? ' · ' + esc(d.via) : ''}</span>`;
}
function connBulk() {
  const r = reg(), list = D.list.slice(0, 40);
  sheet(`<h3>📡 ${_('Как подключены устройства', 'How devices are connected')}</h3><p class=sub>${_('Задайте способ подключения для каждого устройства. «Авто» оставляет определение роутеру.', 'Set the connection method per device. "Auto" leaves detection to the router.')}</p>` +
    list.map((d, i) => `<div class=row><div class=rl>${L.ICONS[d.icon] || '❓'} ${esc(d.name || d.ip || d.mac)}</div><select id=cb${i} style="width:auto;margin:0;padding:8px"><option value="" ${!(r[d.mac] || {}).c ? 'selected' : ''}>${_('Авто', 'Auto')}</option><option value="wifi" ${(r[d.mac] || {}).c === 'wifi' ? 'selected' : ''}>Wi-Fi</option><option value="ap" ${(r[d.mac] || {}).c === 'ap' ? 'selected' : ''}>${_('Через точку', 'Via AP')}</option><option value="lan" ${(r[d.mac] || {}).c === 'lan' ? 'selected' : ''}>${_('Кабель', 'Wired')}</option></select></div>`).join('') +
    `<div class=g2><button onclick="closeSheet()">${_('Отмена', 'Cancel')}</button><button class=p onclick="connBulkSave()">${_('Сохранить', 'Save')}</button></div>`);
}
function connBulkSave() {
  const x = reg();
  D.list.slice(0, 40).forEach((d, i) => { const e = $('#cb' + i); if (!e) return; const v = e.value; x[d.mac] = x[d.mac] || {}; if (v) x[d.mac].c = v; else { delete x[d.mac].c; delete x[d.mac].via; } });
  saveReg(x); closeSheet(); loadDev(true).then(() => { if (page === 'dev') renderDev(); }); toast(_('Сохранено', 'Saved'));
}
function trCard(d, mx) {
  const t = D.tot[d.mac], a = D.acc[d.mac] || { rx: 0, tx: 0 }, rx = t ? t.rx : a.rx, tx = t ? t.tx : a.tx, sp = D.sp[d.ip], w = mx ? Math.max(2, Math.round((rx + tx) / mx * 100)) : 0;
  return `<div class=dv onclick="devSheet('${d.mac}')"><div class=ic>${L.ICONS[d.icon] || '❓'}</div><div class=dm><b>${esc(d.name || d.ip || d.mac)}</b><div class=bar style="margin:6px 0 4px"><i class=low style="width:${w}%"></i></div><small>↓ ${L.fmtB(rx)} · ↑ ${L.fmtB(tx)} · Σ ${L.fmtB(rx + tx)}</small></div><div class=spd>${d.online ? `<span class=dn>↓ ${L.fmtR(sp ? sp.down : 0)}</span><span class=upc>↑ ${L.fmtR(sp ? sp.up : 0)}</span>` : ''}</div></div>`;
}
function devCard(d) {
  const sp = D.sp[d.ip], t = D.tot[d.mac];
  const chips = connChip(d) + (d.name ? '' : `<span class="chip warn" onclick="event.stopPropagation();renameDev('${d.mac}')">✏️ ${_('задать имя', 'set name')}</span>`) +
    (d.pc ? `<span class="chip warn">🕒 ${_('Расписание', 'Schedule')}</span>` : '') + (d.fav ? '<span class=chip>★</span>' : '') +
    (t ? `<span class=chip>Σ ${L.fmtB(t.rx + t.tx)}</span>` : '');
  let r = '';
  if (d.blocked) r = `<button class="pw un" onclick="event.stopPropagation();blk('${d.mac}',0)">🔓<small>${_('Разблок.', 'Unblock')}</small></button>`;
  else if (d.online) r = `<div class=spd><span class=dn>↓ ${L.fmtR(sp ? sp.down : 0)}</span><span class=upc>↑ ${L.fmtR(sp ? sp.up : 0)}</span></div>`;
  else r = `<button class=pw onclick="event.stopPropagation();wolDev('${d.mac}')">${PWR}<small>${_('Включить', 'Power on')}</small></button>`;
  return `<div class="dv ${d.online ? 'on' : ''}" onclick="devSheet('${d.mac}')"><div class=ic>${L.ICONS[d.icon] || '❓'}</div><div class=dm><b>${esc(d.name || d.ip || d.mac)}</b><small>${esc((d.ip || '—') + ' · ' + d.mac)}</small><div>${chips}</div></div>${r}</div>`;
}
function renderDev() {
  const c = devCount(), list = devVisible();
  let banner = '';
  if (!D.nl) banner += `<div class=card style="padding:12px"><div class=sub style="margin:0 0 8px">📊 ${_('Чтобы видеть, сколько трафика съело каждое устройство, нужен учёт трафика.', 'To see how much traffic each device used, traffic accounting is needed.')}</div><button class=p onclick="enableNl()">${_('Включить учёт трафика', 'Enable traffic accounting')}</button></div>`;
  if (!D.hasCT) banner += `<div class=sub>${_('Скорость по устройствам пока недоступна: на роутере нет счётчиков соединений (conntrack). Если включён аппаратный ускоритель, счётчики могут не работать.', 'Per-device speed is unavailable: no connection counters (conntrack) on the router. Hardware flow offloading may prevent counters.')}</div>`;
  const keep = $('#dq') ? $('#dq').value : D.q;
  if (D.tab === 'tr') banner += `<div class=sub>${D.nl ? _('Данные учёта nlbwmon за текущий период.', 'nlbwmon accounting data for the current period.') : _('Считается, пока приложение открыто (примерно). Для точного постоянного учёта включите nlbwmon.', 'Counted while the app is open (approximate). Enable nlbwmon for exact, permanent accounting.')} <span class=chip onclick="accReset()">${_('Сбросить', 'Reset')}</span></div>`;
  if (rs.length === 1 && !LS.get('hint_ap', 0) && D.tab === 'on' && D.list.some(x => x.conn === 'apguess')) banner += `<div class=card style="padding:12px"><div class=sub style="margin:0 0 8px">📡 ${_('Роутер не видит, к какой точке доступа подключены часть устройств. Добавьте вторую точку (например, D-Link) как роутер: устройства на её Wi-Fi определятся сами. Или задайте способ вручную: нажмите на значок подключения у устройства.', 'This router cannot see which access point some devices use. Add the second access point (e.g. D-Link) as a router and devices on its Wi-Fi are detected automatically. Or set it manually: tap the connection badge on a device.')}</div><div class=grid><button class=p onclick="go('rt')">${_('Добавить роутер', 'Add router')}</button><button onclick="LS.set('hint_ap',1);renderDev()">${_('Понятно', 'Got it')}</button></div></div>`;
  V(`<div class=hd><h1>${_('Устройства', 'Devices')}</h1><button class=s onclick="connBulk()">📡</button></div>` +
    H.seg([['on', `${_('В сети', 'Online')} · ${c.on}`], ['off', `${_('Не в сети', 'Offline')} · ${c.off}`], ['tr', _('Трафик', 'Traffic')], ['bl', `${_('Блок', 'Blocked')} · ${c.bl}`]], D.tab, 'devTab') +
    `<input type=text id=dq placeholder="🔎 ${_('Поиск', 'Search')}" value="${esc(keep)}" oninput="D.q=this.value;renderDevList()">` + banner +
    `<div id=dl>${list.map(devCard).join('') || `<div class=sub style="text-align:center;margin-top:30px">${_('Пусто', 'Nothing here')}</div>`}</div>`);
}
function renderDevList() { const e = $('#dl'); if (e) e.innerHTML = devVisible().map(x => D.tab === 'tr' ? trCard(x, Math.max.apply(null, [1].concat(D.list.map(totOf)))) : devCard(x)).join('') || `<div class=sub style="text-align:center;margin-top:30px">${_('Пусто', 'Nothing here')}</div>`; }
function devTab(k) { D.tab = k; renderDev(); }
P.dev = async () => {
  await loadDev(true); accLoad();
  sh('sysctl -w net.netfilter.nf_conntrack_acct=1 >/dev/null 2>&1; [ -f /etc/sysctl.d/99-routerhub.conf ] || echo net.netfilter.nf_conntrack_acct=1 > /etc/sysctl.d/99-routerhub.conf').catch(() => { });
  await ctSample().catch(() => { });
  await nlTotals().catch(() => { });
  renderDev();
  D.tick = 0;
  timer = setInterval(async () => {
    try {
      D.tick++;
      if (D.tick % 5 === 0) { await loadDev(true); await nlTotals(); accSave(); renderDev(); }
      else { await ctSample(); if (!$('#sheet').innerHTML) renderDevList(); }
    } catch (e) { }
  }, 3000);
};
async function enableNl() {
  if (!await need(['nlbwmon'], _('Учёт трафика', 'Traffic accounting'))) return;
  await sh('/etc/init.d/nlbwmon enable; /etc/init.d/nlbwmon start; true');
  toast(_('Учёт включён. Данные появятся через пару минут.', 'Enabled. Data will appear in a couple of minutes.'));
}
// ---------- device actions ----------
const dget = m => D.list.find(x => x.mac === m);
function devSheet(mac) {
  const d = dget(mac); if (!d) return;
  const t = D.tot[mac], sp = D.sp[d.ip];
  const tile = (ic, lb, fn) => `<button class=tl onclick="${fn}"><span>${ic}</span>${lb}</button>`;
  sheet(`<div class=sh-hd><div class=ic>${L.ICONS[d.icon] || '❓'}</div><div style="flex:1"><b>${esc(d.name || d.ip || d.mac)}</b><small>${esc((d.ip || '—') + ' · ' + d.mac)}</small><small>${connChip(d).replace(/<[^>]+>/g, '')}</small></div><button class=s onclick="renameDev('${mac}')">✏️</button></div>` +
    `<div class=grid style="margin-bottom:10px"><div class=st><span>${_('Сейчас', 'Now')}</span><b>${d.online ? '↓ ' + L.fmtR(sp ? sp.down : 0) : _('не в сети', 'offline')}</b><span>${d.online ? '↑ ' + L.fmtR(sp ? sp.up : 0) : ''}</span></div><div class=st><span>${_('Потреблено', 'Used')}</span><b>${t ? L.fmtB(t.rx + t.tx) : '—'}</b><span>${t ? '↓ ' + L.fmtB(t.rx) + ' · ↑ ' + L.fmtB(t.tx) : _('нужен учёт трафика', 'needs accounting')}</span></div></div>` +
    (D.hist[mac] && D.hist[mac].length > 2 ? `<div class=card style="padding:10px;margin-bottom:10px"><div class=sub style="margin:0 0 4px">${_('Скорость загрузки за последние минуты', 'Download speed over the last minutes')}</div>${spark(D.hist[mac], 'low')}</div>` : '') + `<div class=tiles>` +
    (!d.online ? tile('⏻', _('Включить', 'Power on'), `closeSheet();wolDev('${mac}')`) : '') +
    tile('✏️', _('Название', 'Rename'), `renameDev('${mac}')`) + tile('🎨', _('Иконка', 'Icon'), `iconSheet('${mac}')`) + tile('📡', _('Подключение', 'Connection'), `connSheet('${mac}')`) +
    tile(d.fav ? '★' : '☆', d.fav ? _('Убрать с главной', 'Unpin') : _('На главную', 'Pin to home'), `favDev('${mac}')`) +
    tile(d.blocked ? '🔓' : '🚫', d.blocked ? _('Разблокировать', 'Unblock') : _('Блок интернета', 'Block internet'), `closeSheet();blk('${mac}',${d.blocked ? 0 : 1})`) +
    tile('🕒', _('Родит. контроль', 'Parental'), `pcSheet('${mac}')`) +
    tile('📌', d.static ? _('IP закреплён', 'IP pinned') : _('Закрепить IP', 'Pin IP'), `fixIP('${mac}')`) +
    (d.wifi ? tile('📴', _('Отключить от Wi-Fi', 'Kick from Wi-Fi'), `closeSheet();kick('${mac}')`) : '') + `</div>`);
}
function connSheet(mac) {
  const d = dget(mac), r = reg()[mac] || {};
  form(_('Как подключено устройство', 'How the device is connected'), [
    { k: 'c', t: 'select', l: _('Способ подключения', 'Connection method'), v: r.c || '', o: [['', _('Определять автоматически', 'Detect automatically')], ['wifi', _('Wi-Fi этого роутера', 'Wi-Fi of this router')], ['ap', _('Wi-Fi другой точки доступа', 'Wi-Fi of another access point')], ['lan', _('Кабель (LAN)', 'Wired (LAN)')]], custom: 0 },
    { k: 'via', t: 'text', l: _('Через что (название точки, порта)', 'Via (access point or port name)'), v: r.via || '', p: 'D-Link / lan2', show: g => g('c') === 'ap' || g('c') === 'lan' }
  ], async v => {
    const x = reg(); x[mac] = Object.assign(x[mac] || {}, { c: v[0], via: (v[0] === 'ap' || v[0] === 'lan') ? String(v[1]).trim().slice(0, 40) : '' });
    if (!v[0]) { delete x[mac].c; delete x[mac].via; }
    saveReg(x); await loadDev(true); if (page === 'dev') renderDev(); toast(_('Сохранено', 'Saved'));
  }, '', _('Если роутер показывает неверно (например, Wi-Fi устройства за точкой доступа), задайте способ вручную.', 'If the router shows it wrongly (e.g. a Wi-Fi device behind an access point), set it manually.'));
}
async function renameDev(mac) {
  const d = dget(mac), v = await askText(_('Название устройства', 'Device name'), _('Пусто = вернуть имя по умолчанию', 'Empty = restore default name'), d.name);
  if (v === null) return;
  const r = reg(); r[mac] = Object.assign(r[mac] || {}, { n: v.trim() }); if (!r[mac].n) delete r[mac].n;
  saveReg(r); await loadDev(true); renderDev(); toast(_('Сохранено', 'Saved'));
}
function iconSheet(mac) {
  sheet(`<h3>${_('Иконка устройства', 'Device icon')}</h3><div class=icons>` + Object.keys(L.ICONS).map(k => `<button class=ib onclick="setIcon('${mac}','${k}')"><span>${L.ICONS[k]}</span><small>${_(L.ICON_NAMES[k][0], L.ICON_NAMES[k][1])}</small></button>`).join('') + `</div><button style="margin-top:10px" onclick="setIcon('${mac}','')">${_('Определять автоматически', 'Detect automatically')}</button>`);
}
async function setIcon(mac, k) {
  const r = reg(); r[mac] = Object.assign(r[mac] || {}, k ? { i: k } : {}); if (!k) delete r[mac].i;
  saveReg(r); closeSheet(); await loadDev(true); renderDev();
}
async function favDev(mac) { const r = reg(); r[mac] = Object.assign(r[mac] || {}, { fav: !(r[mac] && r[mac].fav) }); saveReg(r); closeSheet(); await loadDev(true); if (page === 'dev') renderDev(); toast('✓'); }
async function wolDev(mac) {
  if (!L.isMac(mac)) return;
  if (!await need(['etherwake'], _('Включение устройства по сети', 'Wake-on-LAN'))) return;
  try { await sh(`etherwake -b -i ${L.shq(D.lan)} ${mac}`); toast('⏻ ' + _('Сигнал включения отправлен', 'Wake signal sent')); } catch (e) { toast(e.message); }
}
async function blk(mac, on) {
  if (!L.isMac(mac)) return;
  const d = dget(mac);
  if (on && !await ask(_('Заблокировать интернет?', 'Block internet?'), (d && d.name || mac) + ' — ' + _('устройство останется в сети, но интернет у него пропадёт.', 'stays on the network but loses internet access.'), _('Заблокировать', 'Block'), true)) return;
  try {
    if (on) await U.add('firewall', 'rule', L.blockRule(mac).name, L.blockRule(mac));
    else await U.del('firewall', 'rh_block_' + L.m12(mac));
    await applyCfg('firewall'); await loadDev(true); if (page === 'dev') renderDev(); toast(on ? _('Заблокировано', 'Blocked') : _('Разблокировано', 'Unblocked'));
  } catch (e) { toast(e.message); }
}
let PCD = new Set();
const DAYS_UI = [['Mon', 'Пн', 'Mo'], ['Tue', 'Вт', 'Tu'], ['Wed', 'Ср', 'We'], ['Thu', 'Чт', 'Th'], ['Fri', 'Пт', 'Fr'], ['Sat', 'Сб', 'Sa'], ['Sun', 'Вс', 'Su']];
function pcSheet(mac) {
  const d = dget(mac), p = d.pc || { from: '22:00', to: '07:00', days: L.DAYS.slice() };
  PCD = new Set(p.days);
  sheet(`<h3>🕒 ${_('Родительский контроль', 'Parental control')}</h3><p class=sub>${_('В выбранное время у устройства будет отключён интернет.', 'Internet is cut for this device during the chosen time.')}</p>` +
    `<div class=g2><div><label class=fl>${_('С', 'From')}</label><input type=time id=pf value="${esc(p.from || '22:00')}"></div><div><label class=fl>${_('До', 'To')}</label><input type=time id=pt value="${esc(p.to || '07:00')}"></div></div>` +
    `<div class=days>` + DAYS_UI.map(x => `<button id=dy_${x[0]} class="${PCD.has(x[0]) ? 'a' : ''}" onclick="pcDay('${x[0]}')">${_(x[1], x[2])}</button>`).join('') + `</div>` +
    `<div class=g2><button onclick="closeSheet()">${_('Отмена', 'Cancel')}</button><button class=p onclick="pcSave('${mac}')">${_('Сохранить', 'Save')}</button></div>` +
    (d.pc ? `<button class=d style="margin-top:8px" onclick="pcDel('${mac}')">${_('Убрать расписание', 'Remove schedule')}</button>` : ''));
}
function pcDay(k) { if (PCD.has(k)) PCD.delete(k); else PCD.add(k); const e = $('#dy_' + k); if (e) e.className = PCD.has(k) ? 'a' : ''; }
async function pcClear(mac) { for (const s of ['s', 'a', 'b']) { await U.del('firewall', `rh_pc_${L.m12(mac)}_${s}`).catch(() => { }); } }
async function pcSave(mac) {
  const f = $('#pf').value, t = $('#pt').value, days = DAYS_UI.map(x => x[0]).filter(x => PCD.has(x));
  if (!f || !t || f === t) return toast(_('Укажите разное время начала и конца', 'Start and end times must differ'));
  if (!days.length) return toast(_('Выберите дни', 'Pick at least one day'));
  try {
    await pcClear(mac);
    for (const r of L.pcRules(mac, f, t, days)) await U.add('firewall', 'rule', r.name, r);
    await applyCfg('firewall'); closeSheet(); await loadDev(true); if (page === 'dev') renderDev(); toast(_('Расписание сохранено', 'Schedule saved'));
  } catch (e) { toast(e.message); }
}
async function pcDel(mac) { try { await pcClear(mac); await applyCfg('firewall'); closeSheet(); await loadDev(true); renderDev(); } catch (e) { toast(e.message); } }
async function fixIP(mac) {
  const d = dget(mac);
  if (d.static) { if (await ask(_('Открепить IP?', 'Unpin IP?'), d.static.ip, _('Открепить', 'Unpin'))) { await U.del('dhcp', d.static.sec); await applyCfg('dhcp'); await loadDev(true); renderDev(); } return; }
  const v = await askText(_('Закрепить IP', 'Pin IP address'), _('IP-адрес для этого устройства', 'IP address for this device'), d.ip);
  if (v === null) return;
  if (!L.isIP(v.trim())) return toast(_('Неверный IP', 'Invalid IP'));
  try { await U.add('dhcp', 'host', 'rh_' + L.m12(mac), { name: (d.name || 'device').replace(/[^\w-]/g, '_').slice(0, 30) || 'device', mac, ip: v.trim() }); await applyCfg('dhcp'); await loadDev(true); renderDev(); toast(_('Закреплено', 'Pinned')); } catch (e) { toast(e.message); }
}
async function kick(mac) {
  if (!L.isMac(mac)) return;
  await sh(`for i in $(ubus list 'hostapd.*'); do ubus call $i del_client '{"addr":"${mac}","reason":5,"deauth":true,"ban_time":30000}' 2>/dev/null; done; true`);
  toast(_('Отключено на 30 секунд', 'Disconnected for 30 seconds'));
}
