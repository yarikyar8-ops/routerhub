'use strict';
const sid = k => /^[\w.-]+$/.test(String(k));
const tile = (ic, lb, ds, fn) => `<button class=hub onclick="${fn}"><span>${ic}</span><b>${lb}</b><small>${ds}</small></button>`;
P.set = async () => {
  V(H.hd(_('Настройки', 'Settings')) + `<div class=hubs>` +
    tile('📶', 'Wi-Fi', _('Сети, пароли, каналы', 'Networks, passwords, channels'), "go('wifi')") +
    tile('🌐', _('Сеть и DHCP', 'Network & DHCP'), _('LAN, DNS, закреп IP', 'LAN, DNS, static IPs'), "go('net')") +
    tile('🛡️', _('Порты', 'Ports'), _('Проброс портов', 'Port forwarding'), "go('fw')") +
    tile('⚙️', _('Сервисы', 'Services'), _('Запуск и остановка', 'Start and stop'), "go('svc')") +
    tile('🧩', _('Плагины', 'Plugins'), _('Библиотека пакетов', 'Package library'), "go('pkgs')") +
    tile('🖥️', _('Система', 'System'), _('Имя, время, пароль', 'Name, time, password'), "go('sys')") +
    tile('⌨️', 'SSH', _('Терминал', 'Terminal'), "go('ssh')") +
    tile('📜', _('Журнал', 'Log'), _('Системные сообщения', 'System messages'), "go('logs')") +
    tile('🛠', _('Редактор UCI', 'UCI editor'), _('Все параметры роутера', 'Every router option'), "go('uci')") +
    tile('🌍', 'LuCI', _('Полный веб-интерфейс', 'Full web interface'), 'openLuci()') + `</div>`);
};
// ---------------- Wi-Fi ----------------
let WF = {};
const ENC = () => [['none', _('Без пароля', 'Open')], ['psk2', 'WPA2'], ['psk-mixed', 'WPA/WPA2'], ['sae', 'WPA3'], ['sae-mixed', 'WPA2/WPA3']];
P.wifi = async () => {
  WF = await U.get('wireless');
  const keys = Object.keys(WF).filter(sid), rad = keys.filter(k => WF[k]['.type'] === 'wifi-device'), ifs = keys.filter(k => WF[k]['.type'] === 'wifi-iface');
  V(H.hd('Wi-Fi', 'set') + rad.map(k => { const r = WF[k]; return H.card(`${esc(k)} · ${esc(r.band || r.hwmode || '')}`, H.row(_('Радиомодуль', 'Radio'), `${_('Канал', 'Channel')}: ${esc(r.channel || 'auto')} · ${esc(r.htmode || '')} · ${esc(r.country || '')}`, H.sw(r.disabled !== '1', `wfRadioTog('${k}',this.checked)`)) + `<button class=s style="margin:8px 0 0" onclick="wfRadio('${k}')">✏️ ${_('Параметры радио', 'Radio options')}</button>` +
    ifs.filter(i => WF[i].device === k).map(i => { const n = WF[i]; return H.row(`📡 ${esc(n.ssid || '—')}`, `${esc(n.mode || 'ap')} · ${esc(n.encryption || 'none')}`, H.sw(n.disabled !== '1', `wfIfTog('${i}',this.checked)`) + `<button class="s" onclick="wfIf('${i}')">✏️</button>`); }).join('')); }).join('') || H.card('', `<div class=sub>${_('Wi-Fi не найден', 'No Wi-Fi found')}</div>`));
};
async function wfApply(msg) {
  if (!await ask(msg, _('Wi-Fi перезапустится, подключение по нему может пропасть на несколько секунд.', 'Wi-Fi will restart; a connection over it may drop for a few seconds.'), _('Применить', 'Apply'))) return false;
  await applyCfg('wireless'); return true;
}
async function wfRadioTog(k, on) { try { await U.set('wireless', k, { disabled: on ? '0' : '1' }); if (!await wfApply(on ? _('Включить радио?', 'Enable radio?') : _('Выключить радио?', 'Disable radio?'))) { await U.del('wireless', k, ['disabled']).catch(() => { }); } } catch (e) { toast(e.message); } go('wifi'); }
async function wfIfTog(k, on) { try { await U.set('wireless', k, { disabled: on ? '0' : '1' }); await applyCfg('wireless'); } catch (e) { toast(e.message); } }
function wfIf(k) {
  const n = WF[k];
  form(_('Сеть Wi-Fi', 'Wi-Fi network'), [{ k: 'ssid', l: 'SSID', v: n.ssid || '' }, { k: 'enc', l: _('Защита', 'Security'), t: 'select', v: n.encryption || 'none', o: ENC() }, { k: 'key', l: _('Пароль (8+ символов)', 'Password (8+ chars)'), t: 'text', v: n.key || '' }, { k: 'hid', l: _('Скрытая сеть', 'Hidden network'), t: 'check', v: n.hidden === '1' }],
    async v => {
      if (!v[0]) throw new Error('SSID?');
      if (v[1] !== 'none' && v[2].length < 8) throw new Error(_('Пароль минимум 8 символов', 'Password needs 8+ characters'));
      const o = { ssid: v[0], encryption: v[1], hidden: v[3] ? '1' : '0' }; if (v[1] !== 'none') o.key = v[2];
      await U.set('wireless', k, o); await wfApply(_('Сохранить сеть?', 'Save network?')); go('wifi');
    });
}
function wfRadio(k) {
  const r = WF[k];
  form(_('Параметры радио', 'Radio options'), [{ l: _('Канал (auto или число)', 'Channel (auto or number)'), v: r.channel || 'auto' }, { l: _('Ширина канала', 'Channel width'), t: 'select', v: r.htmode || '', o: [['', _('по умолчанию', 'default')], ['HT20', 'HT20'], ['HT40', 'HT40'], ['VHT20', 'VHT20'], ['VHT40', 'VHT40'], ['VHT80', 'VHT80'], ['HE20', 'HE20'], ['HE40', 'HE40'], ['HE80', 'HE80']] }, { l: _('Страна (2 буквы)', 'Country (2 letters)'), v: r.country || '' }, { l: _('Мощность, dBm (пусто = макс.)', 'TX power, dBm (empty = max)'), v: r.txpower || '' }],
    async v => {
      if (v[0] !== 'auto' && !/^\d{1,3}$/.test(v[0])) throw new Error(_('Канал: auto или число', 'Channel: auto or number'));
      if (v[2] && !/^[A-Za-z]{2}$/.test(v[2])) throw new Error(_('Страна: 2 буквы', 'Country: 2 letters'));
      await U.set('wireless', k, { channel: v[0] }); const dl = [];
      for (const [o, val] of [['htmode', v[1]], ['country', v[2].toUpperCase()], ['txpower', v[3]]]) { if (val) await U.set('wireless', k, { [o]: val }); else dl.push(o); }
      if (dl.length) await U.del('wireless', k, dl).catch(() => { });
      await wfApply(_('Сохранить параметры?', 'Save options?')); go('wifi');
    });
}
// ---------------- Network & DHCP ----------------
P.net = async () => {
  const [n, d] = await Promise.all([U.get('network'), U.get('dhcp')]);
  const lan = n.lan || {}, wan = n.wan || {}, dl = d.lan || {}, dm = Object.keys(d).find(k => d[k]['.type'] === 'dnsmasq'), dns = arr(dm && d[dm].server);
  const st = Object.keys(d).filter(k => d[k]['.type'] === 'host' && sid(k));
  NETS = { lan, dl, dm, dns };
  V(H.hd(_('Сеть и DHCP', 'Network & DHCP'), 'set') +
    H.card('LAN', H.row(_('Адрес роутера', 'Router address'), `${esc(lan.ipaddr || '—')} / ${esc(lan.netmask || '')}`, '✏️', 'lanEdit()') + H.row(_('Пул DHCP', 'DHCP pool'), `${_('начало', 'start')} ${esc(dl.start || '100')}, ${_('адресов', 'size')} ${esc(dl.limit || '150')}, ${_('аренда', 'lease')} ${esc(dl.leasetime || '12h')}`, '✏️', 'dhcpEdit()')) +
    H.card('WAN', H.row(esc(wan.proto || '—'), esc(wan.ipaddr || wan.device || ''), '')) +
    H.card('DNS', H.row(dns.length ? esc(dns.join(', ')) : _('Системные (от провайдера)', 'System (from ISP)'), '', '✏️', 'dnsEdit()')) +
    H.card(_('Закреплённые адреса', 'Static leases'), (st.map(k => H.row(esc(d[k].name || '—'), `${esc([].concat(d[k].mac || '')[0])} → ${esc(d[k].ip || '')}`, `<button class="s d" onclick="stDel('${k}')">🗑</button>`)).join('') || `<div class=sub style="margin:0 0 8px">${_('Нет', 'None')}</div>`) + `<button style="margin-top:8px" onclick="stAdd()">➕ ${_('Закрепить адрес', 'Add static lease')}</button>`));
};
let NETS = {};
function lanEdit() {
  form(_('Адрес LAN', 'LAN address'), [{ l: 'IP', v: NETS.lan.ipaddr || '' }, { l: _('Маска', 'Netmask'), v: NETS.lan.netmask || '255.255.255.0' }],
    async v => {
      if (!L.isIP(v[0]) || !L.isIP(v[1])) throw new Error(_('Неверный IP или маска', 'Invalid IP or netmask'));
      if (!await ask(_('Сменить адрес роутера?', 'Change router address?'), _('Сеть перезапустится, подключение пропадёт. Приложение запомнит новый адрес, но устройствам нужно переподключиться.', 'The network will restart and the connection will drop. The app will remember the new address, but devices must reconnect.'), _('Сменить', 'Change'), true)) throw new Error(_('Отменено', 'Cancelled'));
      await U.set('network', 'lan', { ipaddr: v[0], netmask: v[1] });
      const old = base(R()).replace(/^https?:\/\//, '').split(':')[0]; if (old === NETS.lan.ipaddr) { R().a = v[0]; saveRs(); }
      await applyCfg('network'); toast(_('Применяется…', 'Applying…'));
    });
}
function dhcpEdit() {
  const d = NETS.dl;
  form(_('Пул DHCP', 'DHCP pool'), [{ l: _('Начало (число)', 'Start (number)'), v: d.start || '100' }, { l: _('Количество адресов', 'Number of addresses'), v: d.limit || '150' }, { l: _('Время аренды (12h, 1d)', 'Lease time (12h, 1d)'), v: d.leasetime || '12h' }],
    async v => { if (!/^\d+$/.test(v[0]) || !/^\d+$/.test(v[1]) || !/^\d+[smhdw]?$/.test(v[2])) throw new Error(_('Неверные значения', 'Invalid values')); await U.set('dhcp', 'lan', { start: v[0], limit: v[1], leasetime: v[2] }); await applyCfg('dhcp'); go('net'); });
}
function dnsEdit() {
  form(_('DNS-серверы', 'DNS servers'), [{ l: _('По одному в строке (пусто = по умолчанию)', 'One per line (empty = default)'), t: 'area', v: NETS.dns.join('\n') }],
    async v => {
      const l = v[0].split('\n').map(x => x.trim()).filter(Boolean);
      if (!l.every(x => /^[\w.:#@/-]+$/.test(x))) throw new Error(_('Неверный формат', 'Invalid format'));
      if (!NETS.dm) throw new Error('dnsmasq?');
      if (l.length) await U.set('dhcp', NETS.dm, { server: l }); else await U.del('dhcp', NETS.dm, ['server']).catch(() => { });
      await applyCfg('dhcp'); go('net');
    });
}
async function stDel(k) { try { await U.del('dhcp', k); await applyCfg('dhcp'); go('net'); } catch (e) { toast(e.message); } }
function stAdd() {
  form(_('Закрепить адрес', 'Static lease'), [{ l: _('Имя', 'Name'), v: '' }, { l: 'MAC', v: '' }, { l: 'IP', v: '' }],
    async v => {
      const mac = v[1].trim().toLowerCase();
      if (!L.isMac(mac) || !L.isIP(v[2].trim())) throw new Error(_('Неверный MAC или IP', 'Invalid MAC or IP'));
      await U.add('dhcp', 'host', 'rh_' + L.m12(mac), { name: v[0].replace(/[^\w-]/g, '_') || 'device', mac, ip: v[2].trim() }); await applyCfg('dhcp'); go('net');
    });
}
// ---------------- Firewall: port forwarding ----------------
P.fw = async () => {
  const f = await U.get('firewall');
  const rd = Object.keys(f).filter(k => f[k]['.type'] === 'redirect' && sid(k)), zn = Object.keys(f).filter(k => f[k]['.type'] === 'zone');
  V(H.hd(_('Проброс портов', 'Port forwarding'), 'set') +
    H.card(_('Правила', 'Rules'), (rd.map(k => { const x = f[k]; return H.row(esc(x.name || k), `${esc(x.proto || 'tcp')} :${esc(x.src_dport || '?')} → ${esc(x.dest_ip || '')}:${esc(x.dest_port || x.src_dport || '')}`, H.sw(x.enabled !== '0', `rdTog('${k}',this.checked)`) + `<button class="s d" onclick="rdDel('${k}')">🗑</button>`); }).join('') || `<div class=sub style="margin:0 0 8px">${_('Нет правил', 'No rules')}</div>`) + `<button style="margin-top:8px" onclick="rdAdd()">➕ ${_('Добавить', 'Add')}</button>`) +
    H.card(_('Зоны', 'Zones'), zn.map(k => H.row(esc(f[k].name), `${_('вход', 'in')}: ${esc(f[k].input || '')} · ${_('выход', 'out')}: ${esc(f[k].output || '')} · ${_('пересылка', 'fwd')}: ${esc(f[k].forward || '')}`, '')).join('')));
};
async function rdTog(k, on) { try { await U.set('firewall', k, { enabled: on ? '1' : '0' }); await applyCfg('firewall'); } catch (e) { toast(e.message); } }
async function rdDel(k) { if (await ask(_('Удалить правило?', 'Delete rule?'), '', _('Удалить', 'Delete'), true)) { try { await U.del('firewall', k); await applyCfg('firewall'); } catch (e) { toast(e.message); } go('fw'); } }
function rdAdd() {
  form(_('Проброс порта', 'Port forward'), [{ l: _('Название', 'Name'), v: '' }, { l: _('Протокол', 'Protocol'), t: 'select', v: 'tcp', o: [['tcp', 'TCP'], ['udp', 'UDP'], ['tcp udp', 'TCP+UDP']] }, { l: _('Внешний порт', 'External port'), v: '' }, { l: _('IP устройства', 'Device IP'), v: '' }, { l: _('Порт устройства (пусто = тот же)', 'Device port (empty = same)'), v: '' }],
    async v => {
      if (!L.isPort(v[2]) || !L.isIP(v[3].trim()) || (v[4] && !L.isPort(v[4]))) throw new Error(_('Проверьте порты и IP', 'Check ports and IP'));
      const nm = 'rh_pf_' + Date.now().toString(36);
      await U.add('firewall', 'redirect', nm, L.redirect({ name: v[0].replace(/[^\w -]/g, '') || nm, ext: v[2], ip: v[3].trim(), port: v[4] || v[2], proto: v[1] })); await applyCfg('firewall'); go('fw');
    });
}
// ---------------- System ----------------
const TZ = [['Europe/Kaliningrad', 'EET-2', 'Калининград'], ['Europe/Moscow', 'MSK-3', 'Москва'], ['Europe/Samara', '<+04>-4', 'Самара'], ['Asia/Yekaterinburg', '<+05>-5', 'Екатеринбург'], ['Asia/Omsk', '<+06>-6', 'Омск'], ['Asia/Novosibirsk', '<+07>-7', 'Новосибирск'], ['Asia/Krasnoyarsk', '<+07>-7', 'Красноярск'], ['Asia/Irkutsk', '<+08>-8', 'Иркутск'], ['Asia/Vladivostok', '<+10>-10', 'Владивосток'], ['Europe/Minsk', '<+03>-3', 'Минск'], ['Europe/Kiev', 'EET-2EEST,M3.5.0/3,M10.5.0/4', 'Киев'], ['Europe/Berlin', 'CET-1CEST,M3.5.0,M10.5.0/3', 'Berlin'], ['Europe/London', 'GMT0BST,M3.5.0/1,M10.5.0', 'London'], ['America/New_York', 'EST5EDT,M3.2.0,M11.1.0', 'New York'], ['UTC', 'UTC0', 'UTC']];
P.sys = async () => {
  const sy = await U.get('system'), k = Object.keys(sy).find(x => sy[x]['.type'] === 'system'), s = sy[k] || {};
  SYS = { k, s };
  V(H.hd(_('Система', 'System'), 'set') +
    H.card('', H.row(_('Имя роутера', 'Hostname'), esc(s.hostname || ''), '✏️', 'hostEdit()') + H.row(_('Часовой пояс', 'Time zone'), esc(s.zonename || s.timezone || ''), '✏️', 'tzEdit()') + H.row(_('Пароль root', 'Root password'), '', '✏️', 'pwEdit()')) +
    H.card(_('Питание', 'Power'), `<div class=grid><button class=d onclick="rebootAsk()">🔄 ${_('Перезагрузка', 'Reboot')}</button><button class=d onclick="offAsk()">⏻ ${_('Выключить', 'Power off')}</button></div><button style="margin-top:8px" onclick="ntpNow()">🕒 ${_('Синхронизировать время', 'Sync time now')}</button>`));
};
let SYS = {};
function hostEdit() { form(_('Имя роутера', 'Hostname'), [{ l: _('Имя', 'Name'), v: SYS.s.hostname || '' }], async v => { if (!/^[A-Za-z0-9-]{1,63}$/.test(v[0])) throw new Error(_('Только латиница, цифры, дефис', 'Letters, digits, hyphen only')); await U.set('system', SYS.k, { hostname: v[0] }); await applyCfg('system'); go('sys'); }); }
function tzEdit() { form(_('Часовой пояс', 'Time zone'), [{ l: _('Пояс', 'Zone'), t: 'select', v: SYS.s.zonename || '', o: TZ.map(x => [x[0], x[2] + ' · ' + x[0]]) }], async v => { const z = TZ.find(x => x[0] === v[0]); if (!z) throw new Error('?'); await U.set('system', SYS.k, { zonename: z[0], timezone: z[1] }); await applyCfg('system'); go('sys'); }); }
function pwEdit() {
  form(_('Пароль root', 'Root password'), [{ l: _('Новый пароль', 'New password'), t: 'password', v: '' }, { l: _('Повторите', 'Repeat'), t: 'password', v: '' }],
    async v => {
      if (v[0].length < 6 || v[0] !== v[1]) throw new Error(_('Пароли не совпадают или короче 6 символов', 'Passwords differ or are shorter than 6 characters'));
      try { await call(R(), 'luci', 'setPassword', { username: 'root', password: v[0] }); } catch (e) { await sh(`printf '%s\\n%s\\n' ${L.shq(v[0])} ${L.shq(v[0])} | passwd root`); }
      R().p = v[0]; saveRs(); toast(_('Пароль изменён', 'Password changed'));
    });
}
async function offAsk() { if (await ask(_('Выключить роутер?', 'Power off the router?'), _('Включить его снова можно только кнопкой питания.', 'You can turn it on again only with the power button.'), _('Выключить', 'Power off'), true)) { await sh('poweroff &\ntrue'); } }
async function ntpNow() { await sh('/etc/init.d/sysntpd restart; true'); toast(_('Готово', 'Done')); }
// ---------------- Services ----------------
const SV = { list: [], f: 'all', q: '' };
const SVCMD = 'for f in /etc/init.d/*; do n=${f##*/}; case $n in README|rcS|rc.*) continue;; esac; e=0; r=0; $f enabled >/dev/null 2>&1 && e=1; $f running >/dev/null 2>&1 && r=1; echo "$n|$e|$r"; done; true';
P.svc = async () => { SV.list = L.parseServices(await out(SVCMD)); renderSvc(); };
const svcName = n => { const x = L.SVC[n]; return x ? { t: _(x[0], x[1]), i: x[2] } : { t: n, i: '🔧' }; };
function svcList() {
  const q = SV.q.toLowerCase();
  return SV.list.filter(s => (SV.f === 'all' || (SV.f === 'run' && s.run) || (SV.f === 'stop' && !s.run) || (SV.f === 'auto' && s.en)) && (!q || (s.name + svcName(s.name).t).toLowerCase().includes(q)))
    .sort((a, b) => (b.run - a.run) || a.name.localeCompare(b.name))
    .map(s => { const d = svcName(s.name); return `<div class="svc ${s.run ? 'on' : ''}"><div class=ic>${d.i}</div><div class=dm><b>${esc(d.t)}</b><small>${esc(s.name)} · ${s.run ? _('работает', 'running') : _('остановлен', 'stopped')} · ${s.en ? _('автозапуск', 'autostart') : _('вручную', 'manual')}</small></div><div class=sa><button class=s onclick="svcAct('${s.name}','${s.run ? 'stop' : 'start'}')">${s.run ? '⏹' : '▶'}</button><button class=s onclick="svcAct('${s.name}','restart')">🔄</button><button class=s onclick="svcAct('${s.name}','${s.en ? 'disable' : 'enable'}')">${s.en ? '🔕' : '🔔'}</button></div></div>`; }).join('') || `<div class=sub style="text-align:center">${_('Ничего не найдено', 'Nothing found')}</div>`;
}
function renderSvc() {
  const c = { all: SV.list.length, run: SV.list.filter(s => s.run).length, stop: SV.list.filter(s => !s.run).length, auto: SV.list.filter(s => s.en).length };
  V(H.hd(_('Сервисы', 'Services'), 'set') + H.seg([['all', `${_('Все', 'All')} · ${c.all}`], ['run', `${_('Работают', 'Running')} · ${c.run}`], ['stop', `${_('Стоят', 'Stopped')} · ${c.stop}`], ['auto', `${_('Автозапуск', 'Autostart')} · ${c.auto}`]], SV.f, 'svF') + `<input type=text id=sq placeholder="🔎 ${_('Поиск', 'Search')}" value="${esc(SV.q)}" oninput="SV.q=this.value;$('#sl').innerHTML=svcList()"><div id=sl>${svcList()}</div>`);
}
function svF(k) { SV.f = k; renderSvc(); }
async function svcAct(n, a) {
  if (!sid(n) || !['start', 'stop', 'restart', 'enable', 'disable'].includes(a)) return;
  if ((a === 'stop' || a === 'disable') && ['network', 'rpcd', 'uhttpd', 'dropbear'].includes(n) && !await ask(_('Это важный сервис', 'This is an important service'), _('Остановка может оборвать связь с роутером.', 'Stopping it may cut your connection to the router.'), _('Продолжить', 'Continue'), true)) return;
  await sh(`/etc/init.d/${n} ${a} >/dev/null 2>&1 &\ntrue`); await sleep(1500); SV.list = L.parseServices(await out(SVCMD)); renderSvc();
}
// ---------------- Plugin library ----------------
const PKCAT = [
  ['Скорость и сеть', 'Speed & network', [
    [['sqm-scripts', 'luci-app-sqm'], ['Умные очереди (SQM)', 'Smart queues (SQM)'], ['Убирает лаги и скачки пинга при загруженном канале.', 'Removes lag and ping spikes on a busy link.']],
    [['nlbwmon', 'luci-app-nlbwmon'], ['Учёт трафика', 'Traffic accounting'], ['Считает, сколько трафика съело каждое устройство.', 'Counts how much traffic each device used.']],
    [['etherwake'], ['Включение по сети (WoL)', 'Wake-on-LAN'], ['Нужен для кнопки включения ПК.', 'Needed for the power-on button.']],
    [['luci-app-upnp', 'miniupnpd-nftables'], ['UPnP', 'UPnP'], ['Автоматический проброс портов для игр и торрентов.', 'Automatic port mapping for games and torrents.']],
    [['luci-app-ddns', 'ddns-scripts'], ['Динамический DNS', 'Dynamic DNS'], ['Постоянное имя для домашнего IP.', 'A stable name for your home IP.']],
    [['wireguard-tools', 'luci-proto-wireguard'], ['WireGuard', 'WireGuard'], ['Современный VPN-протокол.', 'A modern VPN protocol.']]]],
  ['DNS и безопасность', 'DNS & security', [
    [['adblock-fast', 'luci-app-adblock-fast'], ['Блокировка рекламы', 'Ad blocking'], ['Фильтрует рекламу на уровне DNS для всей сети.', 'DNS-level ad filtering for the whole network.']],
    [['banip', 'luci-app-banip'], ['Блокировка IP (banip)', 'IP blocking (banip)'], ['Списки вредных адресов.', 'Lists of malicious addresses.']],
    [['https-dns-proxy', 'luci-app-https-dns-proxy'], ['DNS через HTTPS', 'DNS over HTTPS'], ['Шифрует DNS-запросы.', 'Encrypts DNS queries.']]]],
  ['Диагностика', 'Diagnostics', [
    [['htop'], ['htop', 'htop'], ['Монитор процессов.', 'Process monitor.']], [['tcpdump'], ['tcpdump', 'tcpdump'], ['Захват трафика.', 'Packet capture.']],
    [['mtr'], ['mtr', 'mtr'], ['Трассировка с потерями.', 'Traceroute with loss stats.']], [['iperf3'], ['iperf3', 'iperf3'], ['Замер скорости сети.', 'Network speed test.']],
    [['bind-dig'], ['dig', 'dig'], ['Проверка DNS.', 'DNS lookups.']], [['curl', 'ca-bundle'], ['curl + сертификаты', 'curl + certificates'], ['Нужны для загрузки подписок и обновлений.', 'Needed to fetch subscriptions and updates.']]]],
  ['Язык', 'Language', [
    [['luci-i18n-base-ru', 'luci-i18n-firewall-ru'], ['LuCI на русском', 'LuCI in Russian'], ['Русский веб-интерфейс.', 'Russian web interface.']]]],
  ['Для Подкопа', 'For Podkop', [
    [['kmod-nft-tproxy', 'jq', 'coreutils-base64'], ['Зависимости Podkop', 'Podkop dependencies'], ['Если установка Podkop просит эти пакеты.', 'If Podkop installation asks for these.']],
    [['sing-box'], ['sing-box', 'sing-box'], ['Ядро для прокси-маршрутизации.', 'Core for proxy routing.']]]]
];
const PKS = { inst: {}, up: [] };
P.pkgs = async () => { PKS.inst = await installed(); renderPkgs(); };
function renderPkgs() {
  V(H.hd(_('Плагины', 'Plugins'), 'set') +
    H.card(_('Обновления', 'Updates'), `<div class=grid><button class=p onclick="pkgCheck()">🔍 ${_('Проверить', 'Check')}</button><button onclick="pkgByName()">➕ ${_('Установить по имени', 'Install by name')}</button></div><div id=pu>${PKS.up.length ? pkgUpHtml() : ''}</div>`) +
    PKCAT.map(c => H.card(_(c[0], c[1]), c[2].map((p, i) => { const ok = p[0].every(n => n in PKS.inst); return H.row(`${_(p[1][0], p[1][1])} ${ok ? '<span class="chip ok">✓</span>' : ''}`, _(p[2][0], p[2][1]) + '<br>' + esc(p[0].join(' ')), `<button class="s ${ok ? 'd' : 'p'}" onclick="pkgToggle('${p[0].join(' ')}',${ok ? 0 : 1})">${ok ? _('Удалить', 'Remove') : _('Установить', 'Install')}</button>`); }).join(''))).join(''));
}
const pkgUpHtml = () => `<div class=sub style="margin:10px 0 6px">${PKS.up.map(x => `${esc(x.name)}: ${esc(x.from)} → ${esc(x.to)}`).join('<br>')}</div><button class=p onclick="pkgUpAll()">⬆ ${_('Обновить всё', 'Update all')}</button>`;
async function pkgToggle(names, on) {
  const l = names.split(' ').filter(L.okPkg); if (!l.length) return;
  if (!await ask(on ? _('Установить пакеты?', 'Install packages?') : _('Удалить пакеты?', 'Remove packages?'), l.join(', ') + (on ? '\n' + _('Роутеру нужен доступ в интернет.', 'The router needs internet access.') : ''), on ? _('Установить', 'Install') : _('Удалить', 'Remove'), !on)) return;
  const c = L.pmCmd(await pm());
  await jobSheet(on ? _('Установка', 'Installing') : _('Удаление', 'Removing'), on ? `${c.upd}; ${c.inst(l.join(' '))}` : c.rm(l.join(' ')));
  PKS.inst = await installed(); if (page === 'pkgs') renderPkgs();
}
async function pkgByName() {
  const v = await askText(_('Установить пакет', 'Install package'), _('Имя пакета (через пробел)', 'Package name(s), space separated'), ''); if (!v) return;
  const l = v.trim().split(/\s+/); if (!l.every(L.okPkg)) return toast(_('Недопустимое имя', 'Invalid name'));
  await pkgToggle(l.join(' '), 1);
}
async function pkgCheck() {
  const c = L.pmCmd(await pm());
  if (await jobSheet(_('Обновление списков', 'Refreshing lists'), c.upd) !== 0) return;
  PKS.up = L.parseUpgradable(await out(c.up)); renderPkgs();
  if (!PKS.up.length) toast(_('Всё актуально', 'Everything is up to date'));
}
async function pkgUpAll() {
  const names = PKS.up.map(x => x.name).filter(L.okPkg), c = L.pmCmd(await pm());
  if (!names.length) return;
  await jobSheet(_('Обновление', 'Updating'), c.upg(names.join(' '))); PKS.up = []; PKS.inst = await installed(); renderPkgs();
}
// ---------------- UCI editor ----------------
let UE = { cfg: '', v: {}, sec: '' };
P.uci = async a => {
  if (!a) {
    const l = (await out('ls /etc/config 2>/dev/null')).split('\n').map(x => x.trim()).filter(sid);
    V(H.hd(_('Редактор UCI', 'UCI editor'), 'set') + H.card('', `<div class=sub style="margin:0">${_('Здесь доступны все настройки роутера. Меняйте осторожно.', 'Every router setting lives here. Edit with care.')}</div>`) + H.card('', l.map(x => H.row(esc(x), '', '›', `go('uci','${x}')`)).join('')));
    return;
  }
  if (!sid(a)) throw new Error('bad config');
  UE.cfg = a; UE.v = await U.get(a);
  V(H.hd(esc(a), 'uci') + Object.keys(UE.v).filter(sid).map(k => { const s = UE.v[k], o = Object.keys(s).filter(x => x[0] !== '.'); return H.card(`${esc(s['.type'])}${s['.anonymous'] ? '' : ' · ' + esc(k)}`, o.slice(0, 6).map(x => `<div class=kv><span>${esc(x)}</span><b>${esc([].concat(s[x]).join(', ')).slice(0, 60)}</b></div>`).join('') + (o.length > 6 ? `<div class=sub style="margin:4px 0 0">+${o.length - 6}</div>` : '') + `<button class=s style="margin:8px 0 0" onclick="ueEdit('${k}')">✏️ ${_('Изменить', 'Edit')}</button>`); }).join(''));
};
function ueEdit(k) {
  const s = UE.v[k], o = Object.keys(s).filter(x => x[0] !== '.');
  UE.sec = k; UE.opts = o;
  form(`${s['.type']} ${s['.anonymous'] ? '' : k}`, o.map(x => ({ l: x, t: 'area', v: [].concat(s[x]).join('\n') })),
    async v => {
      for (let i = 0; i < o.length; i++) {
        const orig = [].concat(s[o[i]]).join('\n'); if (v[i] === orig) continue;
        if (v[i].trim() === '') await U.del(UE.cfg, k, [o[i]]);
        else await U.set(UE.cfg, k, { [o[i]]: Array.isArray(s[o[i]]) ? v[i].split('\n').map(x => x.trim()).filter(Boolean) : v[i] });
      }
      await applyCfg(UE.cfg); toast(_('Сохранено и применено', 'Saved and applied')); go('uci', UE.cfg);
    },
    `<div class=g2 style="margin-top:8px"><button onclick="ueAdd()">➕ ${_('Параметр', 'Option')}</button><button class=d onclick="ueDel()">🗑 ${_('Секцию', 'Section')}</button></div>`,
    _('Пустое поле = удалить параметр. Списки: по одному значению в строке.', 'Empty field = delete option. Lists: one value per line.'));
}
async function ueAdd() {
  const k = UE.sec;
  form(_('Новый параметр', 'New option'), [{ l: _('Имя', 'Name'), v: '' }, { l: _('Значение', 'Value'), v: '' }], async v => {
    if (!/^[A-Za-z_][\w]*$/.test(v[0])) throw new Error(_('Неверное имя', 'Invalid name'));
    await U.set(UE.cfg, k, { [v[0]]: v[1] }); await applyCfg(UE.cfg); go('uci', UE.cfg);
  });
}
async function ueDel() {
  const k = UE.sec;
  if (await ask(_('Удалить секцию?', 'Delete section?'), k, _('Удалить', 'Delete'), true)) { try { await U.del(UE.cfg, k); await applyCfg(UE.cfg); } catch (e) { toast(e.message); } go('uci', UE.cfg); }
}
// ---------------- Log ----------------
const LG = { q: '' };
P.logs = async () => {
  V(H.hd(_('Журнал', 'Log'), 'set') + `<input type=text id=lq placeholder="🔎 ${_('Фильтр', 'Filter')}" value="${esc(LG.q)}" oninput="LG.q=this.value;logDraw()"><div class=card style="padding:10px"><pre id=lg class=jl style="max-height:62vh"></pre></div>`);
  await logLoad(); timer = setInterval(() => { logLoad().catch(() => { }); }, 4000);
};
async function logLoad() { LG.t = await out('logread 2>/dev/null | tail -n 300'); logDraw(); }
function logDraw() { const e = $('#lg'); if (!e) return; const q = LG.q.toLowerCase(), l = String(LG.t || '').split('\n').filter(x => !q || x.toLowerCase().includes(q)); e.textContent = l.join('\n'); e.scrollTop = e.scrollHeight; }
// ---------------- SSH terminal ----------------
const TS = { on: false, busy: false, buf: '', cr: false, hist: [], hi: 0, host: '', raf: 0 };
window.sshEv = (t, d) => {
  if (SSHK) { SSHK(t, d); return; }
  if (t === 'ok') { TS.on = true; TS.busy = false; TS.buf = ''; TS.cr = false; if (page === 'ssh') term(); }
  else if (t === 'out') { shFeed(d); if (page === 'ssh' && TS.on && !TS.raf) TS.raf = requestAnimationFrame(() => { TS.raf = 0; const e = $('#term'); if (e) { e.textContent = TS.buf; e.scrollTop = e.scrollHeight; } }); }
  else if (t === 'err') { TS.busy = false; toast(d); }
  else if (t === 'closed') { const was = TS.on; TS.on = false; TS.busy = false; if (was) toast(_('Соединение закрыто', 'Connection closed')); if (page === 'ssh') form_ssh(); }
};
function shFeed(d) {
  d = d.replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '').replace(/\x1b\][^\x07\x1b]*(\x07|\x1b\\)/g, '').replace(/\x1b[()][0-9A-Za-z]/g, '').replace(/\x1b./g, '');
  let b = TS.buf;
  for (const c of d) {
    if (c === '\r') { TS.cr = true; continue; }
    if (TS.cr) { TS.cr = false; if (c === '\n') { b += '\n'; continue; } b = b.slice(0, b.lastIndexOf('\n') + 1); }
    if (c === '\b' || c === '\x7f') { if (b && b[b.length - 1] !== '\n') b = b.slice(0, -1); continue; }
    if (c === '\x07') continue;
    b += c;
  }
  TS.buf = b.length > 100000 ? b.slice(-80000) : b;
}
const shl = () => { try { return JSON.parse(Native.secGet('ss') || '[]'); } catch (e) { return []; } };
P.ssh = async () => { if (TS.on) term(); else form_ssh(); };
function form_ssh() {
  const p = shl(), r = R();
  V(H.hd('SSH', 'set') + `<div class=sub style="margin-top:-8px">${_('Терминал, как в PuTTY', 'A PuTTY-style terminal')}</div>` +
    (r ? H.card('', `<button class=p onclick="shR()">${_('Подключиться к', 'Connect to')} «${esc(r.n)}»</button>`) : '') +
    H.card(_('Новое подключение', 'New connection'), `<input type=text id=sh_h placeholder="${_('Адрес (например, 192.168.1.1)', 'Address (e.g. 192.168.1.1)')}" autocapitalize=off><input type=text id=sh_p placeholder="${_('Порт', 'Port')}" value=22><input type=text id=sh_u placeholder="${_('Логин', 'Username')}" value=root autocapitalize=off><input type=password id=sh_w placeholder="${_('Пароль', 'Password')}"><button class=p onclick="shGo()">${_('Подключиться', 'Connect')}</button><button style="margin-top:8px" onclick="shSave()">💾 ${_('Сохранить профиль', 'Save profile')}</button>`) +
    (p.length ? H.card(_('Профили', 'Profiles'), p.map((x, i) => H.row(esc(x.n), `${esc(x.u)}@${esc(x.h)}:${esc(x.p)}`, `<button class="s d" onclick="shDel(${i})">🗑</button>`, `shUse(${i})`)).join('')) : ''));
}
function term() {
  V(`<div class=hd><h1>⌨️ SSH</h1></div><div class=sub style="margin-top:-8px">${esc(TS.host)}</div><div class=card style="padding:10px"><pre id=term></pre></div><div class=card style="padding:10px"><div class=keys><button onclick="ctl(3)">Ctrl+C</button><button onclick="ctl(4)">Ctrl+D</button><button onclick="hs(-1)">↑</button><button onclick="hs(1)">↓</button><button onclick="TS.buf='';$('#term').textContent=''">${_('Очистить', 'Clear')}</button><button class=d onclick="Ssh.close()">${_('Отключить', 'Disconnect')}</button></div><input id=ti type=text autocapitalize=off autocomplete=off autocorrect=off spellcheck=false placeholder="${_('Команда…', 'Command…')}" style="margin:0" onkeydown="if(event.key==='Enter')shSend()" onfocus="$('#nav').style.display='none'" onblur="$('#nav').style.display='flex'"></div>`);
  const e = $('#term'); e.textContent = TS.buf; e.scrollTop = e.scrollHeight;
}
function ctl(n) { Ssh.send(String.fromCharCode(n)); }
function shSend() { const i = $('#ti'), v = i.value; Ssh.send(v + '\n'); if (v && TS.hist[TS.hist.length - 1] !== v) TS.hist.push(v); TS.hi = TS.hist.length; i.value = ''; }
function hs(d) { TS.hi = Math.max(0, Math.min(TS.hist.length, TS.hi + d)); $('#ti').value = TS.hist[TS.hi] || ''; }
function shConn(h, p, u, pw) { if (TS.busy) return; if (!/^[\w.:-]+$/.test(h)) return toast(_('Некорректный адрес', 'Invalid address')); TS.busy = true; TS.host = u + '@' + h; toast(_('Подключение…', 'Connecting…')); Ssh.connect(h, p, u, pw, Math.max(40, Math.floor(innerWidth / 7.4)), 24); }
function shGo() { shConn($('#sh_h').value.trim(), +$('#sh_p').value || 22, $('#sh_u').value.trim() || 'root', $('#sh_w').value); }
function shR() { const r = R(); shConn(r.a.replace(/^https?:\/\//, '').split('/')[0].replace(/:\d+$/, ''), 22, r.u || 'root', r.p); }
function shUse(i) { const x = shl()[i]; shConn(x.h, x.p, x.u, x.pw); }
function shDel(i) { const p = shl(); p.splice(i, 1); Native.secSet('ss', JSON.stringify(p)); form_ssh(); }
function shSave() { const h = $('#sh_h').value.trim(); if (!h) return toast(_('Введите адрес', 'Enter the address')); const p = shl(); p.push({ n: h, h, p: +$('#sh_p').value || 22, u: $('#sh_u').value.trim() || 'root', pw: $('#sh_w').value }); Native.secSet('ss', JSON.stringify(p)); toast(_('Сохранено', 'Saved')); form_ssh(); }
// ---------------- boot ----------------
function boot() {
  try { rs = JSON.parse(Native.secGet('rs') || '[]'); } catch (e) { rs = []; }
  if (cur >= rs.length) cur = 0;
  ap(); go('home');
}
