'use strict';
const sid = k => /^[\w.-]+$/.test(String(k));
// ---------------- Wi-Fi ----------------
let WF = {};
const ENC = () => [['none', _('Без пароля', 'Open')], ['psk2', 'WPA2'], ['psk-mixed', 'WPA/WPA2'], ['sae', 'WPA3'], ['sae-mixed', 'WPA2/WPA3']];
P.wifi = async () => {
  WF = await U.get('wireless');
  const keys = Object.keys(WF).filter(sid), rad = keys.filter(k => WF[k]['.type'] === 'wifi-device'), ifs = keys.filter(k => WF[k]['.type'] === 'wifi-iface');
  V(H.hd('Wi-Fi', 'set') + rad.map(k => { const r = WF[k]; return H.card(`${esc(k)} · ${esc(r.band || r.hwmode || '')}`, H.row(_('Радиомодуль', 'Radio'), `${_('Канал', 'Channel')}: ${esc(r.channel || 'auto')} · ${esc(r.htmode || '')} · ${esc(r.country || '')}`, H.sw(r.disabled !== '1', `wfRadioTog('${k}',this.checked)`)) + `<button class=s style="margin:8px 0 0" onclick="wfRadio('${k}')">✏️ ${_('Параметры радио', 'Radio options')}</button>` +
    ifs.filter(i => WF[i].device === k).map(i => { const n = WF[i]; return H.row(`📡 ${esc(n.ssid || '—')}`, `${esc(n.mode || 'ap')} · ${esc(n.encryption || 'none')}`, H.sw(n.disabled !== '1', `wfIfTog('${i}',this.checked)`) + `<button class="s" onclick="wfIf('${i}')">✏️</button>`); }).join('')); }).join('') || H.card('', `<div class=sub>${_('Wi-Fi не найден', 'No Wi-Fi found')}</div>`));
};
async function wfApply(msg) {
  if (!await ask(msg, _('Wi-Fi перезапустится. Если связь пропадёт, роутер сам вернёт прежние настройки через 75 секунд.', 'Wi-Fi will restart. If the connection is lost, the router restores the old settings by itself after 75 seconds.'), _('Применить', 'Apply'))) { await U.revert('wireless').catch(() => { }); return false; }
  await applySafe('wireless'); return true;
}
async function wfRadioTog(k, on) { try { await U.set('wireless', k, { disabled: on ? '0' : '1' }); await wfApply(on ? _('Включить радио?', 'Enable radio?') : _('Выключить радио?', 'Disable radio?')); } catch (e) { toast(e.message); } if (SHG && !$('#sheet').innerHTML) go('wifi'); }
async function wfIfTog(k, on) { try { await U.set('wireless', k, { disabled: on ? '0' : '1' }); await applySafe('wireless'); } catch (e) { toast(e.message); } }
function wfIf(k) {
  const n = WF[k];
  form(_('Сеть Wi-Fi', 'Wi-Fi network'), [{ k: 'ssid', l: 'SSID', v: n.ssid || '' }, { k: 'enc', l: _('Защита', 'Security'), t: 'select', v: n.encryption || 'none', o: ENC() }, { k: 'key', l: _('Пароль (8+ символов)', 'Password (8+ chars)'), t: 'text', v: n.key || '' }, { k: 'hid', l: _('Скрытая сеть', 'Hidden network'), t: 'check', v: n.hidden === '1' }],
    async v => {
      if (!v[0]) throw new Error('SSID?');
      if (v[1] !== 'none' && v[2].length < 8) throw new Error(_('Пароль минимум 8 символов', 'Password needs 8+ characters'));
      const o = { ssid: v[0], encryption: v[1], hidden: v[3] ? '1' : '0' }; if (v[1] !== 'none') o.key = v[2];
      await U.set('wireless', k, o); await wfApply(_('Сохранить сеть?', 'Save network?')); go('wifi');
    });
}
function wfRadio(k) {
  const r = WF[k];
  form(_('Параметры радио', 'Radio options'), [{ l: _('Канал (auto или число)', 'Channel (auto or number)'), v: r.channel || 'auto' }, { l: _('Ширина канала', 'Channel width'), t: 'select', v: r.htmode || '', o: [['', _('по умолчанию', 'default')], ['HT20', 'HT20'], ['HT40', 'HT40'], ['VHT20', 'VHT20'], ['VHT40', 'VHT40'], ['VHT80', 'VHT80'], ['HE20', 'HE20'], ['HE40', 'HE40'], ['HE80', 'HE80']] }, { l: _('Страна (2 буквы)', 'Country (2 letters)'), v: r.country || '' }, { l: _('Мощность, dBm (пусто = макс.)', 'TX power, dBm (empty = max)'), v: r.txpower || '' }],
    async v => {
      if (v[0] !== 'auto' && !/^\d{1,3}$/.test(v[0])) throw new Error(_('Канал: auto или число', 'Channel: auto or number'));
      if (v[2] && !/^[A-Za-z]{2}$/.test(v[2])) throw new Error(_('Страна: 2 буквы', 'Country: 2 letters'));
      await U.set('wireless', k, { channel: v[0] }); const dl = [];
      for (const [o, val] of [['htmode', v[1]], ['country', v[2].toUpperCase()], ['txpower', v[3]]]) { if (val) await U.set('wireless', k, { [o]: val }); else dl.push(o); }
      if (dl.length) await U.del('wireless', k, dl).catch(() => { });
      await wfApply(_('Сохранить параметры?', 'Save options?')); go('wifi');
    });
}
// ---------------- System ----------------
const TZ = [['Europe/Kaliningrad', 'EET-2', 'Калининград'], ['Europe/Moscow', 'MSK-3', 'Москва'], ['Europe/Samara', '<+04>-4', 'Самара'], ['Asia/Yekaterinburg', '<+05>-5', 'Екатеринбург'], ['Asia/Omsk', '<+06>-6', 'Омск'], ['Asia/Novosibirsk', '<+07>-7', 'Новосибирск'], ['Asia/Krasnoyarsk', '<+07>-7', 'Красноярск'], ['Asia/Irkutsk', '<+08>-8', 'Иркутск'], ['Asia/Vladivostok', '<+10>-10', 'Владивосток'], ['Europe/Minsk', '<+03>-3', 'Минск'], ['Europe/Kiev', 'EET-2EEST,M3.5.0/3,M10.5.0/4', 'Киев'], ['Europe/Berlin', 'CET-1CEST,M3.5.0,M10.5.0/3', 'Berlin'], ['Europe/London', 'GMT0BST,M3.5.0/1,M10.5.0', 'London'], ['America/New_York', 'EST5EDT,M3.2.0,M11.1.0', 'New York'], ['UTC', 'UTC0', 'UTC']];
P.sys = async () => {
  const sy = await U.get('system'), k = Object.keys(sy).find(x => sy[x]['.type'] === 'system'), s = sy[k] || {};
  SYS = { k, s }; await loadCfgs(['system']);
  V(H.hd(_('Система', 'System'), 'set') +
    H.card('', H.row(_('Имя роутера', 'Hostname'), esc(s.hostname || ''), '✏️', 'hostEdit()') + H.row(_('Часовой пояс', 'Time zone'), esc(s.zonename || s.timezone || ''), '✏️', 'tzEdit()') + H.row(_('Пароль root', 'Root password'), '', '✏️', 'pwEdit()')) +
    H.card(_('Питание', 'Power'), `<div class=grid><button class=d onclick="rebootAsk()">🔄 ${_('Перезагрузка', 'Reboot')}</button><button class=d onclick="offAsk()">⏻ ${_('Выключить', 'Power off')}</button></div><button style="margin-top:8px" onclick="ntpNow()">🕒 ${_('Синхронизировать время', 'Sync time now')}</button>`) + cfgCard('ntp'));
};
let SYS = {};
function hostEdit() { form(_('Имя роутера', 'Hostname'), [{ l: _('Имя', 'Name'), v: SYS.s.hostname || '' }], async v => { if (!/^[A-Za-z0-9-]{1,63}$/.test(v[0])) throw new Error(_('Только латиница, цифры, дефис', 'Letters, digits, hyphen only')); await U.set('system', SYS.k, { hostname: v[0] }); await applyCfg('system'); go('sys'); }); }
function tzEdit() { form(_('Часовой пояс', 'Time zone'), [{ l: _('Пояс', 'Zone'), t: 'select', v: SYS.s.zonename || '', o: TZ.map(x => [x[0], x[2] + ' · ' + x[0]]) }], async v => { const z = TZ.find(x => x[0] === v[0]); if (!z) throw new Error('?'); await U.set('system', SYS.k, { zonename: z[0], timezone: z[1] }); await applyCfg('system'); go('sys'); }); }
function pwEdit() {
  form(_('Пароль root', 'Root password'), [{ l: _('Новый пароль', 'New password'), t: 'password', v: '' }, { l: _('Повторите', 'Repeat'), t: 'password', v: '' }],
    async v => {
      if (v[0].length < 6 || v[0] !== v[1]) throw new Error(_('Пароли не совпадают или короче 6 символов', 'Passwords differ or are shorter than 6 characters'));
      try { await call(R(), 'luci', 'setPassword', { username: 'root', password: v[0] }); } catch (e) { await sh(`printf '%s\\n%s\\n' ${L.shq(v[0])} ${L.shq(v[0])} | passwd root`); }
      R().p = v[0]; saveRs(); toast(_('Пароль изменён', 'Password changed'));
    });
}
async function offAsk() { if (await ask(_('Выключить роутер?', 'Power off the router?'), _('Включить его снова можно только кнопкой питания.', 'You can turn it on again only with the power button.'), _('Выключить', 'Power off'), true)) { await sh('poweroff &\ntrue'); } }
async function ntpNow() { await sh('/etc/init.d/sysntpd restart; true'); toast(_('Готово', 'Done')); }
// ---------------- Services ----------------
const SV = { list: [], f: 'all', q: '' };
const SVCMD = 'for f in /etc/init.d/*; do n=${f##*/}; case $n in README|rcS|rc.*) continue;; esac; e=0; r=0; $f enabled >/dev/null 2>&1 && e=1; $f running >/dev/null 2>&1 && r=1; echo "$n|$e|$r"; done; true';
P.svc = async () => { SV.list = L.parseServices(await out(SVCMD)); renderSvc(); };
const svcName = n => { const x = L.SVC[n]; return x ? { t: _(x[0], x[1]), i: x[2] } : { t: n, i: '🔧' }; };
function svcList() {
  const q = SV.q.toLowerCase();
  return SV.list.filter(s => (SV.f === 'all' || (SV.f === 'run' && s.run) || (SV.f === 'stop' && !s.run) || (SV.f === 'auto' && s.en)) && (!q || (s.name + svcName(s.name).t).toLowerCase().includes(q)))
    .sort((a, b) => (b.run - a.run) || a.name.localeCompare(b.name))
    .map(s => { const d = svcName(s.name); return `<div class="svc ${s.run ? 'on' : ''}"><div class=ic>${d.i}</div><div class=dm><b>${esc(d.t)}</b><small>${esc(s.name)} · ${s.run ? _('работает', 'running') : _('остановлен', 'stopped')} · ${s.en ? _('автозапуск', 'autostart') : _('вручную', 'manual')}</small></div><div class=sa><button class=s onclick="svcAct('${s.name}','${s.run ? 'stop' : 'start'}')">${s.run ? '⏹' : '▶'}</button><button class=s onclick="svcAct('${s.name}','restart')">🔄</button><button class=s onclick="svcAct('${s.name}','${s.en ? 'disable' : 'enable'}')">${s.en ? '🔕' : '🔔'}</button></div></div>`; }).join('') || `<div class=sub style="text-align:center">${_('Ничего не найдено', 'Nothing found')}</div>`;
}
function renderSvc() {
  const c = { all: SV.list.length, run: SV.list.filter(s => s.run).length, stop: SV.list.filter(s => !s.run).length, auto: SV.list.filter(s => s.en).length };
  V(H.hd(_('Сервисы', 'Services'), 'set') + H.seg([['all', `${_('Все', 'All')} · ${c.all}`], ['run', `${_('Работают', 'Running')} · ${c.run}`], ['stop', `${_('Стоят', 'Stopped')} · ${c.stop}`], ['auto', `${_('Автозапуск', 'Autostart')} · ${c.auto}`]], SV.f, 'svF') + `<input type=text id=sq placeholder="🔎 ${_('Поиск', 'Search')}" value="${esc(SV.q)}" oninput="SV.q=this.value;$('#sl').innerHTML=svcList()"><div id=sl>${svcList()}</div>`);
}
function svF(k) { SV.f = k; renderSvc(); }
async function svcAct(n, a) {
  if (!sid(n) || !['start', 'stop', 'restart', 'enable', 'disable'].includes(a)) return;
  if ((a === 'stop' || a === 'disable') && ['network', 'rpcd', 'uhttpd', 'dropbear'].includes(n) && !await ask(_('Это важный сервис', 'This is an important service'), _('Остановка может оборвать связь с роутером.', 'Stopping it may cut your connection to the router.'), _('Продолжить', 'Continue'), true)) return;
  await sh(`/etc/init.d/${n} ${a} >/dev/null 2>&1 &\ntrue`); await sleep(1500); SV.list = L.parseServices(await out(SVCMD)); renderSvc();
}
// ---------------- Plugin library ----------------
const pk = (names, ru, en, dru, den) => [names.split(' '), [ru, en], [dru, den]];
const PKCAT = () => [
  [_('Скорость и сеть', 'Speed & network'), [
    pk('sqm-scripts luci-app-sqm', 'Умные очереди (SQM)', 'Smart queues (SQM)', 'Убирает лаги и скачки пинга при загруженном канале.', 'Removes lag and ping spikes on a busy link.'),
    pk('nlbwmon luci-app-nlbwmon', 'Учёт трафика', 'Traffic accounting', 'Считает трафик каждого устройства.', 'Counts traffic per device.'),
    pk('etherwake luci-app-wol', 'Включение по сети (WoL)', 'Wake-on-LAN', 'Нужен для кнопки включения ПК.', 'Needed for the PC power-on button.'),
    pk('luci-app-upnp miniupnpd-nftables', 'UPnP', 'UPnP', 'Автоматический проброс портов для игр.', 'Automatic port mapping for games.'),
    pk('luci-app-ddns ddns-scripts', 'Динамический DNS', 'Dynamic DNS', 'Постоянное имя для домашнего IP.', 'A stable name for your home IP.'),
    pk('luci-app-mwan3 mwan3', 'Несколько провайдеров (mwan3)', 'Multi-WAN (mwan3)', 'Балансировка и резерв между каналами.', 'Load balancing and failover between links.'),
    pk('luci-app-smartdns smartdns', 'SmartDNS', 'SmartDNS', 'Быстрый DNS: выбирает самый отзывчивый сервер.', 'Fast DNS: picks the most responsive server.'),
    pk('luci-app-socat socat', 'socat', 'socat', 'Перенаправление портов и туннели.', 'Port relays and tunnels.')]],
  [_('VPN и туннели', 'VPN & tunnels'), [
    pk('wireguard-tools luci-proto-wireguard', 'WireGuard', 'WireGuard', 'Современный быстрый VPN.', 'A modern, fast VPN.'),
    pk('openvpn-openssl luci-app-openvpn', 'OpenVPN', 'OpenVPN', 'Классический VPN.', 'The classic VPN.'),
    pk('zerotier luci-app-zerotier', 'ZeroTier', 'ZeroTier', 'Виртуальная сеть между устройствами.', 'A virtual network between devices.'),
    pk('tailscale', 'Tailscale', 'Tailscale', 'Доступ к дому из любой точки.', 'Reach your home from anywhere.'),
    pk('sing-box', 'sing-box', 'sing-box', 'Ядро для прокси-маршрутизации (нужно Podkop).', 'Proxy core (needed by Podkop).'),
    pk('kmod-nft-tproxy jq coreutils-base64', 'Зависимости Podkop', 'Podkop dependencies', 'Если установка Podkop просит эти пакеты.', 'If Podkop installation asks for these.')]],
  [_('DNS и безопасность', 'DNS & security'), [
    pk('adblock-fast luci-app-adblock-fast', 'Блокировка рекламы', 'Ad blocking', 'Фильтрует рекламу для всей сети.', 'Filters ads for the whole network.'),
    pk('banip luci-app-banip', 'Блокировка IP (banip)', 'IP blocking (banip)', 'Списки вредных адресов.', 'Lists of malicious addresses.'),
    pk('https-dns-proxy luci-app-https-dns-proxy', 'DNS через HTTPS', 'DNS over HTTPS', 'Шифрует DNS-запросы.', 'Encrypts DNS queries.'),
    pk('acme luci-app-acme', 'Сертификаты Let\'s Encrypt', "Let's Encrypt certificates", 'Бесплатные HTTPS-сертификаты.', 'Free HTTPS certificates.')]],
  [_('Диски и файлы', 'Disks & files'), [
    pk('block-mount kmod-usb-storage kmod-fs-ext4', 'USB-накопители', 'USB storage', 'Подключение флешек и дисков.', 'Mount flash drives and disks.'),
    pk('luci-app-samba4 samba4-server', 'Сетевые папки (Samba)', 'File sharing (Samba)', 'Доступ к диску с компьютеров.', 'Access the disk from computers.'),
    pk('luci-app-ksmbd ksmbd-server', 'Сетевые папки (ksmbd)', 'File sharing (ksmbd)', 'Лёгкая альтернатива Samba.', 'A lightweight Samba alternative.'),
    pk('luci-app-hd-idle hd-idle', 'Спящий режим дисков', 'Disk spin-down', 'Усыпляет неиспользуемые диски.', 'Spins down idle disks.'),
    pk('luci-app-minidlna minidlna', 'Медиасервер (DLNA)', 'Media server (DLNA)', 'Видео и музыка на ТВ.', 'Video and music on your TV.'),
    pk('luci-app-transmission transmission-daemon', 'Торрент-клиент', 'Torrent client', 'Загрузки прямо на роутере.', 'Downloads right on the router.')]],
  [_('Мониторинг', 'Monitoring'), [
    pk('luci-app-statistics collectd', 'Графики и статистика', 'Graphs & statistics', 'Нагрузка, температура, трафик во времени.', 'Load, temperature, traffic over time.'),
    pk('luci-app-vnstat2 vnstat2', 'Трафик по дням', 'Daily traffic (vnStat)', 'Статистика трафика по дням и месяцам.', 'Traffic stats per day and month.'),
    pk('luci-app-watchcat watchcat', 'Watchcat', 'Watchcat', 'Перезагрузка при пропаже интернета.', 'Reboots when the internet is lost.')]],
  [_('Утилиты', 'Utilities'), [
    pk('htop', 'htop', 'htop', 'Монитор процессов.', 'Process monitor.'), pk('nano', 'nano', 'nano', 'Удобный текстовый редактор.', 'A friendly text editor.'), pk('bash', 'bash', 'bash', 'Оболочка с автодополнением.', 'A shell with completion.'),
    pk('tcpdump', 'tcpdump', 'tcpdump', 'Захват трафика.', 'Packet capture.'), pk('mtr', 'mtr', 'mtr', 'Трассировка с потерями.', 'Traceroute with loss stats.'), pk('iperf3', 'iperf3', 'iperf3', 'Замер скорости сети.', 'Network speed test.'),
    pk('bind-dig', 'dig', 'dig', 'Проверка DNS.', 'DNS lookups.'), pk('curl ca-bundle', 'curl + сертификаты', 'curl + certificates', 'Загрузка подписок и обновлений.', 'Fetching subscriptions and updates.'),
    pk('luci-app-ttyd ttyd', 'Терминал в браузере', 'Web terminal', 'Консоль в веб-интерфейсе.', 'A console in the web UI.'), pk('luci-app-commands', 'Быстрые команды', 'Custom commands', 'Кнопки для своих команд.', 'Buttons for your commands.'),
    pk('luci-app-attendedsysupgrade', 'Обновление прошивки', 'Firmware upgrade', 'Обновление прошивки с сохранением пакетов.', 'Firmware upgrade keeping your packages.')]],
  [_('Язык', 'Language'), [
    pk('luci-i18n-base-ru luci-i18n-firewall-ru', 'LuCI на русском', 'LuCI in Russian', 'Русский веб-интерфейс.', 'Russian web interface.')]]
];
const PKS = { inst: {}, up: [], res: [], ru: [], tab: 'cat', q: '' };
P.pkgs = async () => { PKS.inst = await installed(); renderPkgs(); };
function pkgTab(k) { PKS.tab = k; renderPkgs(); }
function renderPkgs() {
  V(H.hd(_('Программы', 'Software'), 'set') + H.seg([['cat', _('Плагины', 'Plugins')], ['inst', `${_('Установленные', 'Installed')} · ${Object.keys(PKS.inst).length}`], ['upd', _('Обновления', 'Updates')]], PKS.tab, 'pkgTab') +
    (PKS.tab === 'cat' ? pkgCatHtml() : PKS.tab === 'inst' ? pkgInstHtml() : pkgUpdHtml()));
}
function pkgCatHtml() {
  return H.card(_('Поиск по всем пакетам', 'Search all packages'), `<div style="display:flex;gap:8px"><input type=text id=ps placeholder="${_('Например: luci-app-', 'E.g. luci-app-')}" style="margin:0" autocapitalize=off onkeydown="if(event.key==='Enter')pkgSearch()"><button class="s p" style="margin:0" onclick="pkgSearch()">🔎</button></div><div id=psr>${PKS.res.length ? pkgResHtml() : ''}</div>`) +
    PKCAT().map(c => H.card(c[0], c[1].map(p => { const ok = p[0].every(n => n in PKS.inst); return H.row(`${_(p[1][0], p[1][1])} ${ok ? '<span class="chip ok">✓</span>' : ''}`, _(p[2][0], p[2][1]) + '<br>' + esc(p[0].join(' ')), `<button class="s ${ok ? 'd' : 'p'}" onclick="pkgToggle('${p[0].join(' ')}',${ok ? 0 : 1})">${ok ? _('Удалить', 'Remove') : _('Установить', 'Install')}</button>`); }).join(''))).join('');
}
function pkgInstRows() {
  const q = PKS.q.toLowerCase();
  const l = Object.keys(PKS.inst).filter(n => !q || n.toLowerCase().includes(q)).sort();
  return l.slice(0, 150).map(n => H.row(esc(n), esc(PKS.inst[n]), L.isProt(n) ? `<span class="chip">🔒 ${_('системный', 'system')}</span>` : `<button class="s d" onclick="pkgToggle('${n}',0)">${_('Удалить', 'Remove')}</button>`)).join('') + (l.length > 150 ? `<div class=sub>… ${l.length - 150}</div>` : '') || `<div class=sub>${_('Ничего не найдено', 'Nothing found')}</div>`;
}
function pkgInstHtml() {
  return `<input type=text id=pq placeholder="🔎 ${_('Фильтр по имени', 'Filter by name')}" value="${esc(PKS.q)}" oninput="PKS.q=this.value;$('#pil').innerHTML=pkgInstRows()" autocapitalize=off>` + H.card(_('Установленные пакеты', 'Installed packages'), `<div class=sub style="margin:0 0 8px">${_('Системные пакеты защищены от удаления, чтобы роутер не сломался.', 'System packages are protected from removal so the router cannot be broken.')}</div><div id=pil>${pkgInstRows()}</div>`);
}
function pkgUpdHtml() {
  return H.card(_('Обновления и переводы', 'Updates & translations'), `<div class=grid><button class=p onclick="pkgCheck()">🔍 ${_('Проверить', 'Check')}</button><button onclick="pkgRu()">🇷🇺 ${_('Русский для всех', 'Russian for all')}</button></div>` + (PKS.up.length ? pkgUpHtml() : `<div class=sub style="margin:10px 0 0">${_('Нажмите «Проверить»: роутер обновит списки пакетов и покажет, что можно обновить.', 'Tap "Check": the router refreshes package lists and shows what can be updated.')}</div>`)) +
    H.card(_('Репозиторий пакетов', 'Package repository'), `<div class=sub style="margin:0 0 8px">${_('Если обновление списков зависает или падает, проверьте зеркала и выберите самое быстрое.', 'If refreshing lists hangs or fails, test the mirrors and pick the fastest.')}</div><div id=mir>${mirHtml()}</div><div class=grid style="margin-top:10px"><button class=p onclick="mirTest()">⏱ ${_('Проверить зеркала', 'Test mirrors')}</button><button onclick="mirRevert()">↩ ${_('Исходное', 'Original')}</button></div><button style="margin-top:8px" onclick="pmUnlock()">🔓 ${_('Разблокировать пакетный менеджер', 'Unlock the package manager')}</button>`);
}
const MIR = { res: {}, cur: -1 };
function mirHtml() {
  return L.MIRRORS.map((m, i) => { const r = MIR.res[i]; return H.row(`${MIR.cur === i ? '✔ ' : ''}${esc(m[0])}`, _(m[1], m[2]), (r ? `<span class="chip ${r.ok ? 'ok' : 'bad'}">${r.ok ? r.s + ' ' + _('с', 's') : _('недоступно', 'unreachable')}</span>` : '') + `<button class="s" onclick="mirUse(${i})">${_('Выбрать', 'Use')}</button>`); }).join('');
}
async function mirTest() {
  toast(_('Проверяю зеркала…', 'Testing mirrors…'));
  try { MIR.res = L.parseMirror(await out(L.mirrorTestCmd())); MIR.cur = L.mirrorCur(await out(L.mirrorCurCmd())); } catch (e) { toast(e.message); }
  const e = $('#mir'); if (e) e.innerHTML = mirHtml();
}
async function mirUse(i) {
  const m = L.MIRRORS[i]; if (!m) return;
  if (!await ask(_('Сменить зеркало?', 'Switch mirror?'), m[0] + '\n' + _('Исходные файлы сохранятся, вернуть можно кнопкой «Исходное».', 'The original files are kept; you can restore them with "Original".'), _('Выбрать', 'Use'))) return;
  try { await sh(L.mirrorSwitchCmd(i)); MIR.cur = i; toast('✅ ' + m[0]); } catch (e) { toast(e.message); }
  if (page === 'pkgs') renderPkgs();
}
async function mirRevert() { try { await sh(L.mirrorRevertCmd()); MIR.cur = 0; toast('↩ ' + _('Возвращено исходное', 'Original restored')); } catch (e) { toast(e.message); } if (page === 'pkgs') renderPkgs(); }
const pkgResHtml = () => `<div style="margin-top:8px">` + PKS.res.map(r => H.row(esc(r.name), esc(r.ver + (r.desc ? ' · ' + r.desc : '')), r.name in PKS.inst ? `<span class="chip ok">✓</span>` : `<button class="s p" onclick="pkgToggle('${r.name}',1)">${_('Установить', 'Install')}</button>`)).join('') + `</div>`;
async function pkgSearch() {
  const q = $('#ps').value.trim();
  if (!/^[\w.+-]{2,40}$/.test(q)) return toast(_('Введите минимум 2 символа (латиница, цифры, - . +)', 'Enter at least 2 characters (letters, digits, - . +)'));
  const p = await pm(); PKS.res = L.parseSearch(await out(L.searchCmd(p, q)), p);
  const e = $('#psr'); if (e) e.innerHTML = PKS.res.length ? pkgResHtml() : `<div class=sub style="margin:8px 0 0">${_('Ничего не найдено. На вкладке «Обновления» нажмите «Проверить», чтобы обновить списки пакетов.', 'Nothing found. On the "Updates" tab tap "Check" to refresh package lists.')}</div>`;
}
const pkgUpHtml = () => `<div class=sub style="margin:10px 0 6px">${PKS.up.map(x => `${esc(x.name)}: ${esc(x.from)} → ${esc(x.to)}`).join('<br>')}</div><button class=p onclick="pkgUpAll()">⬆ ${_('Обновить всё', 'Update all')}</button>`;
async function pkgToggle(names, on) {
  let l = names.split(' ').filter(L.okPkg); if (!l.length) return;
  if (!on) {
    const prot = l.filter(L.isProt);
    if (prot.length) { toast(_('Системные пакеты не удаляются: ', 'System packages are never removed: ') + prot.join(', ')); l = l.filter(n => !L.isProt(n)); if (!l.length) return; }
  }
  if (!await ask(on ? _('Установить пакеты?', 'Install packages?') : _('Удалить пакеты?', 'Remove packages?'), l.join(', ') + (on ? '\n' + _('Роутеру нужен доступ в интернет.', 'The router needs internet access.') : ''), on ? _('Установить', 'Install') : _('Удалить', 'Remove'), !on)) return;
  const c = L.pmCmd(await pm());
  await jobSheet(on ? _('Установка', 'Installing') : _('Удаление', 'Removing'), on ? `${c.upd}; ${c.inst(l.join(' '))}` : c.rm(l.join(' ')));
  PKS.inst = await installed(); if (page === 'pkgs') renderPkgs();
}
async function pkgCheck() {
  const c = L.pmCmd(await pm());
  if (await jobSheet(_('Проверка обновлений', 'Checking for updates'), c.upd) !== 0) return;
  PKS.up = L.parseUpgradable(await out(c.up));
  const b = $('#jb');
  if (b) b.innerHTML = `<div class=sub>${PKS.up.length ? '⬆ ' + _('Можно обновить: ', 'Can be updated: ') + PKS.up.length + '<br>' + PKS.up.map(x => `${esc(x.name)}: ${esc(x.from)} → ${esc(x.to)}`).join('<br>') : '✅ ' + _('Всё актуально, обновлений нет.', 'Everything is up to date.')}</div>${PKS.up.length ? `<button class=p onclick="closeSheet();pkgUpAll()">⬆ ${_('Обновить всё', 'Update all')}</button>` : ''}<button style="margin-top:8px" onclick="closeSheet()">OK</button>`;
  PKS.tab = 'upd'; if (page === 'pkgs') renderPkgs();
}
async function pkgUpAll() {
  const names = PKS.up.map(x => x.name).filter(L.okPkg), c = L.pmCmd(await pm());
  if (!names.length) return;
  await jobSheet(_('Обновление', 'Updating'), c.upg(names.join(' '))); PKS.up = []; PKS.inst = await installed(); if (page === 'pkgs') renderPkgs();
}
async function pkgRu() {
  const p = await pm(), c = L.pmCmd(p), inst = await installed(), names = new Set(['base', 'firewall']);
  Object.keys(inst).forEach(n => { if (n.startsWith('luci-app-')) names.add(n.slice(9)); });
  const list = [...names].filter(x => /^[a-z0-9._+-]+$/i.test(x));
  if (await jobSheet(_('Поиск русских переводов', 'Looking for Russian translations'), c.upd) !== 0) return;
  const has = x => p === 'apk' ? `[ -n "$(apk search -e luci-i18n-${x}-ru 2>/dev/null)" ] && echo ${x}` : `[ -n "$(opkg list luci-i18n-${x}-ru 2>/dev/null)" ] && echo ${x}`;
  const avail = (await out(list.map(has).join('\n') + '\ntrue')).split('\n').map(x => x.trim()).filter(x => list.includes(x)).map(x => 'luci-i18n-' + x + '-ru');
  const have = avail.filter(x => x in inst); PKS.ru = avail.filter(x => !(x in inst));
  const b = $('#jb');
  if (b) b.innerHTML = `<div class=sub>${_('Найдено русских пакетов: ', 'Russian packages found: ')}${avail.length}<br>${_('Уже установлены: ', 'Already installed: ')}${have.length}${PKS.ru.length ? '<br>' + _('Можно установить: ', 'Can be installed: ') + esc(PKS.ru.join(', ')) : ''}</div>${PKS.ru.length ? `<button class=p onclick="closeSheet();pkgRuInstall()">🇷🇺 ${_('Установить', 'Install')} (${PKS.ru.length})</button>` : (avail.length ? `<div class=sub>✅ ${_('Всё уже на русском.', 'Everything is already in Russian.')}</div>` : `<div class=sub>${_('Для ваших приложений русских переводов в репозитории нет.', 'No Russian translations in the repository for your apps.')}</div>`)}<button style="margin-top:8px" onclick="closeSheet()">OK</button>`;
}
async function pkgRuInstall() { if (PKS.ru.length) await pkgToggle(PKS.ru.join(' '), 1); }
// ---------------- UCI editor ----------------
let UE = { cfg: '', v: {}, sec: '' };
P.uci = async a => {
  if (!a) {
    const l = (await out('ls /etc/config 2>/dev/null')).split('\n').map(x => x.trim()).filter(sid);
    V(H.hd(_('Редактор UCI', 'UCI editor'), 'set') + H.card('', `<div class=sub style="margin:0">${_('Здесь доступны все настройки роутера. Меняйте осторожно.', 'Every router setting lives here. Edit with care.')}</div>`) + H.card('', l.map(x => H.row(esc(x), '', '›', `go('uci','${x}')`)).join('')));
    return;
  }
  if (!sid(a)) throw new Error('bad config');
  UE.cfg = a; UE.v = await U.get(a);
  V(H.hd(esc(a), 'uci') + Object.keys(UE.v).filter(sid).map(k => { const s = UE.v[k], o = Object.keys(s).filter(x => x[0] !== '.'); return H.card(`${esc(s['.type'])}${s['.anonymous'] ? '' : ' · ' + esc(k)}`, o.slice(0, 6).map(x => `<div class=kv><span>${esc(x)}</span><b>${esc([].concat(s[x]).join(', ')).slice(0, 60)}</b></div>`).join('') + (o.length > 6 ? `<div class=sub style="margin:4px 0 0">+${o.length - 6}</div>` : '') + `<button class=s style="margin:8px 0 0" onclick="ueEdit('${k}')">✏️ ${_('Изменить', 'Edit')}</button>`); }).join(''));
};
function ueEdit(k) {
  const s = UE.v[k], o = Object.keys(s).filter(x => x[0] !== '.');
  UE.sec = k; UE.opts = o;
  form(`${s['.type']} ${s['.anonymous'] ? '' : k}`, o.map(x => ({ l: x, t: 'area', v: [].concat(s[x]).join('\n') })),
    async v => {
      for (let i = 0; i < o.length; i++) {
        const orig = [].concat(s[o[i]]).join('\n'); if (v[i] === orig) continue;
        if (v[i].trim() === '') await U.del(UE.cfg, k, [o[i]]);
        else await U.set(UE.cfg, k, { [o[i]]: Array.isArray(s[o[i]]) ? v[i].split('\n').map(x => x.trim()).filter(Boolean) : v[i] });
      }
      await applyCfg(UE.cfg); toast(_('Сохранено и применено', 'Saved and applied')); go('uci', UE.cfg);
    },
    `<div class=g2 style="margin-top:8px"><button onclick="ueAdd()">➕ ${_('Параметр', 'Option')}</button><button class=d onclick="ueDel()">🗑 ${_('Секцию', 'Section')}</button></div>`,
    _('Пустое поле = удалить параметр. Списки: по одному значению в строке.', 'Empty field = delete option. Lists: one value per line.'));
}
async function ueAdd() {
  const k = UE.sec;
  form(_('Новый параметр', 'New option'), [{ l: _('Имя', 'Name'), v: '' }, { l: _('Значение', 'Value'), v: '' }], async v => {
    if (!/^[A-Za-z_][\w]*$/.test(v[0])) throw new Error(_('Неверное имя', 'Invalid name'));
    await U.set(UE.cfg, k, { [v[0]]: v[1] }); await applyCfg(UE.cfg); go('uci', UE.cfg);
  });
}
async function ueDel() {
  const k = UE.sec;
  if (await ask(_('Удалить секцию?', 'Delete section?'), k, _('Удалить', 'Delete'), true)) { try { await U.del(UE.cfg, k); await applyCfg(UE.cfg); } catch (e) { toast(e.message); } go('uci', UE.cfg); }
}
// ---------------- Log ----------------
const LG = { q: '' };
P.logs = async () => {
  V(H.hd(_('Журнал', 'Log'), 'set') + `<input type=text id=lq placeholder="🔎 ${_('Фильтр', 'Filter')}" value="${esc(LG.q)}" oninput="LG.q=this.value;logDraw()"><div class=card style="padding:10px"><pre id=lg class=jl style="max-height:62vh"></pre></div>`);
  await logLoad(); timer = setInterval(() => { logLoad().catch(() => { }); }, 4000);
};
async function logLoad() { LG.t = await out('logread 2>/dev/null | tail -n 300'); logDraw(); }
function logDraw() { const e = $('#lg'); if (!e) return; const q = LG.q.toLowerCase(), l = String(LG.t || '').split('\n').filter(x => !q || x.toLowerCase().includes(q)); e.textContent = l.join('\n'); e.scrollTop = e.scrollHeight; }
// ---------------- SSH terminal ----------------
const TS = { on: false, busy: false, buf: '', cr: false, hist: [], hi: 0, host: '', raf: 0 };
window.sshEv = (t, d) => {
  if (SSHK) { SSHK(t, d); return; }
  if (t === 'ok') { TS.on = true; TS.busy = false; TS.buf = ''; TS.cr = false; if (page === 'ssh') term(); }
  else if (t === 'out') { shFeed(d); if (page === 'ssh' && TS.on && !TS.raf) TS.raf = requestAnimationFrame(() => { TS.raf = 0; const e = $('#term'); if (e) { e.textContent = TS.buf; e.scrollTop = e.scrollHeight; } }); }
  else if (t === 'err') { TS.busy = false; toast(d); }
  else if (t === 'closed') { const was = TS.on; TS.on = false; TS.busy = false; if (was) toast(_('Соединение закрыто', 'Connection closed')); if (page === 'ssh') form_ssh(); }
};
function shFeed(d) {
  d = d.replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '').replace(/\x1b\][^\x07\x1b]*(\x07|\x1b\\)/g, '').replace(/\x1b[()][0-9A-Za-z]/g, '').replace(/\x1b./g, '');
  let b = TS.buf;
  for (const c of d) {
    if (c === '\r') { TS.cr = true; continue; }
    if (TS.cr) { TS.cr = false; if (c === '\n') { b += '\n'; continue; } b = b.slice(0, b.lastIndexOf('\n') + 1); }
    if (c === '\b' || c === '\x7f') { if (b && b[b.length - 1] !== '\n') b = b.slice(0, -1); continue; }
    if (c === '\x07') continue;
    b += c;
  }
  TS.buf = b.length > 100000 ? b.slice(-80000) : b;
}
const shl = () => { try { return JSON.parse(Native.secGet('ss') || '[]'); } catch (e) { return []; } };
P.ssh = async () => { if (TS.on) term(); else form_ssh(); };
function form_ssh() {
  const p = shl(), r = R();
  V(H.hd('SSH', 'set') + `<div class=sub style="margin-top:-8px">${_('Терминал, как в PuTTY', 'A PuTTY-style terminal')}</div>` +
    (r ? H.card('', `<button class=p onclick="shR()">${_('Подключиться к', 'Connect to')} «${esc(r.n)}»</button>`) : '') +
    H.card(_('Новое подключение', 'New connection'), `<input type=text id=sh_h placeholder="${_('Адрес (например, 192.168.1.1)', 'Address (e.g. 192.168.1.1)')}" autocapitalize=off><input type=text id=sh_p placeholder="${_('Порт', 'Port')}" value=22><input type=text id=sh_u placeholder="${_('Логин', 'Username')}" value=root autocapitalize=off><input type=password id=sh_w placeholder="${_('Пароль', 'Password')}"><button class=p onclick="shGo()">${_('Подключиться', 'Connect')}</button><button style="margin-top:8px" onclick="shSave()">💾 ${_('Сохранить профиль', 'Save profile')}</button>`) +
    (p.length ? H.card(_('Профили', 'Profiles'), p.map((x, i) => H.row(esc(x.n), `${esc(x.u)}@${esc(x.h)}:${esc(x.p)}`, `<button class="s d" onclick="shDel(${i})">🗑</button>`, `shUse(${i})`)).join('')) : ''));
}
function term() {
  V(`<div class=hd><h1>⌨️ SSH</h1></div><div class=sub style="margin-top:-8px">${esc(TS.host)}</div><div class=card style="padding:10px"><pre id=term></pre></div><div class=card style="padding:10px"><div class=keys><button onclick="ctl(3)">Ctrl+C</button><button onclick="ctl(4)">Ctrl+D</button><button onclick="hs(-1)">↑</button><button onclick="hs(1)">↓</button><button onclick="TS.buf='';$('#term').textContent=''">${_('Очистить', 'Clear')}</button><button class=d onclick="Ssh.close()">${_('Отключить', 'Disconnect')}</button></div><input id=ti type=text autocapitalize=off autocomplete=off autocorrect=off spellcheck=false placeholder="${_('Команда…', 'Command…')}" style="margin:0" onkeydown="if(event.key==='Enter')shSend()" onfocus="$('#nav').style.display='none'" onblur="$('#nav').style.display='flex'"></div>`);
  const e = $('#term'); e.textContent = TS.buf; e.scrollTop = e.scrollHeight;
}
function ctl(n) { Ssh.send(String.fromCharCode(n)); }
function shSend() { const i = $('#ti'), v = i.value; Ssh.send(v + '\n'); if (v && TS.hist[TS.hist.length - 1] !== v) TS.hist.push(v); TS.hi = TS.hist.length; i.value = ''; }
function hs(d) { TS.hi = Math.max(0, Math.min(TS.hist.length, TS.hi + d)); $('#ti').value = TS.hist[TS.hi] || ''; }
function shConn(h, p, u, pw) { if (TS.busy) return; if (!/^[\w.:-]+$/.test(h)) return toast(_('Некорректный адрес', 'Invalid address')); TS.busy = true; TS.host = u + '@' + h; toast(_('Подключение…', 'Connecting…')); Ssh.connect(h, p, u, pw, Math.max(40, Math.floor(innerWidth / 7.4)), 24); }
function shGo() { shConn($('#sh_h').value.trim(), +$('#sh_p').value || 22, $('#sh_u').value.trim() || 'root', $('#sh_w').value); }
function shR() { const r = R(); shConn(r.a.replace(/^https?:\/\//, '').split('/')[0].replace(/:\d+$/, ''), 22, r.u || 'root', r.p); }
function shUse(i) { const x = shl()[i]; shConn(x.h, x.p, x.u, x.pw); }
function shDel(i) { const p = shl(); p.splice(i, 1); Native.secSet('ss', JSON.stringify(p)); form_ssh(); }
function shSave() { const h = $('#sh_h').value.trim(); if (!h) return toast(_('Введите адрес', 'Enter the address')); const p = shl(); p.push({ n: h, h, p: +$('#sh_p').value || 22, u: $('#sh_u').value.trim() || 'root', pw: $('#sh_w').value }); Native.secSet('ss', JSON.stringify(p)); toast(_('Сохранено', 'Saved')); form_ssh(); }
// ---------------- boot ----------------
function boot() {
  try { rs = JSON.parse(Native.secGet('rs') || '[]'); } catch (e) { rs = []; }
  if (cur >= rs.length) cur = 0;
  ap(); go('home');
}
