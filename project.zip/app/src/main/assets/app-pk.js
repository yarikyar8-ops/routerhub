'use strict';
const K = { tab: 'st', pkg: null, sec: null, cfg: {}, ping: {}, subs: null, open: null, sel: new Set(), inst: {}, rel: null, busy: false };
const CAT = [
  { id: 'podkop', repo: 'itdoginfo/podkop', name: 'Podkop', off: 1, pats: ['^podkop', '^luci-app-podkop', '^luci-i18n-podkop-ru'],
    d: ['Официальный Podkop: направляет в туннель только выбранные сайты и сервисы через sing-box. Сейчас выпускается для opkg (OpenWrt 24.10).', 'Official Podkop: routes only chosen sites and services through a tunnel using sing-box. Currently released for opkg (OpenWrt 24.10).'] },
  { id: 'forkop', repo: 'slayer326/forkop', name: 'Forkop', off: 0, pats: ['^forkop', '^luci-app-forkop', '^luci-i18n-forkop-ru'],
    d: ['Форк Podkop с отдельным пакетом forkop; в релизах есть пакеты для opkg и для apk (OpenWrt 25.12).', 'A Podkop fork shipped as the forkop package; releases include opkg and apk packages (OpenWrt 25.12).'] },
  { id: 'engine', repo: 'podkop-net/podkop-engine', name: 'podkop-engine', off: 0, pats: ['sing-box', 'podkop-engine'],
    d: ['Неофициальная сборка sing-box для Podkop с патчами. Автор прямо указывает, что к проекту sing-box она не относится.', 'Unofficial sing-box build for Podkop with patches. The author states it is not affiliated with the sing-box project.'] },
  { id: 'analyzer', repo: 'MaksSt/forkop-analyzer', name: 'Forkop Analyzer', off: 0, pats: ['forkop-analyzer'],
    d: ['Тест и сравнение серверов для Forkop (OpenWrt 25.12, apk). Создаёт реальный тестовый трафик.', 'Server benchmark for Forkop (OpenWrt 25.12, apk). Generates real test traffic.'] },
  { id: 'check', repo: 'Hellington-Rey/sing-box-service-check', name: 'sing-box service check', off: 0, pats: ['service-check'],
    d: ['Диагностика маршрута и DNS для Podkop/Forkop (LuCI-приложение).', 'Route and DNS diagnostics for Podkop/Forkop (LuCI app).'] }
];
const catAll = () => CAT.concat((LS.get('catx', []) || []).filter(L.okRepo).map(r => ({ id: 'x_' + r, repo: r, name: r.split('/')[1], off: 0, custom: 1, pats: ['.'], d: ['Добавлено вами. Мной не проверялось.', 'Added by you. Not reviewed by me.'] })));
const subsLoad = () => { if (K.subs === null) { try { K.subs = JSON.parse(Native.secGet('subs') || '[]'); } catch (e) { K.subs = []; } } return K.subs; };
const subsSave = () => Native.secSet('subs', JSON.stringify(K.subs || []));

async function pkDetect() {
  const names = (await out('ls /etc/config 2>/dev/null')).split('\n').map(x => x.trim());
  K.pkg = names.includes('podkop') ? 'podkop' : names.includes('forkop') ? 'forkop' : null;
  K.cfg = {}; if (!K.pkg) { K.sec = null; return; }
  K.cfg = await U.get(K.pkg);
  const secs = Object.keys(K.cfg).filter(k => K.cfg[k]['.type'] === 'section');
  K.sec = (K.sec && secs.includes(K.sec)) ? K.sec : (secs[0] || null);
}
const arr = x => [].concat(x == null ? [] : x).filter(v => v !== '');
function curKeys() {
  const s = K.cfg[K.sec] || {}, mode = s.proxy_config_type || 'url';
  const raw = mode === 'url' ? arr(s.proxy_string) : mode === 'selector' ? arr(s.selector_proxy_links) : mode === 'urltest' ? arr(s.urltest_proxy_links) : [];
  return { mode, links: raw.map(L.parseLink).map((p, i) => p || { proto: '?', name: raw[i].slice(0, 30), host: '', port: 0, raw: raw[i] }) };
}
P.pk = async () => { await pkDetect(); await pkShow(); };
async function pkTab(k) { K.tab = k; V(`<div class=sub style="margin-top:40px;text-align:center">${_('Загрузка…', 'Loading…')}</div>`); try { await pkShow(); } catch (e) { V(errCard(e)); } }
const pkHead = () => H.hd('Podkop') + H.seg([['st', _('Состояние', 'Status')], ['keys', _('Ключи', 'Keys')], ['sub', _('Подписки', 'Subscriptions')], ['upd', _('Обновления', 'Updates')], ['lib', _('Библиотека', 'Library')]], K.tab, 'pkTab');
async function pkShow() {
  let b = '';
  if (K.tab === 'st') b = await pkStatusView();
  else if (K.tab === 'keys') b = pkKeysView();
  else if (K.tab === 'sub') b = pkSubView();
  else if (K.tab === 'upd') b = await pkUpdView();
  else b = await pkLibView();
  V(pkHead() + b);
}
const noPk = () => H.card('', `<div class=sub style="margin:0 0 10px">${_('Podkop или Forkop не найден на этом роутере. Установить можно из библиотеки.', 'Podkop or Forkop was not found on this router. You can install it from the library.')}</div><button class=p onclick="pkTab('lib')">${_('Открыть библиотеку', 'Open library')}</button>`);
// ---------- status ----------
async function pkStatusView() {
  if (!K.pkg) return noPk();
  const p = K.pkg;
  const s = L.sections(await out(`echo '##RUN'; /etc/init.d/${p} running >/dev/null 2>&1 && echo 1 || echo 0\necho '##SB'; sing-box version 2>/dev/null | head -1\necho '##ST'; ${p} get_status 2>&1 | head -c 500\necho '##LOG'; logread 2>/dev/null | grep -iE '${p}|sing-box' | tail -n 10\ntrue`));
  const run = (s.RUN || '').trim() === '1', ck = curKeys();
  return H.card('', `<div class=big><span class="dot ${run ? 'on' : ''}"></span>${esc(p)}<small> ${run ? _('работает', 'running') : _('остановлен', 'stopped')}</small></div>
<div class=sub style="margin:6px 0 12px">${esc((s.SB || '').trim() || 'sing-box: —')} · ${_('режим', 'mode')}: ${esc(ck.mode)} · ${_('ключей', 'keys')}: ${ck.links.length}</div>
<div class=grid><button class=p onclick="pkSvc('restart')">🔄 ${_('Перезапустить', 'Restart')}</button><button onclick="pkSvc('${run ? 'stop' : 'start'}')">${run ? '⏹ ' + _('Остановить', 'Stop') : '▶ ' + _('Запустить', 'Start')}</button></div>`) +
    H.card(_('Проверка состояния', 'Health check'), `<pre class=jl style="max-height:130px">${esc((s.ST || '').trim() || '—')}</pre>`) +
    H.card(_('Журнал', 'Log'), `<pre class=jl>${esc((s.LOG || '').trim() || '—')}</pre>`);
}
async function pkSvc(a) { toast('…'); await sh(`/etc/init.d/${K.pkg} ${a} >/dev/null 2>&1 &\ntrue`); await sleep(3500); await pkShow(); }
// ---------- keys ----------
const protoBadge = l => `<span class=pb>${esc(l.proto)}</span>`;
function pingChip(r) { if (!r) return ''; return r.ok ? `<span class="chip ok">${r.ms != null ? '~' + Math.round(r.ms) + ' ms' : _('доступен', 'reachable')}</span>` : `<span class="chip bad">${_('не отвечает', 'down')}</span>`; }
function keyRows(links, key, sel) {
  const pr = K.ping[key] || {};
  return links.map((l, i) => `<div class=row>${sel ? `<label class=ck><input type=checkbox ${K.sel.has(i) ? 'checked' : ''} onchange="selKey(${i},this.checked)"><i></i></label>` : ''}<div class=rl>${protoBadge(l)} ${esc(l.name)}<small>${esc(l.host)}:${l.port || '?'}</small></div><div>${pingChip(pr[i])}</div></div>`).join('') || `<div class=sub>${_('Ключей нет', 'No keys')}</div>`;
}
function pkKeysView() {
  if (!K.pkg) return noPk();
  const ck = curKeys();
  return H.card(_('Режим', 'Mode'), H.seg([['url', _('Один', 'Single')], ['selector', _('Выбор', 'Selector')], ['urltest', _('Авто (лучший)', 'Auto (best)')]], ck.mode, 'pkMode')) +
    H.card(`${_('Ключи', 'Keys')} · ${ck.links.length}`, `<div class=grid style="margin-bottom:8px"><button class=p onclick="pingCur()">📡 ${_('Пинг всех', 'Ping all')}</button><button onclick="keyAdd()">➕ ${_('Добавить ключ', 'Add key')}</button></div><div id=kl>${keyRows(ck.links, 'cur', false)}</div>`) +
    (ck.links.length ? H.card('', `<button class=d onclick="keyClear()">🗑 ${_('Удалить все ключи', 'Remove all keys')}</button>`) : '');
}
async function pkApply(links, mode) {
  if (!K.sec) throw new Error(_('Не найдена секция Podkop', 'Podkop section not found'));
  if (mode === 'url' && !links.length) throw new Error(_('Нужен хотя бы один ключ', 'At least one key is needed'));
  const lst = { url: 'proxy_string', selector: 'selector_proxy_links', urltest: 'urltest_proxy_links' }[mode];
  const v = { connection_type: 'proxy', proxy_config_type: mode };
  if (links.length) v[lst] = mode === 'url' ? links[0] : links;
  await U.set(K.pkg, K.sec, v);
  if (!links.length) await U.del(K.pkg, K.sec, [lst]).catch(() => { });
  if (mode !== 'url') await U.del(K.pkg, K.sec, ['proxy_string']).catch(() => { });
  await applyCfg(K.pkg); K.cfg = await U.get(K.pkg);
}
async function pkMode(m) { const ck = curKeys(); try { await pkApply(ck.links.map(l => l.raw).slice(0, m === 'url' ? 1 : 999), m); toast(_('Режим изменён, Podkop перезапускается', 'Mode changed, restarting Podkop')); } catch (e) { toast(e.message); } await pkShow(); }
async function keyAdd() {
  const v = await askText(_('Добавить ключ', 'Add key'), 'vless:// vmess:// trojan:// ss:// hy2:// ...', '');
  if (!v) return;
  const p = L.parseLink(v.trim()); if (!p) return toast(_('Не удалось разобрать ссылку', 'Cannot parse the link'));
  const ck = curKeys();
  try { await pkApply(ck.mode === 'url' ? [p.raw] : ck.links.map(l => l.raw).concat(p.raw), ck.mode); toast(_('Добавлено', 'Added')); } catch (e) { toast(e.message); }
  await pkShow();
}
async function keyClear() { if (await ask(_('Удалить все ключи?', 'Remove all keys?'), '', _('Удалить', 'Remove'), true)) { try { await pkApply([], curKeys().mode === 'url' ? 'selector' : curKeys().mode); } catch (e) { toast(e.message); } await pkShow(); } }
async function pingList(links, key, rerender) {
  K.ping[key] = {};
  const items = links.map((l, i) => ({ i, host: l.host, port: l.port }));
  for (let c = 0; c < items.length; c += 10) {
    const t = await out(L.pingCmd(items.slice(c, c + 10)));
    Object.assign(K.ping[key], L.parsePing(t)); rerender();
  }
}
async function pingCur() { toast(_('Проверяю…', 'Checking…')); try { await pingList(curKeys().links, 'cur', () => { const e = $('#kl'); if (e) e.innerHTML = keyRows(curKeys().links, 'cur', false); }); } catch (e) { toast(e.message); } }
// ---------- subscriptions ----------
function pkSubView() {
  const subs = subsLoad();
  if (K.open !== null && subs[K.open]) return subDetail(subs[K.open]);
  return H.card('', `<button class=p onclick="subAdd()">➕ ${_('Добавить ссылку-подписку от провайдера', 'Add a provider subscription link')}</button>`) +
    (subs.length ? H.card(_('Подписки', 'Subscriptions'), subs.map((s, i) => H.row(`🔗 ${esc(s.provider)}`, `${s.links.length} ${_('ключей', 'keys')}${s.info && s.info.total ? ' · ' + L.fmtB(s.info.used) + ' / ' + L.fmtB(s.info.total) : ''}`, '›', `subOpen(${i})`)).join('')) : `<div class=sub style="text-align:center;margin-top:20px">${_('Подписок пока нет. Вставьте ссылку от провайдера: приложение само расшифрует её и достанет ключи.', 'No subscriptions yet. Paste a provider link: the app decodes it and extracts the keys.')}</div>`);
}
function subDetail(s) {
  const i = K.open, inf = s.info || {}, exp = inf.expire ? new Date(inf.expire * 1000).toLocaleDateString() : '';
  return `<button class=s style="margin:0 0 10px" onclick="K.open=null;pkShow()">‹ ${_('Назад', 'Back')}</button>` +
    H.card(`🔗 ${esc(s.provider)}`, `<div class=sub style="margin:0 0 10px">${esc(inf.host || '')}${inf.total ? `<br>${_('Трафик', 'Traffic')}: ${L.fmtB(inf.used)} / ${L.fmtB(inf.total)}` : ''}${exp ? `<br>${_('Действует до', 'Valid until')}: ${exp}` : ''}${inf.web ? `<br>${esc(inf.web)}` : ''}</div><div class=grid><button onclick="subRefresh(${i})">🔄 ${_('Обновить', 'Refresh')}</button><button class=d onclick="subDel(${i})">🗑 ${_('Удалить', 'Delete')}</button></div>`) +
    H.card(`${_('Ключи', 'Keys')} · ${s.links.length}`, `<div class=grid style="margin-bottom:8px"><button class=p onclick="subPing(${i})">📡 ${_('Пинг всех', 'Ping all')}</button><button onclick="selAll(${s.links.length})">☑ ${_('Выбрать все', 'Select all')}</button></div><div id=kl>${keyRows(s.links, 'sub' + i, true)}</div>`) +
    H.card(_('Применить в Podkop', 'Apply to Podkop'), K.pkg ? `<div class=sub style="margin:0 0 8px">${_('Выбранные ключи заменят текущие. Режим «Авто» сам выбирает самый быстрый.', 'Selected keys replace the current ones. Auto mode picks the fastest.')}</div><div class=grid><button class=p onclick="subApply(${i},'urltest')">⚡ ${_('Авто', 'Auto')}</button><button onclick="subApply(${i},'selector')">🎛 ${_('Выбор', 'Selector')}</button></div>` : `<div class=sub style="margin:0">${_('Podkop не установлен.', 'Podkop is not installed.')}</div>`);
}
const subOpen = i => { K.open = i; K.sel = new Set(); pkShow(); };
const selKey = (i, on) => { if (on) K.sel.add(i); else K.sel.delete(i); };
const selAll = n => { K.sel = new Set(Array.from({ length: n }, (_x, i) => i)); pkShow(); };
async function subFetch(url) {
  if (!/^https?:\/\/[^\s'"`\\]+$/.test(url)) throw new Error(_('Нужна ссылка http(s)', 'An http(s) link is required'));
  const s = L.sections(await out(L.fetchCmd(url))), dec = L.decodeSub(s.BODY || '');
  if (!dec.links.length) {
    const why = { empty: _('Ответ пустой: ссылка не открылась с роутера (возможно, домен заблокирован или нет интернета).', 'Empty response: the link did not open from the router (domain may be blocked or there is no internet).'), json: _('Формат sing-box JSON пока не поддерживается. Нужна ссылка формата v2ray (base64).', 'sing-box JSON is not supported yet. A v2ray (base64) link is required.'), clash: _('Формат Clash пока не поддерживается. Нужна ссылка формата v2ray (base64).', 'Clash format is not supported yet. A v2ray (base64) link is required.'), unknown: _('Не удалось найти ключи в ответе.', 'No keys found in the response.') }[dec.fmt];
    throw new Error(why);
  }
  return { info: L.subInfo(L.parseHdr(s.HDR || ''), url), links: dec.links };
}
async function subAdd() {
  const url = await askText(_('Ссылка-подписка', 'Subscription link'), 'https://…', ''); if (!url) return;
  toast(_('Загружаю…', 'Fetching…'));
  try {
    const r = await subFetch(url.trim()), subs = subsLoad();
    subs.push({ url: url.trim(), provider: r.info.provider, info: r.info, links: r.links, ts: Date.now() }); subsSave();
    K.open = subs.length - 1; K.sel = new Set(); toast(`✅ ${r.info.provider}: ${r.links.length} ${_('ключей', 'keys')}`);
  } catch (e) { toast(e.message); }
  await pkShow();
}
async function subRefresh(i) { toast(_('Обновляю…', 'Refreshing…')); try { const s = subsLoad()[i], r = await subFetch(s.url); Object.assign(s, { provider: r.info.provider, info: r.info, links: r.links, ts: Date.now() }); subsSave(); K.ping['sub' + i] = {}; K.sel = new Set(); } catch (e) { toast(e.message); } await pkShow(); }
async function subDel(i) { if (await ask(_('Удалить подписку?', 'Delete subscription?'), '', _('Удалить', 'Delete'), true)) { subsLoad().splice(i, 1); subsSave(); K.open = null; await pkShow(); } }
async function subPing(i) { toast(_('Проверяю…', 'Checking…')); try { await pingList(subsLoad()[i].links, 'sub' + i, () => { const e = $('#kl'); if (e) e.innerHTML = keyRows(subsLoad()[i].links, 'sub' + i, true); }); } catch (e) { toast(e.message); } }
async function subApply(i, mode) {
  const s = subsLoad()[i], pick = s.links.filter((_l, j) => K.sel.has(j));
  if (!pick.length) return toast(_('Отметьте ключи галочками', 'Tick some keys first'));
  if (!await ask(_('Заменить ключи в Podkop?', 'Replace keys in Podkop?'), `${pick.length} ${_('ключей', 'keys')} · ${mode}`, _('Применить', 'Apply'))) return;
  try { await pkApply(pick.map(l => l.raw), mode); toast(_('Применено, Podkop перезапускается', 'Applied, Podkop is restarting')); } catch (e) { toast(e.message); }
}
// ---------- updates ----------
const REL_NAMES = ['podkop', 'luci-app-podkop', 'luci-i18n-podkop-ru', 'forkop', 'luci-app-forkop', 'sing-box', 'nlbwmon'];
async function pkUpdView() {
  K.inst = await installed();
  const rows = REL_NAMES.filter(n => n in K.inst).map(n => H.row(esc(n), '', `<span class=chip>${esc(K.inst[n])}</span>`)).join('');
  return H.card(_('Установлено', 'Installed'), rows || `<div class=sub>${_('Пакеты Podkop и sing-box не найдены.', 'Podkop and sing-box packages not found.')}</div>`) +
    H.card(_('Обновить', 'Update'), `<button class=p onclick="pkCheck()">🔍 ${_('Проверить обновления', 'Check for updates')}</button><div id=uc></div>
<div class=grid style="margin-top:10px"><button onclick="pkRelease('podkop')">⬆ Podkop</button><button onclick="pkSingbox()">⬆ sing-box</button></div>
<div class=sub style="margin:10px 0 0">${_('Podkop обновляется из официального релиза на GitHub, sing-box из репозитория пакетов OpenWrt. Роутеру нужен интернет.', 'Podkop is updated from the official GitHub release; sing-box from the OpenWrt package feed. The router needs internet access.')}</div>`);
}
async function pkCheck() {
  const c = L.pmCmd(await pm());
  if (await jobSheet(_('Обновление списков пакетов', 'Refreshing package lists'), c.upd) !== 0) return;
  const up = L.parseUpgradable(await out(c.up)).filter(x => /podkop|forkop|sing-box|nlbwmon/.test(x.name));
  const rel = L.parseRelease(await out(L.ghCmd('itdoginfo/podkop')).catch(() => ''));
  const e = $('#uc');
  if (e) e.innerHTML = `<div class=sub style="margin:10px 0 0">${up.length ? up.map(x => `${esc(x.name)}: ${esc(x.from)} → ${esc(x.to)}`).join('<br>') : _('В репозитории пакетов обновлений нет.', 'No updates in the package feed.')}${rel ? `<br>Podkop (GitHub): ${esc(rel.tag_name)}` : ''}</div>`;
}
async function pkSingbox() {
  if (!await ask(_('Обновить sing-box?', 'Update sing-box?'), _('Версия берётся из репозитория OpenWrt. Podkop будет перезапущен.', 'The version comes from the OpenWrt feed. Podkop will be restarted.'), _('Обновить', 'Update'))) return;
  const c = L.pmCmd(await pm());
  await jobSheet('sing-box', `${c.upd}; ${c.upg('sing-box')}; [ -x /etc/init.d/${K.pkg || 'podkop'} ] && /etc/init.d/${K.pkg || 'podkop'} restart`);
}
async function pkRelease(id) {
  const e = catAll().find(x => x.id === id); if (!e) return;
  toast(_('Загружаю данные релиза…', 'Fetching release info…'));
  let rel = null; try { rel = L.parseRelease(await out(L.ghCmd(e.repo))); } catch (er) { }
  if (!rel) return toast(_('Не удалось получить релиз с GitHub (нет интернета или лимит запросов).', 'Could not fetch the GitHub release (no internet or rate limit).'));
  const p = await pm(), ext = L.pmCmd(p).ext, arch = (await out('. /etc/openwrt_release 2>/dev/null; echo $DISTRIB_ARCH')).trim();
  const as = L.pickAssets(rel, ext, arch, e.pats);
  K.rel = { e, as, p };
  sheet(`<h3>${esc(e.name)} · ${esc(rel.tag_name)}</h3><div class=sub>${e.off ? '✅ ' + _('Официальный проект', 'Official project') : '⚠️ ' + _('Сообщество: репозиторий найден и имеет релизы, но код мной не проверялся. Устанавливайте только если доверяете автору.', 'Community: the repository exists and has releases, but I have not reviewed its code. Install only if you trust the author.')}<br>github.com/${esc(e.repo)}${rel.published_at ? '<br>' + esc(rel.published_at.slice(0, 10)) : ''}</div>` +
    (p === 'apk' ? `<div class=sub>⚠️ ${_('Пакеты apk из релизов не подписаны ключом OpenWrt, установка идёт с флагом --allow-untrusted.', 'Release apk packages are not signed with an OpenWrt key; installing with --allow-untrusted.')}</div>` : '') +
    (as.length ? `<div class=assets>` + as.map((a, i) => `<label class=asr><input type=checkbox id=as${i} ${a.pre ? 'checked' : ''}><span>${esc(a.name)}<small>${L.fmtB(a.size)}${a.archOk ? '' : ' · ' + _('другая архитектура', 'other architecture')}${a.digest ? ' · ' + esc(a.digest.slice(0, 19)) + '…' : ''}</small></span></label>`).join('') + `</div><div class=g2><button onclick="closeSheet()">${_('Отмена', 'Cancel')}</button><button class=p onclick="pkInstall()">${_('Установить', 'Install')}</button></div>` : `<div class=sub>${_('В релизе нет пакетов ' + ext + ' для вашей системы. Для этого проекта, вероятно, нужна другая версия OpenWrt.', 'This release has no ' + ext + ' packages for your system. This project probably needs a different OpenWrt version.')}</div><button class=p onclick="closeSheet()">OK</button>`));
}
async function pkInstall() {
  const sel = K.rel.as.filter((_a, i) => { const c = $('#as' + i); return c && c.checked; });
  if (!sel.length) return toast(_('Отметьте пакеты', 'Tick some packages'));
  closeSheet();
  await jobSheet(_('Установка', 'Installing'), L.installCmd(K.rel.p, sel));
  K.inst = {};
}
// ---------- library ----------
async function pkLibView() {
  const inst = await installed();
  const cards = catAll().map(e => {
    const have = Object.keys(inst).filter(n => e.pats.some(p => new RegExp(p, 'i').test(n)) && /podkop|forkop|sing-box/i.test(n));
    return H.card('', `<div class=lh><b>${esc(e.name)}</b><span class="chip ${e.off ? 'ok' : 'warn'}">${e.off ? _('Официальный', 'Official') : _('Сообщество', 'Community')}</span></div><div class=sub style="margin:6px 0">${_(e.d[0], e.d[1])}</div><div class=sub style="margin:0 0 8px">github.com/${esc(e.repo)}${have.length ? '<br>✔ ' + have.map(n => esc(n + ' ' + inst[n])).join(', ') : ''}</div><button class=p onclick="pkRelease('${e.id.replace(/'/g, '')}')">${_('Релиз и установка', 'Release & install')}</button>`);
  }).join('');
  return H.card('', `<div class=sub style="margin:0">${_('Каталог проектов вокруг Podkop. Все пакеты скачиваются из релизов GitHub прямо на роутер. «Сообщество» означает, что проект найден и у него есть релизы, но код мной не проверялся.', 'A catalog of projects around Podkop. Packages are downloaded from GitHub releases directly onto the router. "Community" means the project exists and has releases, but I have not reviewed its code.')}</div>`) + cards +
    H.card('', `<button onclick="catAdd()">➕ ${_('Добавить свой репозиторий', 'Add your own repository')}</button>`);
}
async function catAdd() {
  const v = await askText(_('Репозиторий GitHub', 'GitHub repository'), 'owner/repo', ''); if (!v) return;
  if (!L.okRepo(v.trim())) return toast(_('Формат: владелец/репозиторий', 'Format: owner/repository'));
  const x = LS.get('catx', []); if (!x.includes(v.trim())) x.push(v.trim()); LS.set('catx', x); await pkShow();
}
