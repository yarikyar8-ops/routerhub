'use strict';
const K = { tab: 'st', pkg: null, sec: null, cfg: {}, ping: {}, subs: null, open: null, sel: new Set(), inst: {}, rel: null, found: [], gq: 'podkop openwrt' };
const FAM = { podkop: ['luci-i18n-podkop-ru', 'luci-app-podkop', 'podkop'], forkop: ['luci-i18n-forkop-ru', 'luci-app-forkop', 'forkop'], netshift: ['luci-i18n-netshift-ru', 'luci-app-netshift', 'netshift'] };
const CAT = [
  { id: 'podkop', repo: 'itdoginfo/podkop', name: 'Podkop', off: 1, fam: 'podkop', pats: ['^podkop', '^luci-app-podkop', '^luci-i18n-podkop-ru'],
    d: ['Официальный Podkop: направляет в туннель только выбранные сайты и сервисы через sing-box. Есть пакеты opkg (OpenWrt 24.10) и apk (25.12).', 'Official Podkop: routes only chosen sites and services through a tunnel using sing-box. Packages for opkg (OpenWrt 24.10) and apk (25.12).'] },
  { id: 'netshift', repo: 'yandexru45/netshift', name: 'NetShift', off: 0, fam: 'netshift', pats: ['^netshift', '^luci-app-netshift', '^luci-i18n-netshift-ru'],
    d: ['Форк Podkop с расширениями: подписки, URLTest, переключаемое ядро sing-box. Сам переносит настройки Podkop при установке.', 'A Podkop fork with extras: subscriptions, URLTest, switchable sing-box core. Migrates Podkop settings on install.'] },
  { id: 'forkop', repo: 'slayer326/forkop', name: 'Forkop', off: 0, fam: 'forkop', pats: ['^forkop', '^luci-app-forkop', '^luci-i18n-forkop-ru'],
    d: ['Форк Podkop с отдельным пакетом forkop; в релизах есть пакеты opkg и apk (OpenWrt 25.12).', 'A Podkop fork shipped as the forkop package; releases include opkg and apk packages (OpenWrt 25.12).'] },
  { id: 'engine', repo: 'podkop-net/podkop-engine', name: 'podkop-engine', off: 0, pats: ['sing-box', 'podkop-engine'],
    d: ['Неофициальная сборка sing-box для Podkop с патчами. Автор указывает, что к проекту sing-box она не относится.', 'Unofficial sing-box build for Podkop with patches. The author states it is not affiliated with the sing-box project.'] },
  { id: 'kapji', repo: 'KapJI/podkop', name: 'KapJI/podkop', off: 0, pats: ['podkop'],
    d: ['Ранний форк Podkop. Описание взято из репозитория, активность не проверялась.', 'An early Podkop fork. Description taken from the repository; activity not checked.'] },
  { id: 'subs', repo: 'tickcount/podkop-subscriptions', name: 'podkop-subscriptions', off: 0, pats: ['subscriptions'],
    d: ['Подписки для Podkop (проект сообщества). Описание не проверялось.', 'Subscriptions for Podkop (community project). Description not reviewed.'] },
  { id: 'analyzer', repo: 'MaksSt/forkop-analyzer', name: 'Forkop Analyzer', off: 0, pats: ['forkop-analyzer'],
    d: ['Тест и сравнение серверов для Forkop (OpenWrt 25.12, apk). Создаёт реальный тестовый трафик.', 'Server benchmark for Forkop (OpenWrt 25.12, apk). Generates real test traffic.'] },
  { id: 'check', repo: 'Hellington-Rey/sing-box-service-check', name: 'sing-box service check', off: 0, pats: ['service-check'],
    d: ['Диагностика маршрута и DNS для Podkop/Forkop (LuCI-приложение).', 'Route and DNS diagnostics for Podkop/Forkop (LuCI app).'] },
  { id: 'homeproxy', feed: ['luci-app-homeproxy'], name: 'HomeProxy', off: 0, repo: 'immortalwrt/homeproxy', pats: ['.'],
    d: ['Другое приложение на sing-box из репозитория пакетов (если оно есть для вашей версии OpenWrt). Не заменяет Podkop, не ставьте вместе.', 'Another sing-box app from the package feed (if available for your OpenWrt version). Not a Podkop replacement; do not run both.'] }
];
const catAll = () => CAT.concat((LS.get('catx', []) || []).filter(L.okRepo).filter(r => !CAT.some(c => c.repo === r)).map(r => ({ id: 'x_' + r.replace(/[^\w]/g, '_'), repo: r, name: r.split('/')[1], off: 0, custom: 1, pats: ['.'], d: ['Добавлено вами. Мной не проверялось.', 'Added by you. Not reviewed by me.'] })));
const subsLoad = () => { if (K.subs === null) { try { K.subs = JSON.parse(Native.secGet('subs') || '[]'); } catch (e) { K.subs = []; } } return K.subs; };
const subsSave = () => Native.secSet('subs', JSON.stringify(K.subs || []));
const arr = x => [].concat(x == null ? [] : x).filter(v => v !== '');

async function pkDetect() {
  const names = (await out('ls /etc/config 2>/dev/null')).split('\n').map(x => x.trim());
  K.pkg = ['podkop', 'netshift', 'forkop'].find(n => names.includes(n)) || null;
  K.cfg = {}; if (!K.pkg) { K.sec = null; return; }
  K.cfg = await U.get(K.pkg); CV[K.pkg] = K.cfg;
  const secs = Object.keys(K.cfg).filter(k => K.cfg[k]['.type'] === 'section');
  K.sec = (K.sec && secs.includes(K.sec)) ? K.sec : (secs[0] || null);
}
function curKeys() {
  const s = K.cfg[K.sec] || {}, mode = s.proxy_config_type || 'url';
  const raw = mode === 'url' ? arr(s.proxy_string) : mode === 'selector' ? arr(s.selector_proxy_links) : mode === 'urltest' ? arr(s.urltest_proxy_links) : [];
  return { mode, links: raw.map(L.parseLink).map((p, i) => p || { proto: '?', name: raw[i].slice(0, 30), host: '', port: 0, raw: raw[i] }) };
}
P.pk = async () => { await pkDetect(); await pkShow(); };
async function pkTab(k) { K.tab = k; V(`<div class=sub style="margin-top:40px;text-align:center">${_('Загрузка…', 'Loading…')}</div>`); try { await pkShow(); } catch (e) { V(errCard(e)); } }
const pkHead = () => H.hd('Podkop') + H.seg([['st', _('Состояние', 'Status')], ['sec', _('Разделы', 'Sections')], ['set', _('Настройки', 'Settings')], ['keys', _('Ключи', 'Keys')], ['sub', _('Подписки', 'Subscriptions')], ['upd', _('Обновления', 'Updates')], ['lib', _('Библиотека', 'Library')]], K.tab, 'pkTab');
async function pkShow() {
  let b = '';
  if (K.tab === 'st') b = await pkStatusView();
  else if (K.tab === 'sec') b = pkSecView();
  else if (K.tab === 'set') b = pkSetView();
  else if (K.tab === 'keys') b = pkKeysView();
  else if (K.tab === 'sub') b = pkSubView();
  else if (K.tab === 'upd') b = await pkUpdView();
  else b = await pkLibView();
  V(pkHead() + b);
}
const noPk = () => H.card('', `<div class=sub style="margin:0 0 10px">${_('Podkop, NetShift или Forkop не найден на этом роутере. Установить можно из библиотеки.', 'Podkop, NetShift or Forkop was not found on this router. You can install one from the library.')}</div><button class=p onclick="pkTab('lib')">${_('Открыть библиотеку', 'Open library')}</button>`);
// ---------- status ----------
async function pkStatusView() {
  if (!K.pkg) return noPk();
  const p = K.pkg;
  const s = L.sections(await out(`echo '##RUN'; /etc/init.d/${p} running >/dev/null 2>&1 && echo 1 || echo 0\necho '##SB'; sing-box version 2>/dev/null | head -1\necho '##ST'; ${p} get_status 2>&1 | head -c 500\necho '##LOG'; logread 2>/dev/null | grep -iE '${p}|sing-box' | tail -n 10\ntrue`));
  const run = (s.RUN || '').trim() === '1', ck = curKeys();
  return H.card('', `<div class=big><span class="dot ${run ? 'on' : ''}"></span>${esc(p)}<small> ${run ? _('работает', 'running') : _('остановлен', 'stopped')}</small></div>
<div class=sub style="margin:6px 0 12px">${esc((s.SB || '').trim() || 'sing-box: —')} · ${_('режим', 'mode')}: ${esc(ck.mode)} · ${_('ключей', 'keys')}: ${ck.links.length}</div>
<div class=grid><button class=p onclick="pkSvc('restart')">🔄 ${_('Перезапустить', 'Restart')}</button><button onclick="pkSvc('${run ? 'stop' : 'start'}')">${run ? '⏹ ' + _('Остановить', 'Stop') : '▶ ' + _('Запустить', 'Start')}</button></div>`) +
    H.card(_('Проверка состояния', 'Health check'), `<pre class=jl style="max-height:130px">${esc((s.ST || '').trim() || '—')}</pre>`) +
    H.card(_('Журнал', 'Log'), `<pre class=jl>${esc((s.LOG || '').trim() || '—')}</pre>`);
}
async function pkSvc(a) { toast('…'); await sh(`/etc/init.d/${K.pkg} ${a} >/dev/null 2>&1 &\ntrue`); await sleep(3500); await pkShow(); }
// ---------- native sections & settings (no need to open the web UI) ----------
function pkSecView() {
  if (!K.pkg) return noPk();
  return H.card('', `<div class=sub style="margin:0">${_('Раздел — это правило: какой трафик (списки сайтов, домены, подсети) и куда отправлять (прокси, VPN, блок, напрямую).', 'A section is a rule: which traffic (site lists, domains, subnets) goes where (proxy, VPN, block, direct).')}</div>`) + cfgCard('pkSec');
}
function pkSetView() { if (!K.pkg) return noPk(); return cfgCard('pkSet') + H.card('', `<button onclick="go('uci','${K.pkg}')">🛠 ${_('Все параметры (редактор UCI)', 'All options (UCI editor)')}</button>`); }
// ---------- keys ----------
const protoBadge = l => `<span class=pb>${esc(l.proto)}</span>`;
function pingChip(r) { if (!r) return ''; return r.ok ? `<span class="chip ok">${r.ms != null ? '~' + Math.round(r.ms) + ' ms' : _('доступен', 'reachable')}</span>` : `<span class="chip bad">${_('не отвечает', 'down')}</span>`; }
function keyRows(links, key, sel) {
  const pr = K.ping[key] || {};
  return links.map((l, i) => `<div class=row>${sel ? `<label class=ck><input type=checkbox ${K.sel.has(i) ? 'checked' : ''} onchange="selKey(${i},this.checked)"><i></i></label>` : ''}<div class=rl>${protoBadge(l)} ${esc(l.name)}<small>${esc(l.host)}:${l.port || '?'}</small></div><div>${pingChip(pr[i])}</div></div>`).join('') || `<div class=sub>${_('Ключей нет', 'No keys')}</div>`;
}
function pkKeysView() {
  if (!K.pkg) return noPk();
  const ck = curKeys(), secs = Object.keys(K.cfg).filter(k => K.cfg[k]['.type'] === 'section' && sid(k));
  return (secs.length > 1 ? H.card(_('Раздел', 'Section'), `<select onchange="K.sec=this.value;pkShow()">${secs.map(k => `<option value="${k}" ${k === K.sec ? 'selected' : ''}>${esc(k)}</option>`).join('')}</select>`) : '') +
    H.card(_('Режим', 'Mode'), H.seg([['url', _('Один', 'Single')], ['selector', _('Выбор', 'Selector')], ['urltest', _('Авто (лучший)', 'Auto (best)')]], ck.mode, 'pkMode')) +
    H.card(`${_('Ключи', 'Keys')} · ${ck.links.length}`, `<div class=grid style="margin-bottom:8px"><button class=p onclick="pingCur()">📡 ${_('Пинг всех', 'Ping all')}</button><button onclick="keyAdd()">➕ ${_('Добавить ключ', 'Add key')}</button></div><div id=kl>${keyRows(ck.links, 'cur', false)}</div>`) +
    (ck.links.length ? H.card('', `<button class=d onclick="keyClear()">🗑 ${_('Удалить все ключи', 'Remove all keys')}</button>`) : '');
}
async function pkApply(links, mode) {
  if (!K.sec) throw new Error(_('Не найдена секция', 'Section not found'));
  if (mode === 'url' && !links.length) throw new Error(_('Нужен хотя бы один ключ', 'At least one key is needed'));
  const lst = { url: 'proxy_string', selector: 'selector_proxy_links', urltest: 'urltest_proxy_links' }[mode];
  const v = { connection_type: 'proxy', proxy_config_type: mode };
  if (links.length) v[lst] = mode === 'url' ? links[0] : links;
  await U.set(K.pkg, K.sec, v);
  if (!links.length) await U.del(K.pkg, K.sec, [lst]).catch(() => { });
  if (mode !== 'url') await U.del(K.pkg, K.sec, ['proxy_string']).catch(() => { });
  await applyCfg(K.pkg); K.cfg = await U.get(K.pkg); CV[K.pkg] = K.cfg;
}
async function pkMode(m) { const ck = curKeys(); try { await pkApply(ck.links.map(l => l.raw).slice(0, m === 'url' ? 1 : 999), m); toast(_('Режим изменён, служба перезапускается', 'Mode changed, service is restarting')); } catch (e) { toast(e.message); } await pkShow(); }
async function keyAdd() {
  const v = await askText(_('Добавить ключ', 'Add key'), 'vless:// vmess:// trojan:// ss:// hy2:// ...', '');
  if (!v) return;
  const p = L.parseLink(v.trim()); if (!p) return toast(_('Не удалось разобрать ссылку', 'Cannot parse the link'));
  const ck = curKeys();
  try { await pkApply(ck.mode === 'url' ? [p.raw] : ck.links.map(l => l.raw).concat(p.raw), ck.mode); toast(_('Добавлено', 'Added')); } catch (e) { toast(e.message); }
  await pkShow();
}
async function keyClear() { if (await ask(_('Удалить все ключи?', 'Remove all keys?'), '', _('Удалить', 'Remove'), true)) { try { await pkApply([], curKeys().mode === 'url' ? 'selector' : curKeys().mode); } catch (e) { toast(e.message); } await pkShow(); } }
async function pingList(links, key, rerender) {
  K.ping[key] = {};
  const items = links.map((l, i) => ({ i, host: l.host, port: l.port }));
  for (let c = 0; c < items.length; c += 10) {
    const t = await out(L.pingCmd(items.slice(c, c + 10)));
    Object.assign(K.ping[key], L.parsePing(t)); rerender();
  }
}
async function pingCur() { toast(_('Проверяю…', 'Checking…')); try { await pingList(curKeys().links, 'cur', () => { const e = $('#kl'); if (e) e.innerHTML = keyRows(curKeys().links, 'cur', false); }); } catch (e) { toast(e.message); } }
// ---------- subscriptions ----------
function pkSubView() {
  const subs = subsLoad();
  if (K.open !== null && subs[K.open]) return subDetail(subs[K.open]);
  return H.card('', `<button class=p onclick="subAdd()">➕ ${_('Добавить ссылку-подписку от провайдера', 'Add a provider subscription link')}</button><div class=sub style="margin:8px 0 0">${_('Можно вставить ссылку https://… или сами ключи vless:// vmess:// trojan:// ss:// hy2://', 'Paste an https://… link or the keys themselves (vless:// vmess:// trojan:// ss:// hy2://)')}</div>`) +
    (subs.length ? H.card(_('Подписки', 'Subscriptions'), subs.map((s, i) => H.row(`🔗 ${esc(s.provider)}`, `${s.links.length} ${_('ключей', 'keys')}${s.info && s.info.total ? ' · ' + L.fmtB(s.info.used) + ' / ' + L.fmtB(s.info.total) : ''}`, '›', `subOpen(${i})`)).join('')) : `<div class=sub style="text-align:center;margin-top:20px">${_('Подписок пока нет. Вставьте ссылку от провайдера: приложение само расшифрует её и достанет ключи.', 'No subscriptions yet. Paste a provider link: the app decodes it and extracts the keys.')}</div>`);
}
function subDetail(s) {
  const i = K.open, inf = s.info || {}, exp = inf.expire ? new Date(inf.expire * 1000).toLocaleDateString() : '';
  return `<button class=s style="margin:0 0 10px" onclick="K.open=null;pkShow()">‹ ${_('Назад', 'Back')}</button>` +
    H.card(`🔗 ${esc(s.provider)}`, `<div class=sub style="margin:0 0 10px">${esc(inf.host || '')}${inf.total ? `<br>${_('Трафик', 'Traffic')}: ${L.fmtB(inf.used)} / ${L.fmtB(inf.total)}` : ''}${exp ? `<br>${_('Действует до', 'Valid until')}: ${exp}` : ''}${inf.web ? `<br>${esc(inf.web)}` : ''}</div><div class=grid>${s.url ? `<button onclick="subRefresh(${i})">🔄 ${_('Обновить', 'Refresh')}</button>` : ''}<button class=d onclick="subDel(${i})">🗑 ${_('Удалить', 'Delete')}</button></div>`) +
    H.card(`${_('Ключи', 'Keys')} · ${s.links.length}`, `<div class=grid style="margin-bottom:8px"><button class=p onclick="subPing(${i})">📡 ${_('Пинг всех', 'Ping all')}</button><button onclick="selAll(${s.links.length})">☑ ${_('Выбрать все', 'Select all')}</button></div><div id=kl>${keyRows(s.links, 'sub' + i, true)}</div>`) +
    H.card(_('Применить', 'Apply'), K.pkg ? `<div class=sub style="margin:0 0 8px">${_('Выбранные ключи заменят текущие. Режим «Авто» сам выбирает самый быстрый.', 'Selected keys replace the current ones. Auto mode picks the fastest.')}</div><div class=grid><button class=p onclick="subApply(${i},'urltest')">⚡ ${_('Авто', 'Auto')}</button><button onclick="subApply(${i},'selector')">🎛 ${_('Выбор', 'Selector')}</button></div>` + (K.pkg === 'netshift' && s.url ? `<button style="margin-top:8px" onclick="subNative(${i})">🔗 ${_('Передать ссылку NetShift (subscription_url)', 'Hand the link to NetShift (subscription_url)')}</button>` : '') : `<div class=sub style="margin:0">${_('Podkop не установлен.', 'Podkop is not installed.')}</div>`);
}
const subOpen = i => { K.open = i; K.sel = new Set(); pkShow(); };
const selKey = (i, on) => { if (on) K.sel.add(i); else K.sel.delete(i); };
const selAll = n => { K.sel = new Set(Array.from({ length: n }, (_x, i) => i)); pkShow(); };
const FMTERR = () => ({ empty: _('Ответ пустой.', 'Empty response.'), json: _('Формат sing-box JSON пока не поддерживается. Нужна ссылка формата v2ray (base64).', 'sing-box JSON is not supported yet. A v2ray (base64) link is required.'), clash: _('Формат Clash пока не поддерживается. Нужна ссылка формата v2ray (base64).', 'Clash format is not supported yet. A v2ray (base64) link is required.'), unknown: _('В ответе не найдено ключей.', 'No keys found in the response.') });
async function subFetch(url) {
  if (!/^https?:\/\/[^\s'"`\\]+$/.test(url)) throw new Error(_('Нужна ссылка http(s)', 'An http(s) link is required'));
  let err = '';
  // 1) from the phone (works even when the router cannot reach the provider)
  try {
    const r = await phoneGet(url, 'v2rayNG/1.8.5');
    if (r.status >= 400) err = 'HTTP ' + r.status;
    else { const d = L.decodeSub(r.body || ''); if (d.links.length) return { info: L.subInfo(r.headers || {}, url), links: d.links }; err = FMTERR()[d.fmt] || ''; }
  } catch (e) { err = e.message; }
  // 2) from the router as a fallback
  let rerr = '';
  try {
    const s = L.sections(await out(L.fetchCmd(url))), d = L.decodeSub(s.BODY || '');
    if (d.links.length) return { info: L.subInfo(L.parseHdr(s.HDR || ''), url), links: d.links };
    rerr = (s.HDR || '').trim().split('\n').slice(-2).join(' ').slice(0, 160) || FMTERR()[d.fmt] || '';
  } catch (e) { rerr = e.message; }
  throw new Error(`${_('Не удалось получить ключи.', 'Could not get the keys.')} ${_('Телефон', 'Phone')}: ${err || '—'}. ${_('Роутер', 'Router')}: ${rerr || '—'}`);
}
async function subAdd() {
  const v = await askText(_('Ссылка-подписка или ключи', 'Subscription link or keys'), _('Ссылка от провайдера (https://…) или сами ключи (vless://…)', 'Provider link (https://…) or the keys themselves (vless://…)'), '');
  if (v && v.trim()) await subIngest(v.trim());
}
async function subIngest(txt) {
  toast(_('Загружаю…', 'Fetching…'));
  try {
    let r, url = '';
    if (/^https?:\/\/\S+$/i.test(txt)) { url = txt; r = await subFetch(txt); }
    else { const d = L.decodeSub(txt); if (!d.links.length) throw new Error(FMTERR()[d.fmt] || FMTERR().unknown); r = { info: { provider: _('Вручную', 'Manual'), host: '', used: 0, total: 0, expire: 0, web: '' }, links: d.links }; }
    const subs = subsLoad(); subs.push({ url, provider: r.info.provider, info: r.info, links: r.links, ts: Date.now() }); subsSave();
    K.open = subs.length - 1; K.sel = new Set(); toast(`✅ ${r.info.provider}: ${r.links.length} ${_('ключей', 'keys')}`);
  } catch (e) { toast(e.message); }
  K.tab = 'sub'; if (page === 'pk') await pkShow();
}
async function subRefresh(i) { toast(_('Обновляю…', 'Refreshing…')); try { const s = subsLoad()[i], r = await subFetch(s.url); Object.assign(s, { provider: r.info.provider, info: r.info, links: r.links, ts: Date.now() }); subsSave(); K.ping['sub' + i] = {}; K.sel = new Set(); } catch (e) { toast(e.message); } await pkShow(); }
async function subDel(i) { if (await ask(_('Удалить подписку?', 'Delete subscription?'), '', _('Удалить', 'Delete'), true)) { subsLoad().splice(i, 1); subsSave(); K.open = null; await pkShow(); } }
async function subPing(i) { toast(_('Проверяю…', 'Checking…')); try { await pingList(subsLoad()[i].links, 'sub' + i, () => { const e = $('#kl'); if (e) e.innerHTML = keyRows(subsLoad()[i].links, 'sub' + i, true); }); } catch (e) { toast(e.message); } }
async function subApply(i, mode) {
  const s = subsLoad()[i], pick = s.links.filter((_l, j) => K.sel.has(j));
  if (!pick.length) return toast(_('Отметьте ключи галочками', 'Tick some keys first'));
  if (!await ask(_('Заменить ключи?', 'Replace keys?'), `${pick.length} ${_('ключей', 'keys')} · ${mode}`, _('Применить', 'Apply'))) return;
  try { await pkApply(pick.map(l => l.raw), mode); toast(_('Применено, служба перезапускается', 'Applied, the service is restarting')); } catch (e) { toast(e.message); }
}
async function subNative(i) { try { await U.set(K.pkg, K.sec, { subscription_url: [subsLoad()[i].url] }); await applyCfg(K.pkg); toast(_('Готово', 'Done')); } catch (e) { toast(e.message); } }
// ---------- updates ----------
const REL_NAMES = ['podkop', 'luci-app-podkop', 'luci-i18n-podkop-ru', 'netshift', 'luci-app-netshift', 'forkop', 'luci-app-forkop', 'sing-box', 'nlbwmon'];
async function pkUpdView() {
  K.inst = await installed();
  const rows = REL_NAMES.filter(n => n in K.inst).map(n => H.row(esc(n), '', `<span class=chip>${esc(K.inst[n])}</span>`)).join('');
  return H.card(_('Установлено', 'Installed'), rows || `<div class=sub>${_('Пакеты Podkop и sing-box не найдены.', 'Podkop and sing-box packages not found.')}</div>`) +
    H.card(_('Обновить', 'Update'), `<button class=p onclick="pkCheck()">🔍 ${_('Проверить обновления', 'Check for updates')}</button><div id=uc></div>
<div class=grid style="margin-top:10px"><button onclick="pkRelease('${K.pkg || 'podkop'}')">⬆ ${esc(K.pkg || 'Podkop')}</button><button onclick="pkSingbox()">⬆ sing-box</button></div>
<div class=sub style="margin:10px 0 0">${_('Проект обновляется из релиза на GitHub, sing-box из репозитория пакетов OpenWrt. Роутеру нужен интернет.', 'The project is updated from its GitHub release; sing-box from the OpenWrt package feed. The router needs internet access.')}</div>`);
}
async function pkCheck() {
  const c = L.pmCmd(await pm());
  if (await jobSheet(_('Обновление списков пакетов', 'Refreshing package lists'), c.upd) !== 0) return;
  closeSheet();
  const up = L.parseUpgradable(await out(c.up)).filter(x => /podkop|forkop|netshift|sing-box|nlbwmon/.test(x.name));
  const e = $('#uc');
  if (e) e.innerHTML = `<div class=sub style="margin:10px 0 0">${up.length ? up.map(x => `${esc(x.name)}: ${esc(x.from)} → ${esc(x.to)}`).join('<br>') : _('В репозитории пакетов обновлений нет.', 'No updates in the package feed.')}</div>`;
}
async function pkSingbox() {
  if (!await ask(_('Обновить sing-box?', 'Update sing-box?'), _('Версия берётся из репозитория OpenWrt. Служба будет перезапущена.', 'The version comes from the OpenWrt feed. The service will be restarted.'), _('Обновить', 'Update'))) return;
  const c = L.pmCmd(await pm()), p = K.pkg || 'podkop';
  await jobSheet('sing-box', `${c.upd}; ${c.upg('sing-box')}; [ -x /etc/init.d/${p} ] && /etc/init.d/${p} restart; true`);
}
async function pkRelease(id) {
  const e = catAll().find(x => x.id === id); if (!e) return;
  if (e.feed) { if (await ask(e.name, _('Установить из репозитория пакетов OpenWrt: ', 'Install from the OpenWrt package feed: ') + e.feed.join(', '), _('Установить', 'Install'))) { const c = L.pmCmd(await pm()); await jobSheet(e.name, `${c.upd}; ${c.inst(e.feed.join(' '))}`); } return; }
  toast(_('Загружаю данные релиза…', 'Fetching release info…'));
  let rel = null; try { rel = L.parseRelease(await out(L.ghCmd(e.repo))); } catch (er) { }
  if (!rel) return toast(_('Не удалось получить релиз с GitHub (нет интернета или лимит запросов).', 'Could not fetch the GitHub release (no internet or rate limit).'));
  const p = await pm(), ext = L.pmCmd(p).ext, arch = (await out('. /etc/openwrt_release 2>/dev/null; echo $DISTRIB_ARCH')).trim();
  const as = L.pickAssets(rel, ext, arch, e.pats), sw = e.fam && K.pkg && K.pkg !== e.fam && FAM[K.pkg];
  K.rel = { e, as, p };
  sheet(`<h3>${esc(e.name)} · ${esc(rel.tag_name)}</h3><div class=sub>${e.off ? '✅ ' + _('Официальный проект', 'Official project') : '⚠️ ' + _('Сообщество: репозиторий найден и имеет релизы, но код мной не проверялся. Устанавливайте только если доверяете автору.', 'Community: the repository exists and has releases, but I have not reviewed its code. Install only if you trust the author.')}<br>github.com/${esc(e.repo)}${rel.published_at ? '<br>' + esc(rel.published_at.slice(0, 10)) : ''}</div>` +
    (sw ? `<div class=sub>🔁 ${_(`Сейчас установлен ${K.pkg}. Он будет остановлен и удалён (несовместим), настройки сохранятся в копии /root/routerhub-backup и перенесутся в ${e.name}.`, `${K.pkg} is installed. It will be stopped and removed (incompatible); your settings are saved to /root/routerhub-backup and carried over to ${e.name}.`)}</div>` : '') +
    (p === 'apk' ? `<div class=sub>⚠️ ${_('Пакеты apk из релизов не подписаны ключом OpenWrt, установка идёт с флагом --allow-untrusted.', 'Release apk packages are not signed with an OpenWrt key; installing with --allow-untrusted.')}</div>` : '') +
    (as.length ? `<div class=assets>` + as.map((a, i) => `<label class=asr><input type=checkbox id=as${i} ${a.pre ? 'checked' : ''}><span>${esc(a.name)}<small>${L.fmtB(a.size)}${a.archOk ? '' : ' · ' + _('другая архитектура', 'other architecture')}${a.digest ? ' · ' + esc(a.digest.slice(0, 19)) + '…' : ''}</small></span></label>`).join('') + `</div><div class=g2><button onclick="closeSheet()">${_('Отмена', 'Cancel')}</button><button class=p onclick="pkInstall()">${sw ? _('Заменить', 'Replace') : _('Установить', 'Install')}</button></div>` : `<div class=sub>${_('В релизе нет пакетов ' + ext + ' для вашей системы. Для этого проекта, вероятно, нужна другая версия OpenWrt.', 'This release has no ' + ext + ' packages for your system. This project probably needs a different OpenWrt version.')}</div><button class=p onclick="closeSheet()">OK</button>`));
}
async function pkInstall() {
  const sel = K.rel.as.filter((_a, i) => { const c = $('#as' + i); return c && c.checked; });
  if (!sel.length) return toast(_('Отметьте пакеты', 'Tick some packages'));
  const e = K.rel.e, p = K.rel.p, sw = e.fam && K.pkg && K.pkg !== e.fam && FAM[K.pkg];
  closeSheet();
  let old = null;
  if (sw) {
    old = { pkg: K.pkg, cfg: JSON.parse(JSON.stringify(K.cfg)) };
    const inst = await installed(), c = L.pmCmd(p), names = FAM[old.pkg].filter(n => n in inst);
    await sh(`mkdir -p /root/routerhub-backup && cp /etc/config/${old.pkg} /root/routerhub-backup/${old.pkg}.$(date +%Y%m%d-%H%M%S) 2>/dev/null; true`);
    const rc = await jobSheet(_('Удаление ', 'Removing ') + old.pkg, `/etc/init.d/${old.pkg} stop >/dev/null 2>&1; ${names.length ? c.rm(names.join(' ')) : 'true'}`);
    if (rc !== 0) return toast(_('Не удалось удалить старый проект. Копия настроек: /root/routerhub-backup', 'Could not remove the old project. Settings backup: /root/routerhub-backup'));
    closeSheet();
  }
  const code = await jobSheet(_('Установка', 'Installing'), L.installCmd(p, sel));
  if (code === 0 && old) { try { await pkMigrate(old, e.fam); } catch (er) { toast(er.message); } }
  K.inst = {};
}
async function pkMigrate(old, to) {
  const dst = await U.get(to).catch(() => ({})), m = L.mergeCfg(old.cfg, dst); let n = 0;
  for (const a of m.adds) { await U.add(to, a.type, a.name || undefined, a.values); n++; }
  for (const s of m.sets) { await U.set(to, s.sec, s.values); n++; }
  if (n) await applyCfg(to);
  toast(_(`Настройки перенесены (${n})`, `Settings carried over (${n})`));
}
// ---------- library ----------
async function pkLibView() {
  const inst = await installed();
  const cards = catAll().map(e => {
    const have = Object.keys(inst).filter(n => (e.feed || []).includes(n) || (e.fam && FAM[e.fam].includes(n)) || (!e.fam && !e.feed && e.pats[0] !== '.' && e.pats.some(p => new RegExp(p, 'i').test(n)) && /podkop|forkop|netshift|sing-box/i.test(n)));
    return H.card('', `<div class=lh><b>${esc(e.name)}</b><span class="chip ${e.off ? 'ok' : 'warn'}">${e.off ? _('Официальный', 'Official') : _('Сообщество', 'Community')}</span></div><div class=sub style="margin:6px 0">${_(e.d[0], e.d[1])}</div><div class=sub style="margin:0 0 8px">github.com/${esc(e.repo)}${have.length ? '<br>✔ ' + have.map(n => esc(n + ' ' + inst[n])).join(', ') : ''}</div><button class=p onclick="pkRelease('${e.id}')">${e.fam && K.pkg && K.pkg !== e.fam ? _('Заменить текущий', 'Replace current') : _('Релиз и установка', 'Release & install')}</button>`);
  }).join('');
  return H.card('', `<div class=sub style="margin:0">${_('Проекты вокруг Podkop. Пакеты скачиваются из релизов GitHub прямо на роутер. «Сообщество» означает, что проект найден и у него есть релизы, но код мной не проверялся. Podkop, NetShift и Forkop несовместимы между собой: при замене старый удаляется, а настройки переносятся.', 'Projects around Podkop. Packages are downloaded from GitHub releases directly onto the router. "Community" means the project exists and has releases, but I have not reviewed its code. Podkop, NetShift and Forkop are mutually incompatible: replacing removes the old one and carries settings over.')}</div>`) + cards +
    H.card(_('Найти проекты на GitHub', 'Find projects on GitHub'), `<div style="display:flex;gap:8px"><input type=text id=gq value="${esc(K.gq)}" style="margin:0" autocapitalize=off onkeydown="if(event.key==='Enter')catSearch()"><button class="s p" style="margin:0" onclick="catSearch()">🔎</button></div><div id=gr>${K.found.length ? foundHtml() : ''}</div>`) +
    H.card('', `<button onclick="catAdd()">➕ ${_('Добавить репозиторий вручную', 'Add a repository manually')}</button>`);
}
const foundHtml = () => K.found.map((r, i) => H.row(esc(r.repo), `⭐ ${r.stars} · ${esc(r.pushed)}${r.fork ? ' · fork' : ''}${r.archived ? ' · ' + _('архив', 'archived') : ''}<br>${esc(r.desc.slice(0, 120))}`, `<button class="s p" onclick="catPick(${i})">➕</button>`)).join('');
async function catSearch() {
  const q = $('#gq').value.trim(); K.gq = q;
  if (q.length < 2 || q.length > 80) return toast(_('Введите запрос', 'Enter a query'));
  toast(_('Ищу…', 'Searching…'));
  try { const r = await phoneGet('https://api.github.com/search/repositories?per_page=20&sort=stars&q=' + encodeURIComponent(q), 'routerhub'); K.found = L.parseGhSearch(r.body || ''); }
  catch (e) { return toast(e.message); }
  const el = $('#gr'); if (el) el.innerHTML = K.found.length ? foundHtml() : `<div class=sub style="margin:8px 0 0">${_('Ничего не найдено', 'Nothing found')}</div>`;
}
async function catPick(i) { const r = K.found[i]; if (!r) return; const x = LS.get('catx', []); if (!x.includes(r.repo)) x.push(r.repo); LS.set('catx', x); toast(_('Добавлено в библиотеку', 'Added to the library')); await pkShow(); }
async function catAdd() {
  const v = await askText(_('Репозиторий GitHub', 'GitHub repository'), 'owner/repo', ''); if (!v) return;
  if (!L.okRepo(v.trim())) return toast(_('Формат: владелец/репозиторий', 'Format: owner/repository'));
  const x = LS.get('catx', []); if (!x.includes(v.trim())) x.push(v.trim()); LS.set('catx', x); await pkShow();
}
