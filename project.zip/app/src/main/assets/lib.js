(function (g) {
'use strict';
const L = {};
L.shq = s => "'" + String(s).replace(/'/g, "'\\''") + "'";
const sd = s => { try { return decodeURIComponent(s); } catch (e) { return s; } };
L.sd = sd;
L.b64d = s => {
  s = String(s).replace(/\s/g, '').replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  const b = atob(s);
  return new TextDecoder().decode(Uint8Array.from(b, c => c.charCodeAt(0)));
};
const hp = s => {
  s = s.trim();
  if (s[0] === '[') { const e = s.indexOf(']'); return [s.slice(1, e), parseInt(s.slice(e + 2), 10) || 0]; }
  const i = s.lastIndexOf(':');
  return i < 0 ? [s, 0] : [s.slice(0, i), parseInt(s.slice(i + 1), 10) || 0];
};
const PROTO = 'vless|vmess|trojan|ss|hysteria2|hy2|tuic|hysteria|anytls|socks';
L.parseLink = u => {
  u = String(u).trim();
  const m = u.match(/^([a-z0-9]+):\/\//i);
  if (!m) return null;
  const proto = m[1].toLowerCase();
  if (!new RegExp('^(' + PROTO + ')$').test(proto)) return null;
  let body = u.slice(m[0].length), name = '';
  const h = body.indexOf('#');
  if (h >= 0) { name = sd(body.slice(h + 1)); body = body.slice(0, h); }
  try {
    if (proto === 'vmess') {
      const j = JSON.parse(L.b64d(body));
      return { proto, name: j.ps || name || j.add, host: String(j.add || ''), port: parseInt(j.port, 10) || 0, raw: u, params: { net: j.net || '', tls: j.tls || '' } };
    }
    const q = body.indexOf('?');
    const main = q >= 0 ? body.slice(0, q) : body;
    const qs = q >= 0 ? body.slice(q + 1) : '';
    if (proto === 'ss') {
      let host, port;
      if (main.includes('@')) { [host, port] = hp(main.slice(main.lastIndexOf('@') + 1).replace(/\/.*$/, '')); }
      else { const d = L.b64d(main.replace(/\/$/, '')); [host, port] = hp(d.slice(d.lastIndexOf('@') + 1)); }
      return { proto, name: name || host, host, port, raw: u, params: {} };
    }
    const at = main.lastIndexOf('@');
    const [host, port] = hp((at >= 0 ? main.slice(at + 1) : main).replace(/\/.*$/, ''));
    const params = {};
    qs.split('&').forEach(p => { if (p) { const i = p.indexOf('='); params[sd(p.slice(0, i < 0 ? p.length : i))] = i < 0 ? '' : sd(p.slice(i + 1)); } });
    if (!host) return null;
    return { proto, name: name || host, host, port, raw: u, params };
  } catch (e) { return null; }
};
L.decodeSub = t => {
  t = String(t).replace(/^\uFEFF/, '').trim();
  if (!t) return { links: [], fmt: 'empty' };
  const has = x => new RegExp('(^|\\s)(' + PROTO + ')://', 'i').test(x);
  let body = t, fmt = 'plain';
  if (!has(t)) { try { const d = L.b64d(t); if (has(d)) { body = d; fmt = 'base64'; } } catch (e) { } }
  if (!has(body)) {
    if (/^\s*[\[{]/.test(t)) return { links: [], fmt: 'json' };
    if (/^\s*(proxies|port|mixed-port)\s*:/m.test(t)) return { links: [], fmt: 'clash' };
    return { links: [], fmt: 'unknown' };
  }
  const seen = new Set(), links = [];
  (body.match(new RegExp('(?:' + PROTO + ')://[^\\s<>"\']+', 'gi')) || []).forEach(x => {
    if (seen.has(x)) return; seen.add(x);
    const p = L.parseLink(x); if (p) links.push(p);
  });
  return { links, fmt };
};
L.parseHdr = t => {
  const h = {};
  String(t).split(/\r?\n/).forEach(l => { const m = l.match(/^\s*([A-Za-z][\w-]*)\s*:\s*(.*?)\s*$/); if (m) h[m[1].toLowerCase()] = m[2]; });
  return h;
};
L.subInfo = (h, url) => {
  let title = sd(h['profile-title'] || '');
  if (/^base64:/i.test(title)) { try { title = L.b64d(title.slice(7)); } catch (e) { } }
  if (!title) { const m = (h['content-disposition'] || '').match(/filename\*?=(?:UTF-8'')?"?([^";]+)/i); if (m) title = sd(m[1]); }
  const u = {};
  (h['subscription-userinfo'] || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) u[p.slice(0, i).trim()] = +p.slice(i + 1); });
  let host = ''; try { host = new URL(url).hostname; } catch (e) { }
  return { title, provider: title || host, host, used: (u.upload || 0) + (u.download || 0), total: u.total || 0, expire: u.expire || 0, web: h['profile-web-page-url'] || h['support-url'] || '', interval: h['profile-update-interval'] || '' };
};
L.fetchCmd = (url, ua) => {
  const q = L.shq(url), a = L.shq(ua || 'v2rayNG/1.8.5');
  return 'rm -f /tmp/rh.hdr /tmp/rh.body; if command -v curl >/dev/null 2>&1; then curl -sSL -m 18 -A ' + a + ' -D /tmp/rh.hdr -o /tmp/rh.body ' + q + ' 2>&1; else wget -T 18 -U ' + a + ' -O /tmp/rh.body ' + q + ' 2>/tmp/rh.hdr; fi; echo "##HDR"; cat /tmp/rh.hdr 2>/dev/null; echo "##BODY"; cat /tmp/rh.body 2>/dev/null';
};
L.sections = t => {
  const o = {}; let k = '_';
  String(t).split('\n').forEach(l => { const m = l.match(/^##(\w+)\s*$/); if (m) { k = m[1]; o[k] = ''; } else o[k] = (o[k] || '') + l + '\n'; });
  return o;
};
// ---------- icons ----------
L.ICONS = { phone: '📱', tablet: '📲', laptop: '💻', desktop: '🖥️', tv: '📺', console: '🎮', printer: '🖨️', camera: '📷', speaker: '🔊', watch: '⌚', smart: '💡', router: '🛜', server: '🗄️', car: '🚗', unknown: '❓' };
L.ICON_NAMES = { phone: ['Телефон', 'Phone'], tablet: ['Планшет', 'Tablet'], laptop: ['Ноутбук', 'Laptop'], desktop: ['Компьютер', 'Computer'], tv: ['Телевизор', 'TV'], console: ['Консоль', 'Console'], printer: ['Принтер', 'Printer'], camera: ['Камера', 'Camera'], speaker: ['Колонка', 'Speaker'], watch: ['Часы', 'Watch'], smart: ['Умный дом', 'Smart home'], router: ['Роутер', 'Router'], server: ['Сервер / NAS', 'Server / NAS'], car: ['Авто', 'Car'], unknown: ['Другое', 'Other'] };
const IR = [
  ['tablet', /(ipad|mediapad|galaxy[-_ ]?tab|\btab\b|-tab|lenovo[-_ ]?tb|tablet|kindle|fire[-_ ]?hd)/i],
  ['watch', /(watch|mi[-_ ]?band|smartband|amazfit|fitbit|garmin)/i],
  ['phone', /(iphone|android|galaxy|pixel|redmi|xiaomi|poco|huawei|honor|oneplus|oppo|realme|vivo|infinix|tecno|nokia|motorola|moto[-_ ]|sm-[a-z]\d|phone|^lmr-|mobile)/i],
  ['laptop', /(macbook|laptop|notebook|thinkpad|ideapad|zenbook|vivobook|latitude|inspiron|probook|elitebook|surface|xps|\bmbp\b|\bmba\b)/i],
  ['console', /(playstation|\bps[345]\b|xbox|nintendo|switch|steamdeck|steam-deck)/i],
  ['tv', /(\btv\b|-tv|_tv|smarttv|bravia|webos|tizen|roku|firetv|chromecast|appletv|apple-tv|android-tv|shield|lg-?tv|samsung-?tv|mi-?box|kion|yandex-?tv|\bstb\b)/i],
  ['printer', /(printer|epson|canon|brother|laserjet|deskjet|officejet|xerox|kyocera|mfp)/i],
  ['camera', /(cam\b|camera|ipc|hikvision|dahua|reolink|ezviz|imou|wyze|eufy|doorbell)/i],
  ['speaker', /(echo|alexa|homepod|sonos|speaker|yandex[-_ ]?(station|mini)|googlehome|google-home|nest-?(mini|audio)|marshall)/i],
  ['smart', /(esp[-_ ]?\d*|tasmota|shelly|sonoff|bulb|yeelight|tuya|zigbee|hass|homeassistant|lamp|plug|switch-?bot|robot|roborock|vacuum|aqara|xiaomi-?(vacuum|mi-?home))/i],
  ['server', /(nas|synology|qnap|server|raspberry|rpi|raspi|proxmox|docker|plex|unraid|truenas|odroid|orangepi)/i],
  ['router', /(router|openwrt|\bdir-?\d|archer|keenetic|cudy|mikrotik|ubnt|unifi|tp-?link|ap-|access-?point|repeater|extender|mesh)/i],
  ['desktop', /(desktop|dekstop|(^|[-_ .])pc($|[-_ .])|^pc|workstation|gaming|imac|\bmini\b)/i],
  ['car', /(\bcar\b|tesla|vehicle|carplay|android-?auto)/i]
];
L.randMac = mac => ((parseInt(String(mac).slice(1, 2), 16) || 0) & 2) !== 0;
L.guessIcon = (name, mac) => {
  const n = String(name || '');
  for (const [k, re] of IR) if (re.test(n)) return k;
  if (L.randMac(mac)) return 'phone';
  return 'unknown';
};
// ---------- devices ----------
L.parseNeigh = t => String(t).split('\n').map(l => {
  const p = l.trim().split(/\s+/); const i = p.indexOf('lladdr');
  if (i < 0 || !/^\d+\.\d+\.\d+\.\d+$/.test(p[0]) || !/^[0-9a-f:]{17}$/i.test(p[i + 1] || '')) return null;
  return { ip: p[0], mac: p[i + 1].toLowerCase(), state: p[p.length - 1] };
}).filter(Boolean);
L.parseLeases = t => String(t).split('\n').map(l => l.trim().split(/\s+/)).filter(p => p.length >= 4 && /^[0-9a-f:]{17}$/i.test(p[1]))
  .map(p => ({ exp: +p[0], mac: p[1].toLowerCase(), ip: p[2], name: p[3] === '*' ? '' : p[3] }));
L.parseWifi = t => String(t).split('\n').map(l => l.trim().split(/\s+/)).filter(p => p.length >= 3 && /^[0-9a-f:]{17}$/i.test(p[1]))
  .map(p => ({ iface: p[0], mac: p[1].toLowerCase(), signal: p[2] }));
L.m12 = m => String(m).replace(/:/g, '').toLowerCase();
L.m17 = s => s.match(/.{2}/g).join(':');
L.isMac = s => /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/i.test(s);
L.isIP = s => /^(\d{1,3}\.){3}\d{1,3}$/.test(s) && s.split('.').every(x => +x <= 255);
L.isPort = s => /^\d+$/.test(String(s)) && +s >= 1 && +s <= 65535;
L.devices = o => {
  const M = {}, reg = o.reg || {};
  const get = m => M[m] || (M[m] = { mac: m, ip: '', host: '', online: false, wifi: null, state: '' });
  Object.keys(reg).forEach(m => { const d = get(m); d.ip = reg[m].ip || ''; d.host = reg[m].host || ''; d.seen = reg[m].seen || 0; });
  (o.leases || []).forEach(x => { const d = get(x.mac); d.ip = x.ip; if (x.name) d.host = x.name; });
  (o.neigh || []).forEach(x => { const d = get(x.mac); d.ip = x.ip; d.state = x.state; });
  const up = new Set(o.up || []);
  (o.neigh || []).forEach(x => { if (['REACHABLE', 'DELAY', 'PROBE', 'PERMANENT'].includes(x.state) || (x.state === 'STALE' && up.has(x.ip))) M[x.mac].online = true; });
  (o.wifi || []).forEach(x => { const d = get(x.mac); d.online = true; d.wifi = { iface: x.iface, signal: x.signal }; });
  const st = o.statics || {};
  Object.keys(st).forEach(m => { const d = get(m); d.static = st[m]; if (!d.host && st[m].name) d.host = st[m].name; if (!d.ip) d.ip = st[m].ip || ''; });
  Object.keys(o.blocks || {}).forEach(m => { get(m).blocked = true; });
  Object.keys(o.pcs || {}).forEach(m => { get(m).pc = o.pcs[m]; });
  const key = s => String(s.ip || '0.0.0.0').split('.').map(x => ('000' + x).slice(-3)).join('');
  const apm = o.ap || {};
  return Object.values(M).map(d => {
    const r = reg[d.mac] || {};
    d.name = r.n || d.host || ''; d.icon = r.i || L.guessIcon(d.name, d.mac); d.fav = !!r.fav;
    const a = apm[d.mac];
    if (r.c) { d.conn = r.c; d.via = r.via || (a ? a.name : ''); d.manualConn = true; if (r.c === 'ap' && a && !d.wifi) d.wifi = { iface: a.iface, signal: a.signal }; }
    else if (d.wifi) d.conn = 'wifi';
    else if (a) { d.conn = 'ap'; d.via = a.name; d.wifi = { iface: a.iface, signal: a.signal }; d.online = true; }
    else if (['phone', 'tablet', 'watch'].includes(d.icon)) d.conn = 'apguess';
    else d.conn = 'lan';
    return d;
  }).sort((a, b) => (b.online - a.online) || key(a).localeCompare(key(b)));
};
// ---------- firewall rules (block / parental control) ----------
L.DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
L.blockRule = mac => ({ name: 'rh_block_' + L.m12(mac), src: 'lan', dest: 'wan', src_mac: mac, target: 'REJECT' });
L.pcRules = (mac, from, to, days) => {
  const b = { src: 'lan', dest: 'wan', src_mac: mac, target: 'REJECT' }, n = 'rh_pc_' + L.m12(mac);
  const wd = d => (d.length && d.length < 7 ? { weekdays: d } : {});
  const t = x => (x.length === 5 ? x + ':00' : x);
  if (from < to) return [Object.assign({ name: n + '_s', start_time: t(from), stop_time: t(to) }, b, wd(days))];
  const next = days.map(d => L.DAYS[(L.DAYS.indexOf(d) + 1) % 7]);
  return [Object.assign({ name: n + '_a', start_time: t(from), stop_time: '23:59:59' }, b, wd(days)),
    Object.assign({ name: n + '_b', start_time: '00:00:00', stop_time: t(to) }, b, wd(next))];
};
const normDay = d => d[0].toUpperCase() + d.slice(1, 3).toLowerCase();
const dayList = w => { const a = (Array.isArray(w) ? w : String(w || '').split(/\s+/)).filter(Boolean).map(normDay); return a.length ? a : L.DAYS.slice(); };
L.parseRules = v => {
  const blocks = {}, pcs = {};
  Object.keys(v || {}).forEach(k => {
    const s = v[k]; if (s['.type'] !== 'rule') return;
    const nm = s['.name'] || k; let m;
    if ((m = nm.match(/^rh_block_([0-9a-f]{12})$/))) blocks[L.m17(m[1])] = { sec: nm };
    else if ((m = nm.match(/^rh_pc_([0-9a-f]{12})_([sab])$/))) {
      const mac = L.m17(m[1]), p = pcs[mac] || (pcs[mac] = { secs: [], from: '', to: '', days: L.DAYS.slice() });
      p.secs.push(nm);
      if (m[2] === 's') { p.from = (s.start_time || '').slice(0, 5); p.to = (s.stop_time || '').slice(0, 5); p.days = dayList(s.weekdays); }
      if (m[2] === 'a') { p.from = (s.start_time || '').slice(0, 5); p.days = dayList(s.weekdays); }
      if (m[2] === 'b') p.to = (s.stop_time || '').slice(0, 5);
    }
  });
  return { blocks, pcs };
};
L.parseStatics = v => {
  const o = {};
  Object.keys(v || {}).forEach(k => {
    const s = v[k]; if (s['.type'] !== 'host') return;
    const mac = String(Array.isArray(s.mac) ? s.mac[0] : (s.mac || '')).split(/\s+/)[0].toLowerCase();
    if (L.isMac(mac)) o[mac] = { sec: s['.name'] || k, name: s.name || '', ip: s.ip || '' };
  });
  return o;
};
L.redirect = x => ({ name: x.name, src: 'wan', src_dport: String(x.ext), dest: 'lan', dest_ip: x.ip, dest_port: String(x.port), proto: x.proto, target: 'DNAT' });
// ---------- traffic ----------
L.CT_CMD = "awk '{s=\"\";n=0;u=0;d=0;for(i=1;i<=NF;i++){if(s==\"\"&&$i~/^src=/)s=substr($i,5);if($i~/^bytes=/){n++;if(n==1)u=substr($i,7);else if(n==2)d=substr($i,7)}}if(s!=\"\"&&n>=2){U[s]+=u;D[s]+=d}}END{for(k in U)print k,U[k],D[k]}' /proc/net/nf_conntrack 2>/dev/null";
L.parseCT = t => {
  const o = {};
  String(t).split('\n').forEach(l => { const p = l.trim().split(/\s+/); if (p.length === 3 && /^\d+\.\d+\.\d+\.\d+$/.test(p[0])) o[p[0]] = { up: +p[1] || 0, down: +p[2] || 0 }; });
  return o;
};
L.parseNlbw = t => {
  const o = {};
  String(t).split('\n').forEach(l => {
    const p = l.trim().split(/\s+/);
    if (p.length >= 6 && /^[0-9a-f:]{17}$/i.test(p[0])) o[p[0].toLowerCase()] = { conns: +p[1], rx: +p[2], tx: +p[4] };
  });
  return o;
};
L.parseNetDev = t => {
  const o = {};
  String(t).split('\n').forEach(l => { const m = l.match(/^\s*([^:\s]+):\s*(\d+)\s+(?:\d+\s+){7}(\d+)/); if (m) o[m[1]] = { rx: +m[2], tx: +m[3] }; });
  return o;
};
// ---------- formatting ----------
L.fmtB = n => { n = +n || 0; const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return (i ? n.toFixed(n >= 100 ? 0 : 1) : Math.round(n)) + ' ' + u[i]; };
L.fmtR = bps => { const b = (+bps || 0) * 8; if (b >= 1e6) return (b / 1e6).toFixed(b >= 1e8 ? 0 : 1) + ' Mb/s'; if (b >= 1e3) return Math.round(b / 1e3) + ' kb/s'; return Math.round(b) + ' b/s'; };
L.dur = s => { s = Math.floor(+s || 0); return { d: Math.floor(s / 86400), h: Math.floor(s % 86400 / 3600), m: Math.floor(s % 3600 / 60) }; };
L.loadInfo = (l, c) => { c = c || 1; const pct = Math.round(l / c * 100); return { pct, lv: pct < 60 ? 'low' : pct < 100 ? 'mid' : 'high' }; };
// ---------- ping keys ----------
const okHost = h => /^[A-Za-z0-9._:-]+$/.test(h) && h.length < 254;
L.pingCmd = items => {
  const ok = items.filter(x => okHost(String(x.host)) && L.isPort(x.port));
  if (!ok.length) return 'true';
  return ok.map(x => {
    const ic = x.host.includes(':') ? "r=''" : "r=$(ping -c1 -W2 " + x.host + " 2>/dev/null | sed -n 's/.*time=\\([0-9.]*\\).*/\\1/p')";
    return '( ' + ic + '; nc -w 2 ' + x.host + ' ' + x.port + ' </dev/null >/dev/null 2>&1 && echo "' + x.i + ' up $r" || echo "' + x.i + ' down" ) &';
  }).join('\n') + '\nwait';
};
L.parsePing = t => {
  const o = {};
  String(t).split('\n').forEach(l => { const m = l.trim().match(/^(\d+) (up|down)\s*([\d.]*)/); if (m) o[m[1]] = { ok: m[2] === 'up', ms: m[3] ? parseFloat(m[3]) : null }; });
  return o;
};
// ---------- packages ----------
L.okPkg = p => /^[a-z0-9][a-z0-9._+-]*$/i.test(p);
L.PMH = 'W() { n=0; while [ $n -lt ${1:-60} ] && pidof apk opkg >/dev/null 2>&1; do [ $n -eq 0 ] && echo "waiting for another package operation..."; sleep 2; n=$((n+1)); done; }\nT() { if command -v timeout >/dev/null 2>&1; then timeout ${RHT:-180} "$@"; else "$@"; fi; }\n';
L.pmCmd = pm => pm === 'apk'
  ? { list: "o=$(awk '/^P:/{p=substr($0,3)} /^V:/{print p\" - \"substr($0,3)}' /lib/apk/db/installed 2>/dev/null); if [ -n \"$o\" ]; then echo \"$o\"; else apk list -I 2>/dev/null; fi", upd: 'W; T apk update', inst: p => 'W; apk add ' + p, rm: p => 'W; apk del ' + p, up: L.PMH + 'W 5; apk list --upgradable 2>/dev/null || apk list -u 2>/dev/null', upg: p => 'W; apk add -u ' + p, ext: '.apk' }
  : { list: "o=$(awk '/^Package:/{p=$2} /^Version:/{print p\" - \"$2}' /usr/lib/opkg/status 2>/dev/null); if [ -n \"$o\" ]; then echo \"$o\"; else opkg list-installed 2>/dev/null; fi", upd: 'W; T opkg update', inst: p => 'W; opkg install ' + p, rm: p => 'W; opkg remove ' + p, up: L.PMH + 'W 5; opkg list-upgradable 2>/dev/null', upg: p => 'W; opkg upgrade ' + p, ext: '.ipk' };
L.parseInstalled = t => {
  const o = {};
  String(t).split('\n').forEach(l => {
    let m = l.match(/^(\S+) - (\S+)/);
    if (m) { o[m[1]] = m[2]; return; }
    m = l.match(/^(.+?)-(\d[\w.+~]*(?:-r\d+)?)\s+\S+\s+\{/);
    if (m) o[m[1]] = m[2];
  });
  return o;
};
L.parseUpgradable = t => {
  const r = [];
  String(t).split('\n').forEach(l => {
    let m = l.match(/^(\S+) - (\S+) - (\S+)/);
    if (m) { r.push({ name: m[1], from: m[2], to: m[3] }); return; }
    m = l.match(/^(.+?)-(\d[\w.+~]*(?:-r\d+)?)\s+\S+\s+\{.*\[upgradable from: .+?-(\d[\w.+~]*(?:-r\d+)?)\]/);
    if (m) r.push({ name: m[1], from: m[3], to: m[2] });
  });
  return r;
};
L.ghCmd = repo => 'u=https://api.github.com/repos/' + repo + '/releases/latest; (curl -sL -m 9 -A routerhub "$u" 2>/dev/null || wget -qO- -T 9 -U routerhub "$u" 2>/dev/null)';
L.okRepo = r => /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(r);
L.parseRelease = t => { try { const j = JSON.parse(t); return j && j.tag_name ? j : null; } catch (e) { return null; } };
L.pickAssets = (rel, ext, arch, pats) => {
  const res = [];
  (rel.assets || []).forEach(a => {
    if (!a.name.endsWith(ext)) return;
    const archTok = /(aarch64|arm_|mips|x86_64|i386|riscv|powerpc|loongarch)/i.test(a.name);
    const archOk = !archTok || (arch && a.name.includes(arch));
    const pre = (pats || []).some(p => new RegExp(p, 'i').test(a.name));
    res.push({ name: a.name, url: a.browser_download_url, size: a.size || 0, digest: a.digest || '', archOk, pre: pre && archOk });
  });
  return res.sort((x, y) => (/^luci-/.test(x.name) - /^luci-/.test(y.name)) || x.name.localeCompare(y.name));
};
L.installCmd = (pm, files) => {
  const get = files.map(f => 'wget -O ' + L.shq('/tmp/rh/' + f.name) + ' ' + L.shq(f.url)).join(' && ');
  const c = L.pmCmd(pm);
  const inst = pm === 'apk'
    ? 'apk add --allow-untrusted ' + files.map(f => L.shq('/tmp/rh/' + f.name)).join(' ')
    : files.map(f => 'opkg install ' + L.shq('/tmp/rh/' + f.name)).join(' && ');
  return 'rm -rf /tmp/rh && mkdir -p /tmp/rh && ' + get + ' && ' + c.upd + '; ' + inst + ' ; R=$?; rm -rf /tmp/rh; exit $R';
};
// ---------- services ----------
L.parseServices = t => String(t).split('\n').map(l => l.split('|')).filter(p => p.length === 3 && /^[\w.-]+$/.test(p[0]))
  .map(p => ({ name: p[0], en: p[1] === '1', run: p[2] === '1' }));
L.SVC = {
  dnsmasq: ['DNS и DHCP', 'DNS & DHCP', '🌐'], odhcpd: ['DHCPv6', 'DHCPv6', '🧭'], dropbear: ['SSH-сервер', 'SSH server', '🔐'], firewall: ['Межсетевой экран', 'Firewall', '🛡️'],
  network: ['Сеть', 'Network', '🔌'], uhttpd: ['Веб-интерфейс LuCI', 'LuCI web server', '🖥️'], sysntpd: ['Синхронизация времени', 'Time sync', '🕒'], cron: ['Планировщик задач', 'Task scheduler', '⏱️'],
  log: ['Системный журнал', 'System log', '📜'], rpcd: ['API для приложений', 'App API (rpcd)', '🧩'], podkop: ['Подкоп (маршрутизация)', 'Podkop (routing)', '🛰️'], forkop: ['Forkop (маршрутизация)', 'Forkop (routing)', '🛰️'],
  'sing-box': ['sing-box (прокси)', 'sing-box (proxy)', '📦'], nlbwmon: ['Учёт трафика', 'Traffic accounting', '📊'], miniupnpd: ['UPnP', 'UPnP', '🔓'], sqm: ['Управление очередями (SQM)', 'Smart queues (SQM)', '⚡'],
  adblock: ['Блокировка рекламы', 'Ad blocking', '🚫'], 'adblock-fast': ['Блокировка рекламы', 'Ad blocking', '🚫'], dnsmasq_dhcp: ['DHCP', 'DHCP', '🧭'], wpad: ['Wi-Fi безопасность', 'Wi-Fi security', '📶'], ddns: ['Динамический DNS', 'Dynamic DNS', '🏷️'],
  banip: ['Блокировка IP', 'IP blocking', '⛔'], 'https-dns-proxy': ['DNS через HTTPS', 'DNS over HTTPS', '🔒'], collectd: ['Статистика', 'Statistics', '📈'], samba4: ['Сетевые папки', 'File sharing', '📁'], wireguard: ['WireGuard', 'WireGuard', '🕳️']
};

// ---------- package search / GitHub search / config merge / misc ----------
L.searchCmd = (pm, q) => L.PMH + 'W 5; ' + (pm === 'apk' ? 'apk search -v ' + L.shq(q) + ' 2>/dev/null | head -40' : 'opkg list 2>/dev/null | grep -i -- ' + L.shq(q) + ' | head -40');
L.parseSearch = (t, pm) => {
  const r = [];
  String(t).split('\n').forEach(l => {
    let m;
    if (pm === 'apk') { m = l.match(/^(.+?)-(\d[\w.+~]*(?:-r\d+)?)\s*(?:-\s*(.*))?$/); if (m) r.push({ name: m[1], ver: m[2], desc: (m[3] || '').trim() }); }
    else { m = l.match(/^(\S+) - (\S+)(?: - (.*))?$/); if (m) r.push({ name: m[1], ver: m[2], desc: m[3] || '' }); }
  });
  return r.filter(x => L.okPkg(x.name));
};
L.parseGhSearch = t => { try { const j = JSON.parse(t); return (j.items || []).map(x => ({ repo: x.full_name, desc: x.description || '', stars: x.stargazers_count || 0, pushed: (x.pushed_at || '').slice(0, 10), fork: !!x.fork, archived: !!x.archived })).filter(x => L.okRepo(x.repo)); } catch (e) { return []; } };
L.mergeCfg = (src, dst) => {
  const adds = [], sets = [];
  Object.keys(src || {}).forEach(k => {
    const s = src[k]; if (!s || !s['.type']) return;
    const vals = {}; Object.keys(s).forEach(o => { if (o[0] !== '.') vals[o] = s[o]; });
    const name = s['.anonymous'] ? null : (s['.name'] || k);
    if (!name) { if (!Object.values(dst || {}).some(d => d['.type'] === s['.type'])) adds.push({ type: s['.type'], name: null, values: vals }); return; }
    const d = (dst || {})[name];
    if (!d) { adds.push({ type: s['.type'], name, values: vals }); return; }
    const miss = {}; Object.keys(vals).forEach(o => { if (!(o in d)) miss[o] = vals[o]; });
    if (Object.keys(miss).length) sets.push({ sec: name, values: miss });
  });
  return { adds, sets };
};
L.parseIfaces = t => { try { return (JSON.parse(t).interface || []).filter(i => i.interface !== 'loopback').map(i => ({ name: i.interface, up: !!i.up, proto: i.proto || '', dev: i.l3_device || i.device || '', ip: ((i['ipv4-address'] || [])[0] || {}).address || '', mask: ((i['ipv4-address'] || [])[0] || {}).mask || '', dns: i['dns-server'] || [], uptime: i.uptime || 0 })); } catch (e) { return []; } };
L.parsePs = t => String(t).split('\n').map(l => l.match(/^\s*(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.*)$/)).filter(Boolean).map(m => ({ pid: +m[1], user: m[2], vsz: m[3], stat: m[4], cmd: m[5].trim() }));
L.COMMUNITY = [['russia_inside', 'Россия: внутри', 'Russia: inside'], ['russia_outside', 'Россия: снаружи', 'Russia: outside'], ['ukraine_inside', 'Украина: внутри', 'Ukraine: inside'], ['geoblock', 'Геоблокировки', 'Geoblocking'], ['block', 'Блокировка', 'Block list'], ['porn', '18+', 'Adult'], ['news', 'Новости', 'News'], ['anime', 'Аниме', 'Anime'], ['youtube', 'YouTube', 'YouTube'], ['hdrezka', 'HDRezka', 'HDRezka'], ['tiktok', 'TikTok', 'TikTok'], ['google_ai', 'Google AI', 'Google AI'], ['google_play', 'Google Play', 'Google Play'], ['hodca', 'HODCA (хостинги)', 'HODCA (hosting)'], ['discord', 'Discord', 'Discord'], ['meta', 'Meta', 'Meta'], ['twitter', 'Twitter / X', 'Twitter / X'], ['cloudflare', 'Cloudflare', 'Cloudflare'], ['cloudfront', 'CloudFront', 'CloudFront'], ['digitalocean', 'DigitalOcean', 'DigitalOcean'], ['hetzner', 'Hetzner', 'Hetzner'], ['ovh', 'OVH', 'OVH'], ['telegram', 'Telegram', 'Telegram'], ['roblox', 'Roblox', 'Roblox']];
L.REGIONAL = ['russia_inside', 'russia_outside', 'ukraine_inside', 'geoblock'];
L.okName = s => /^[A-Za-z][A-Za-z0-9_]{0,40}$/.test(s);

// ---------- provider keys: marking, composing ----------
L.b64e = s => btoa(String.fromCharCode.apply(null, Array.from(new TextEncoder().encode(String(s)))));
L.labelOf = t => String(t || '').replace(/[^\w.\- \u0400-\u04FF]/g, '').trim().replace(/\s+/g, '_').slice(0, 24) || 'Provider';
L.keyId = l => [l.proto, l.host, l.port, l.name].join('|');
L.markLink = (raw, label, name) => {
  const p = L.parseLink(raw); if (!p) return raw;
  const tag = '[' + label + '] ' + String(name || p.name).replace(/[\r\n\t]/g, ' ').slice(0, 60);
  if (p.proto === 'vmess') { try { const j = JSON.parse(L.b64d(raw.slice(8).split('#')[0])); j.ps = tag; return 'vmess://' + L.b64e(JSON.stringify(j)); } catch (e) { return raw; } }
  const i = raw.indexOf('#'), b = i >= 0 ? raw.slice(0, i) : raw;
  return b + '#' + encodeURIComponent(tag);
};
L.composeKeys = (cfgLinks, subs, dead) => {
  const known = new Set((dead || []).slice());
  (subs || []).forEach(s => { (s.hist || []).forEach(m => known.add(m)); (s.links || []).forEach(l => known.add(l.mark)); });
  const foreign = (cfgLinks || []).filter(x => !known.has(x)), on = [];
  (subs || []).forEach(s => (s.links || []).forEach(l => { if (l.on !== false) on.push(l.mark); }));
  return { foreign, on, links: foreign.concat(on.filter(m => !foreign.includes(m))) };
};

// ---------- safety ----------
L.PROT = /^(busybox|base-files|libc|libgcc\d*|musl|ucode|ucode-mod-|libubox|libubus|libuci|libblobmsg|libjson|libnl|libmbedtls|libopenssl|libustream|uclient|ubox|ubus|ubusd|uci|procd|netifd|rpcd|uhttpd|dropbear|odhcp|firewall|dnsmasq|nftables|libnftnl|libmnl|apk|opkg|kernel|kmod-|jsonfilter|fstools|mtd|urngd|urandom-seed|ca-bundle|ca-certificates|iw$|ip-|iptables|ppp|wpad|hostapd|swconfig|luci-base|luci-lib|luci-mod|luci-theme|luci-app-firewall|luci-proto|luci$|px5g|openwrt-keyring|logd|dumb-init|blockd|usign|libiwinfo|iwinfo|rpcd-mod)/;
L.isProt = n => L.PROT.test(String(n));
L.protoName = (p, ru) => ({ static: ['Статический адрес', 'Static address'], dhcp: ['DHCP-клиент', 'DHCP client'], dhcpv6: ['DHCPv6', 'DHCPv6'], pppoe: ['PPPoE', 'PPPoE'], none: ['Не настроен', 'Unmanaged'], wireguard: ['WireGuard', 'WireGuard'] }[p] || [p, p])[ru ? 0 : 1];
L.connName = (p, ru) => ({ proxy: ['Прокси', 'Proxy'], vpn: ['VPN-интерфейс', 'VPN interface'], block: ['Блокировка', 'Block'], exclusion: ['Напрямую (исключение)', 'Direct (exclusion)'] }[p] || [p, p])[ru ? 0 : 1];
L.modeName = (p, ru) => ({ url: ['один ключ', 'single key'], selector: ['выбор из списка', 'selector'], urltest: ['авто (лучший)', 'auto (best)'], outbound: ['JSON outbound', 'JSON outbound'] }[p] || [p, p])[ru ? 0 : 1];
L.stationsCmd = "for i in $(iw dev 2>/dev/null | awk '$1==\"Interface\"{print $2}'); do iw dev $i station dump 2>/dev/null | awk -v I=$i '/^Station/{m=$2} /signal:/{print I, m, $2}'; done; true";

// ---------- repository mirrors ----------
L.MIRRORS = [['downloads.openwrt.org', 'Основной (по умолчанию)', 'Default'], ['mirror-01.infra.openwrt.org', 'Официальное зеркало OpenWrt', 'Official OpenWrt mirror'], ['openwrt.freemirror.org', 'freemirror.org', 'freemirror.org'], ['mirror.kumi.systems/openwrt', 'kumi.systems', 'kumi.systems']];
L.MFILES = '/etc/apk/repositories.d/*.list /etc/opkg/distfeeds.conf';
L.mirrorTestCmd = () => L.MIRRORS.map((m, i) => '( s=$(date +%s); wget -q -T 6 -O /dev/null https://' + m[0] + '/releases/ >/dev/null 2>&1 || curl -sf -m 6 -o /dev/null https://' + m[0] + '/releases/ >/dev/null 2>&1; r=$?; e=$(( $(date +%s)-s )); [ $r -eq 0 ] && echo "' + i + ' ok $e" || echo "' + i + ' fail $e" ) &').join('\n') + '\nwait\ntrue';
L.parseMirror = t => { const o = {}; String(t).split('\n').forEach(l => { const m = l.trim().match(/^(\d+) (ok|fail) (\d+)/); if (m) o[m[1]] = { ok: m[2] === 'ok', s: +m[3] }; }); return o; };
L.mirrorSwitchCmd = i => { const m = L.MIRRORS[i]; if (!m) return 'false'; return 'for f in ' + L.MFILES + '; do [ -f "$f" ] || continue; [ -f "$f.rhorig" ] || cp "$f" "$f.rhorig"; sed -i -E "s#https?://(downloads\\.openwrt\\.org|mirror-01\\.infra\\.openwrt\\.org|openwrt\\.freemirror\\.org|mirror\\.kumi\\.systems/openwrt)#https://' + m[0] + '#g" "$f"; done; true'; };
L.mirrorRevertCmd = () => 'for f in ' + L.MFILES + '; do [ -f "$f.rhorig" ] && cp "$f.rhorig" "$f"; done; true';
L.mirrorCurCmd = () => 'cat ' + L.MFILES + ' 2>/dev/null | head -c 4000';
L.mirrorCur = t => { const x = String(t); let best = -1, pos = 1e9; L.MIRRORS.forEach((m, i) => { const p = x.indexOf('https://' + m[0]); if (p >= 0 && p < pos) { pos = p; best = i; } }); return best; };
// ---------- temperature ----------
L.TEMPCMD = 'for z in /sys/class/thermal/thermal_zone*; do [ -r $z/temp ] && echo "$(cat $z/type 2>/dev/null | tr \' \' _) $(cat $z/temp 2>/dev/null)"; done; for h in /sys/class/hwmon/hwmon*; do n=$(cat $h/name 2>/dev/null | tr \' \' _); for t in $h/temp*_input; do [ -r $t ] && echo "$n $(cat $t 2>/dev/null)"; done; done; true';
L.parseTemp = t => { const seen = new Set(), r = []; String(t).split('\n').forEach(l => { const m = l.trim().match(/^(\S+)\s+(-?\d+)$/); if (!m) return; let v = +m[2]; if (Math.abs(v) >= 1000) v /= 1000; v = Math.round(v * 10) / 10; if (v <= -30 || v >= 150) return; const k = m[1] + v; if (seen.has(k)) return; seen.add(k); r.push({ name: m[1], c: v }); }); return r; };
L.tempLabel = (n, ru) => /cpu|soc|core|thermal|a53|a7/i.test(n) ? (ru ? 'Процессор' : 'CPU') : /mt7|phy|wifi|wlan|ath|mac80211|radio/i.test(n) ? 'Wi-Fi ' + (n.match(/\d+/) || [''])[0] : n;
L.tempLevel = c => (c < 60 ? 'low' : c < 75 ? 'mid' : 'high');
g.L = L;
if (typeof module !== 'undefined') module.exports = L;
})(typeof window !== 'undefined' ? window : globalThis);
